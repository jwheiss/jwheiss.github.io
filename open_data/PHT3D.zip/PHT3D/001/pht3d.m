Doc = load('PHT3D001.ACN');
Oxygen = load('PHT3D002.ACN');
Nitrate = load('PHT3D003.ACN');
Nitrogen = load('PHT3D004.ACN');
Aerobic = load('PHT3D005.ACN');
Age = load('PHT3D006.ACN');
pH = load('PHT3D007.ACN');
pe = load('PHT3D008.ACN');
