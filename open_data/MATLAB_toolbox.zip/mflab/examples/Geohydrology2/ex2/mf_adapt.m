% Example see USGS Modflow 2000 manual, Open-File Report 00-92
% TO 090806 091129

clear variables; close all;

basename='ex2'; % model basename

%% Zones
i1 = 8;  % Zone second clay layer
i2 = 2; h2=-6;  % lower top layer
i3 = 3; h3=-3;  % higher top layer
i4 = 4; h4=-10; % building pit

%% Grid
xGr=[-5500:1000:5500 -2500:500:2500 -1500:250:1500 -100:100:500-500:50:50 -250:25:250];
yGr=xGr;
zGr=[-4 -12 -40 -50 -200]; % 4 layers

gr = gridObj(xGr,yGr,zGr);
figure; hold on; gr.plotGrid('c');

%% Layer properties
kh =[1e-2; 25; 1e-2; 30];

HK = gr.const(kh);
VK = HK;

%% which cells have fixed heads?

IBOUND=gr.const(99);             % default, all 1 ==compute these cells

%clay layer in2nd aquifer

xClay = -500;

IBOUND(:,gr.xm<xClay,3) =  i1; HK(IBOUND==i1) = 30; VK(IBOUND==i1)=30;

%entire toplayer
IBOUND(:,:,1)         =  -i2;

% zone2 higher land to the NE
IBOUND(:,gr.xm>500,1)  = -i3;
IBOUND(gr.ym>1500,:,1)  =-i3;

% building pit
IBOUND(gr.ym>-25 & gr.ym<25,gr.xm>-25 & gr.xm<25,1) =-i4;

STRTHD=gr.const(-0);      % all zeros, matrix same size as IBOUND
STRTHD(IBOUND==-i2)= h2;
STRTHD(IBOUND==-i3)= h3;
STRTHD(IBOUND==-i4)= h4; VK(IBOUND==-i4)=10;

% show the zones in the first layer
pcolor(gr.xc,gr.yc,IBOUND(:,:,1));

% save anything necessary in mf_analyze that is not automatically saved
save underneath gr

