% Seawat V4, Benchmark example, See Langevin e.a. 2008, p23ff

%  TO 091106 110606

% Example problem (verbatim from Langeving e.a. 2008, p23ff)
% An example problem was developed to illustrate the new model features
% presented in this report (see above). The problem consists of a
% two-dimensional cross section of a confined coastal aquifer initially
% saturated with relatively cold seawater at a temperature of 5C. Warmer
% freshwater with a temperature of 25C is injected into the coastal aquifer
% along the left boundary to represent flow from inland areas (fig. 1). The
% warmer freshwater flows to the right, where it discharges into a vertical
% ocean boundary. The ocean boundary is represented with hydrostatic
% conditions base on a fluid density calculated from seawater salinities at
% 5C. No-flow conditions are assigned to the top and bottom boundaries. A
% complete list of the intput values used for the problem is gien below.
% This problem is a simplified representation of what might occur in a
% coastal carbonate aquifer.

basename='coastal_flow';

% The entire table of Langevin et al, has been stored in the excel workbook
[LanNams,LanVals]=getExcelData([basename, '.xls'],'TableLangevin','Vertical');

% Assiging values from table for as far as needed for this model
top =LanVals(strmatchi('top' ,LanNams));  % Lan... = Langevin...
NX=LanVals(strmatchi('NCOL',LanNams));
NY=LanVals(strmatchi('NROW',LanNams));
NZ=LanVals(strmatchi('NLAY',LanNams));
Dx  =LanVals(strmatchi('Dx'  ,LanNams));
Dy  =LanVals(strmatchi('Dy'  ,LanNams));
Dz  =LanVals(strmatchi('Dz'  ,LanNams));
kh  =LanVals(strmatchi('kh'  ,LanNams));
kv  =LanVals(strmatchi('kv'  ,LanNams));
peff=LanVals(strmatchi('peff'  ,LanNams));
Ss  =LanVals(strmatchi('Ss'  ,LanNams));
h_ocean=LanVals(strmatchi('h_ocean',LanNams));
c_ocean=LanVals(strmatchi('c_ocean',LanNams));
T_ocean=LanVals(strmatchi('T_ocean',LanNams));
c_inflow=LanVals(strmatchi('c_inflow',LanNams));
T_inflow=LanVals(strmatchi('T_inflow',LanNams));
Q_inflow=LanVals(strmatchi('Qinflow',LanNams));

%% Mesh using table data

gr = gridObj([0 Dx*(1:NX)],[0 Dy*(1:NY)],[top, -(1:NZ)*Dz]);

%% Generate all other matrices using table data

iLeft  = 2;
iRight = 3;

IBOUND   =gr.const(1);  IBOUND(:,end,:)=iRight; IBOUND(:,1,:)=iLeft;
ICBUND   =gr.const(1);
STRTHD   =gr.const(h_ocean);
%STRTHD(:,1,:)=STRTHD(:,1,:)+3; % DEBUGGING
STCONC{1}=bsxfun(@times,interp1(gr.xGr([1 end]),[c_inflow c_ocean],gr.xm),ones(size(gr.zm)));
STCONC{2}=bsxfun(@times,interp1(gr.xGr([1 end]),[T_inflow T_ocean],gr.xm),ones(size(gr.zm)));

HK       =gr.const(kh);
VK       =gr.const(kv);
PEFF     =gr.const(peff);
SS       =gr.const(Ss);

%% Generate MNW objects and the acompanying PNTSRC for MT3DMS

MNW = MNW1Obj(basename,'MNW',gr,HK,{'PER','Q_'},{'PER','C_','T_'});

%% CHD right flow boundary

CHDDENSOPT=2;   % environmental head at ocean boundary, Langevin et al 2008, p22

zoneVals={iRight h_ocean h_ocean CHDDENSOPT};
concVals={c_ocean,T_ocean};

[CHD,PNTSRC] = bcnZone(basename,'CHD',IBOUND,zoneVals,concVals);


%% PNTSRC for SSM source sink mixing module MT3DMS/Seawat
save Underneath c_ocean T_ocean