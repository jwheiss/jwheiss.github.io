close all
clear variables

load underneath
load name
load(basename);

%% Analyzing model output

[xGr,yGr,zGr,xm,ym,zm,Dx,Dy,Dz,Nx,Ny,Nz]=modelsize3(xGr,yGr,zGr);

ZM=0.5*(Z(:,:,1:end-1)+Z(:,:,2:end));

%% % Reading simulation data

B=readBud([basename,'.cbb']);

T=readMT3D('MT3D002.UCN');    dT = 0.05; Trange=ContourRange(T,dT);

C=readMT3D('MT3D001.UCN');    dC = 0.50; Crange=ContourRange(C,dC);

H=readDat([basename,'.hds']); dH=0.01; Hrange=ContourRange(H,dH);

B=mf_psi(B);                  dPsi=1;  Prange=ContourRange(B,dPsi,[],'Psi');
T=maskHC(T,-900);
C=maskHC(C,-900);
H=maskHC(H,900);

%% Plot everything on multiple data axes to manage colors

t=[C.time]; NT=length(t);

scrsz=get(0,'screensize');
pos1=[scrsz(1)+0.025*scrsz(3) scrsz(2)+0.3*scrsz(4) 0.45*scrsz(3) 0.5*scrsz(4)];
pos2=[scrsz(1)+0.525*scrsz(3) scrsz(2)+0.3*scrsz(4) 0.45*scrsz(3) 0.5*scrsz(4)];

titlefmt=sprintf('Coert Strikker CT5440, Jul2011, t=%%.1f d, Psi=%.1f',dPsi);

axclr=[0.8 0.8 0.8];   % 'none'; % make all susequent axes transparent


figure('position',pos1);
ax(1)=clrobj(axclr,xm          ,XS(zm) , [0.5  1],   0:0.05:1 ,Jet2);
ax(2)=clrobj(axclr,xGr(2:end-1),XS(zGr), [ -5  5],  -5:0.05:5 ,Jet2);
ax(3)=clrobj(axclr,xm          ,XS(zm) , [ -5 5],   -5:0.1: 5 ,Jet2);
mf_setmulticolormap(ax([1 2 3]));  % generate combined colormap and set it
    
figure('position',pos2);
ax(4)=clrobj(axclr,xm          ,XS(zm) , [  5 12],     2:1  :22 ,Jet2);
ax(5)=clrobj(axclr,xGr(2:end-1),XS(zGr), [ -5  5],    -5:0.05:5 ,Jet2);
ax(6)=clrobj(axclr,xm          ,XS(zm) , [ -5 5],     -5:0.1: 5 ,Jet2);
mf_setmulticolormap(ax([4 5 6]));  % generate combined colormap and set it

film=0;

if film>0
    aviobj=avifile(basename,'compression','none',...
        'fps',5,'colormap',colormap);
end

for it=1:NT
   ax(1).title(sprintf('Langevin''s coast problem Choride    ; t=%.0f d, dPsi=%.2f m^2/d',C(it).time,dPsi));
   ax(4).title(sprintf('Langevin''s coast problem Temperature; t=%.0f d, dPsi=%.2f m^2/d',C(it).time,dPsi));

   if it==1
        ax(1)=ax(1).contour(@contourf,XS(C(it).values));
        ax(2)=ax(2).contour(@contour ,B(it).Psi);
        ax(3)=ax(3).contour(@contour, XS(H(it).values));
        ax(4)=ax(4).contour(@contourf,XS(T(it).values));
        ax(5)=ax(5).contour(@contour ,B(it).Psi);
        ax(6)=ax(6).contour(@contour, XS(H(it).values));
        xlim=get(ax(1).ax,'xlim');
        ylim=get(ax(2).ax,'ylim');
        for i=1:length(ax), set(ax(i).ax,'xlim',xlim,'ylim',ylim); end
        axes(ax(1).ax); for i=1:length(MNW), MNW(i).plot2d('w',2); end
        axes(ax(4).ax); for i=1:length(MNW), MNW(i).plot2d('w',2); end
        
        uistack(ax(1).ax,'bottom');
        uistack(ax(4).ax,'bottom');
 
     else
        ax(1).update(XS(C(it).values));
        ax(2).update(B(it).Psi);
        ax(3).update(XS(H(it).values));
        ax(4).update(XS(T(it).values));
        ax(5).update(B(it).Psi);
        ax(6).update(XS(H(it).values));

        drawnow;
  end
end

if film,
    aviobj=close(aviobj);
    if ismac, avi_compress(basename); end
end
