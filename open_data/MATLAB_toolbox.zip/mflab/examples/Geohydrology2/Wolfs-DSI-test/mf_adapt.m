% Seawat V4, Benchmark example, See Langevin e.a. 2008, p23ff

%  TO 091106 110606 110823

% DHI, based on problem (verbatim from Langeving e.a. 2008, p23ff)
% An example problem was developed to illustrate the new model features
% presented in this report (see above). The problem consists of a
% two-dimensional cross section of a confined coastal aquifer initially
% saturated with relatively cold seawater at a temperature of 5C. Warmer
% freshwater with a temperature of 25C is injected into the coastal aquifer
% along the left boundary to represent flow from inland areas (fig. 1). The
% warmer freshwater flows to the right, where it discharges into a vertical
% ocean boundary. The ocean boundary is represented with hydrostatic
% conditions base on a fluid density calculated from seawater salinities at
% 5C. No-flow conditions are assigned to the top and bottom boundaries. A
% complete list of the intput values used for the problem is gien below.
% This problem is a simplified representation of what might occur in a
% coastal carbonate aquifer.

basename='DSI';

% Assiging values from table for as far as needed for this model
%% Mesh using table data
peff=0.35;
hk=10;
vk= 1;
sy=0.1;
ss=1e-5;
h_start=0;
c_start=1;
T_start=12;
c_inflow=0;
T_inflow=10;

%% Grid

xGr=-200:200;
yGr=[-0.5 0.5];
zGr=[0:-1:-10 -12.5:-2.5:-20 -25:-5:-50];

[xGr,yGr,Z,xm,ym,zm,Dx,Dy,Dz,Nx,Ny,Nz]=modelsize3(xGr,yGr,zGr);

[XM,YM,ZM]=meshgrid(xm,ym,zm);

%% Generate all other matrices using table data
M=ones(Ny,Nx,Nz);      % dummy array of ones, size of model

IBOUND   =M;  IBOUND(:,[1 end],:)=-1;

ICBUND   =IBOUND;  % use CHD package

STRTHD   =M*h_start;

STRTHD(:,xm<25 & xm>-25,:)=-5;

%STRTHD(:,1,:)=STRTHD(:,1,:)+3; % DEBUGGING
STCONC{1}=M*1; % conc
STCONC{2}=M*12; % temp

HK       =M*hk;
VK       =M*vk;
PEFF     =M*peff;
SS       =M*ss;
SY       =M*sy;

%% Generate MNW objects and the acompanying PNTSRC for MT3DMS

[MNW,PNTSRC,WEL]=mf_setmnwells(basename,xGr,yGr,Z,{'Q_','C_','T_'},HK);

% %% CHD right flow boundary
% 
% CHDDENSOPT=2;   % environmental head at ocean boundary, Langevin et al 2008, p22
% 
% % similar for CHD boundary conditions on right hand boundary of model
% LRCright=cellIndices(find(XM>xGr(end-1)),size(M),'LRC');
% 
% CHD=[];
% u=ones(size(LRCright(:,1)));
% for iPer=1:MNW(1).NPER
%     CHD=[CHD;[iPer*u LRCright u*[h_ocean h_ocean CHDDENSOPT]]];
% end

%% PNTSRC for SSM source sink mixing module MT3DMS/Seawat

ITYPEleft =1;  % conc in prescribed head at left boundary
ITYPEright=1;  % conc at prescribed head at right boundary     
dummy=0;
% Notice that we have two species, salinity and temperature
LRCleft  = cellIndices(cellIndex([   ones(Nz,1),ones(Nz,1),(1:Nz)'],size(IBOUND)),size(IBOUND),'LRC');
LRCright = cellIndices(cellIndex([Nx*ones(Nz,1),ones(Nz,1),(1:Nz)'],size(IBOUND)),size(IBOUND),'LRC');

uR = ones(size(LRCright(:,1)));
uL = ones(size(LRCleft (:,1)));

for iPer=1:MNW(1).NPER
    PNTSRC=[PNTSRC; ...
                        iPer*uR LRCright uR*[dummy ITYPEright c_start  T_start];...
                        iPer*uL LRCleft  uL*[dummy ITYPEleft  c_start  T_start]...
                    ...
           ];
end

save Underneath h_start c_start T_start