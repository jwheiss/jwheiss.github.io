%% Analyzing model output
load('name'); load(basename);

%% Get unformatted data

H=maskHC( readDat([basename,'.hds']),[-1000 1000],[NaN NaN]);
C=maskHC( readMT3D('MT3D001.UCN'),   [0 1000],[0 NaN]);
B=maskBud(readBud([basename,'.bgt'],'FLOWRIGHTFACE'),1000);  % get only flow rightface
B=mf_Psi(B);

%hrange=ContourRange(H,50);
crange=ContourRange(C,50); 
prange=ContourRange(B,[5 10],'','Psi');

%% Contour each result or make movie

figure;
hold on
xlabel('x [m]');
ylabel('z [m]');
grey=get(gcf,'color');
set(gca,'clim',crange([1 end]));

%% Loop for movie
vidObj=VideoWriter('Elder');
vidObj.FrameRate=3;
vidObj.open();

s=sprintf(' dC=%g, dPsi=%g m2/d',min(diff(crange)),min(diff(prange)));

for it=1:length(C)
    ttl=sprintf('Heat transport from nuclear storage, t=%.0f %s',C(it).time,s);
    
    if it==1
         ht =title(ttl);
        [~,hc]=contourf(gr.xc,gr.zc,XS(C(it).values),crange);
        [~,hp]=contour( gr.xp,gr.zp,B(it).Psi,prange,'color',grey);
    else
        set(ht,'string',ttl);
        set(hc,'zData',XS(C(it).values));
        set(hp,'zData',B(it).Psi);
    end
    set(get(hc,'children'),'edgecolor','none');
    drawnow;
    vidObj.writeVideo(getframe(gcf));

end
vidObj.close();