% MF_ADAPT -- Seawat Benchmark example
% See Guo and Langevin (2002) p72ff
%  TO 090101 091207

basename='Kernafval';
FREE = 1;
BACKGROUND=0;  % run in background
GREP = 'STRESS';

%this is a modification of the elder problem
%The model show the heat flow from an underground storage of radio active
%material.
%The model is 600 m wide and 225 meter heigh this is the depht of the depth
%of the faciltie near mol (Dutch belguim border near Eindhoven).


%% Parameters

L     =300;     % m half width of model          
H     =225;     % m height and top of model      (Diepte is 225 meter van het onderzoeks lab in Mol)
peff  = 0.1;    % [ ] effective porosity         (niet bekend wat de werkelijke waarde is)
k     = 0.411;  % m/d hydraulic condictivity     (is de porositeit van de boven ligende laag)
Kk    = 0.0018; % m/d hydraulic condictivity     (porositeit van de klei laag (tweede laag) 0.0018 m/d laag van breda)
k1    = 1e-5;   % for top and bottom layer       
Tempstorage=80; % Celcius                        (temperatuur van de wanden van de opslag faciliteit 80 uit bron 25 uit opdracht)
NormTemp=10;    % Celcius                        (10 normale tempratuur voor grondwater)
rhof  =1000;    % kg/m3 freshwater density       
rhob  =972;     % kg/m3 warm water density            
aL    =0;       % m longitudinal dispersivity    
aT    =0;       % m transverse dispersivity      
D     =0.308;   % m2/d molecular diffusion coefficient   
hCorner=225;    % m (point water heads)          

%% Mesh

xGr=-L:10:L;                % verdeelt de breedt in stappen van 10
zGr=H:-5:0;                 % verdeelt de hoogte in stappen van 5
yGr=[0 1];

gr=gridObj(xGr,yGr,zGr);

%% Generate all other matrices
ZONE   = zeros(gr.size);

IBOUND = gr.const(1);
ICBUND = gr.const(1);
STRTHD = gr.const(hCorner);
STCONC = gr.const(NormTemp);
HK     = gr.const(k);
VK     = HK;
PEFF   = gr.const(peff);

%% Set zones
itopside   = 1;
itopmid    = 2;
itopcorner = 3;
ibottom    = 4;

ZONE(:,gr.xm<-L/6 | gr.xm>L/6,end)= itopside;     % inactive
ZONE(:,gr.xm>-L/6 & gr.xm<L/6,end)= itopmid;        %zorgt voor de lengte van het de warmte bron is 100 meter
ZONE(:,[1 end],(end-1))               = itopcorner;   % only corner in to of model
ZONE(:,:,1)                   = ibottom;

%% Arrays
HK(:,:,[33:end])=Kk;                     % geeft de hoogt van de onderste laag aan 
VK     = HK;
HK(:,:,[1 end])=k1;

IBOUND(ZONE==itopcorner) =-1;
IBOUND(ZONE==itopside)   = 0;

ICBUND(ZONE==itopmid)    = -1;
ICBUND(ZONE==ibottom)    = -2;

STRTHD(ZONE==itopcorner)= H;
STRTHD(:,1,:)=230;      % zorgt voor een hoger head aan een kant van het model 225 = geen stroming
STCONC(ZONE==itopmid)   = Tempstorage;
