% MF_ADAPT -- Seawat Benchmark example
% See Guo and Langevin (2002) p72ff
%  TO 090101 091207

basename='Kernafval';

%%
% This is a modification of the elder problem
% The model showed the heat flow from an underground storage of radio active
% material.
% The model is 600 m wide and 225 meter high this is the depht of the
% of the facilty near Mol (Belguim).

% Let us assume for simplicity that the facility has a width L and al
% length infinity perpendicular to our cross section. Later on we can turn
% the model into a full three dimensional one if desired.
% Further let us put the facility at 2 km to the north of the water divide
% in the Kempen, so that any losses will be transported northward towards
% Brabant. The water divide is a closed boundary of the model.

% It may be very practical to manipulate some of the data in a sheet of
% your workbook (kernafval.xls) and read them into mf_adapt. In the
% workbook you can easily relate different variables and so preliminary
% computations.

% We will also put the geology in a sheet in the workbook and read that in
% as well.

%% Parameters

[dataHdr,data] = getExcelData(basename,'data','vertical');

L          = data(strmatchi('L'          ,dataHdr));
Tfacility  = data(strmatchi('TempStorage',dataHdr));
Ttop       = data(strmatchi('TempNormal' ,dataHdr));
dtdz       = data(strmatchi('geogradient',dataHdr));
Ztop       = data(strmatchi('Ztop'       ,dataHdr));
Zbot       = data(strmatchi('Zbot'       ,dataHdr)); 
zTfacility = data(strmatchi('zTfacility' ,dataHdr));
zBfacility = data(strmatchi('zBfacility' ,dataHdr));

%% Mesh

Conf = xsConfObj(basename,'config','material');

xLfacility = Conf.xL(strmatchi('facility',Conf.zoneNames));
xRfacility = Conf.xR(strmatchi('facility',Conf.zoneNames));

xGr= [0:25:L xLfacility xRfacility];                % verdeelt de breedt in stappen van 10
zGr= [Ztop:-10:Zbot Zbot zTfacility zBfacility];       % verdeelt de hoogte in stappen van 5
yGr=[0 1];

gr=gridObj(xGr,yGr,zGr);

clear xGr yGr zGr

%% Generate all other matrices

STRTHD = Conf.array3D(gr,'head'    ,'g');  % initial heads no NaNs
HK     = Conf.array3D(gr,'kh'      ,'g');  % initial horizontal conductivity
VK     = Conf.array3D(gr,'kv'      ,'h');  % initial vertical conductivity
PEFF   = Conf.array3D(gr,'Porosity','g');

IBOUND = gr.const(1); IBOUND(:,end,:)=-1;
ICBUND = IBOUND;

% insert geogradient for initial temperatures
STCONC = gr.const(Ttop +dtdz*( Ztop - gr.zm));

%% make z zone in the IBOUND to mark the location of the facility:
iFacility = 5;
IBOUND(:,gr.xm>xLfacility & gr.xm<xRfacility,gr.zm>zBfacility & gr.zm<zTfacility)= iFacility;

% Generate PNTSRC for that zone, using 'CCC' for constant concentration
% cell (see manual of MT3MDS)
[~,PNTSRC] = bcnZone(basename,'CCC',IBOUND,{iFacility NaN},Tfacility);

