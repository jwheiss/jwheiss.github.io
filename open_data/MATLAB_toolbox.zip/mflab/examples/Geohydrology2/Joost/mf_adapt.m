% MT3DMS Benchmark Problem see Zheng & Wang (1999), p139ff
% Two-dimensional Transport in a Diagonal Flow Field

%  TO 091114 091203

basename='ATES'; 

fprintf('Hello I''m running\n');
% The problem considered in this section is similar to the 2D-Uniform case
% except that the flow direction is oriented at a 45-deg angle to both
% the columns and the rows of the model grid. The grid Peclet number for this
% problem is 5 in the longitudinal direction and 50 in the transverse direction.
% The problem represents a challenging test for transport solution techniques
% because of the sharpness of the concentration front, compounded by the grid
% orientation effect.

% The model has 100 rows and columns and one layer. The parameters use
% are listed below. Note that mflab gets aL and aT from the worksheet LAY
% not from this m-file.

delx=10;      % m
dely=10;      % m
delz=50;      % m
peff=0.35;    % [] effective porosity
v   =2/365;       % m/d seepage velocity 45degrees NE
cIn =1000;    % ppm  Injection water concentration
              % simulation time 1000d (set in worksheet PER)
%% Mesh

%Nz=1; Ny=100; Nx=100;   Gooi dit eruit, want wordt hierodner berekend in
%modelsize3

% De shift van de coordinaten hieronder zorgt dat de wells midden in de
% cellen komen te liggen. Je krijgt dan geen kunstmatige verschuiving.
% Alternatief is zeer fijn grid maar dat kost heel veel rekentijd of om het
% grid buien grof en binnen fijn te maken, maar dat vervormt de bellen te
% zeer. 5 m lijkt bij de gehanteerde afstand tussen de putten en debieten
% een aardig compromis.
xGr= [-500:5:500 ]-2.5; % [-400:5:400]; % [-500:50:500 -100:5:100 ]; %-50:2.5:50];
yGr= [-500:5:500 ]-2.5; % [-400:5:400]; % [-500:50:500 -100:5:100 ]; %-50:2.5:50];
zGr= 0:-delz:-50;

[xGr,yGr,zGr,xm,ym,zm,Dx,Dy,Dz,Nx,Ny,Nz]=modelsize3(xGr,yGr,zGr);

[Xm,Ym]=meshgrid(xm,ym);  % centers of all cells
xUR=xGr(end); yUR=yGr(1); % x nd u of upper right corner of model grid

Z=zGr(ones(Ny,1),ones(1,Nx),1:length(zGr));

%% Generate all other matrices
IBOUND=ones(Ny,Nx,Nz);
   IBOUND(:,[1 end],:)= -1;  % Fix west and east   boundary head
   IBOUND([1 end],:,:)= -1;  % Fix north and south boundary head
ICBUND=ones(Ny,Nx,Nz); % All one, don't need fixed conc boundary

%% Uniform flow field under 45degrees in NE direction

% The uniform ambient flow is at 45 degrees to with the grid, but Zheng
% specifies no boundaries. Hence we have to estimate them ourselves. The
% problem is independent of the conductivity (it is assumed uniform) and
% iwth the given groundwater seepage of 1 m/d we have a gradient i=q/k
% Assuming Zheng uses the word seepage for Darcy flow, we have with k=10
% i=1/10=0.1 m/m. So the gradient along the 45degree boundary is sqrt(1/k).
% so starting with a head 0 at the upper corner of the model, we have the
% following boundary head everywhere
%STRTHD=0+(xGr-xUR)*(qx/k)+(yGr-yUR)*(qy/k), with ix=iy=-sqrt(q/k)

angle=0;
%angle=-pi*90/180; % degrees
q =v*peff;
qx=q*cos(angle);  % from seepage velocity to specific yield in x-dir
qy=q*sin(angle);  % from seepage velocity to specific yield in y-dir

kh= 25; kv=25;   % values are irrelevant in this 1d problem

STRTHD=0-(Xm-xUR)*qx/kh-(Ym-yUR)*qy/kh;

HK       =ones(Ny,Nx,Nz)*kh;
VK       =ones(Ny,Nx,Nz)*kv;
PEFF     =ones(Ny,Nx,Nz)*peff;
STCONC{1}=ones(Ny,Nx,Nz)*0;
STCONC{2}=ones(Ny,Nx,Nz)*0;  % Je hebt twee components, dus ook twee start concentratie arrays

%% Wells

% Met de functie mf_setwells is het invoeren van de wells veel eenvoudige
% geworden. wel is nu de struct met de wel data, en WEL en PNTSRC zijn de
% arrays die je nodi hebt voor he tmodel
% Je kan alle comments hieronder weggooien.

% er was nog een klein probleem met de gridcoordinaten ten opzichte van de
% well coordinaten. Namelijk, een van de wells (x-0) lag op de rand van het
% grid (xGr=0). Ik heb xGr nu van -500 tot 500 laten lopen. Pas het aan aan
% wat je wil, maar de putte moeetn wel binnen je netwerk vallen.



% we only need the well
% iPer=1;                 % stress period (only one)

% [welnams,welvals]=getExcelData(basename,'wells','h');

% xw=welvals(:,strmatchi('x',welnams));
% yw=welvals(:,strmatchi('y',welnams));

% welpos=NaN(size(xw,1),5);              NWEL=size(welpos,1);

% [pernams,pervals]=getperiods(basename); NPER=size(pervals,1);

gr = gridObj(xGr,yGr,Z);

wel = wellObj(basename,'wells',gr,HK,'PER',1:3);

% wel(NWEL).iQ=NaN;
% for i=1:size(welpos,1)
%     wel(i).x  = xw(i);
%     wel(i).y  = yw(i);
%     wel(i).ix = find(xm<=xw(i),1,'last');
%     wel(i).iy = find(ym>=yw(i),1,'last');
%     wel(i).iz = 1;  % only one layer yet !
%     wel(i).iQ = strmatchi(sprintf('Q_%d',i),pernams);
%     wel(i).iC = strmatchi(sprintf('C1_%d',i),pernams);
% end

%%
% ITYPE=2;  % WELLS see MT3D manual

% WEL=[]; PNTSRC=[];
% for iPer=1:NPER
%     for iw=1:NWEL
%         WEL=[WEL;...
%             iPer wel(iw).iz wel(iw).iy wel(iw).ix pervals(iPer,wel(iw).iQ)];
%         PNTSRC=[PNTSRC;...
%             iPer wel(iw).iz wel(iw).iy wel(iw).ix pervals(iPer,wel(iw).iC) ITYPE];
%     end
% end

fprintf('hello I''m done\n');

save underneath wel
