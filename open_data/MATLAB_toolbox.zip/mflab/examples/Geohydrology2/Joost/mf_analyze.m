%% Analyzing model output
load('name'); load(basename);
load underneath

problem='Jost van der Zwet, ATES, CT5440';
%% visualization

[xGr,yGr,xm,ym,Dx,Dy,Nx,Ny]=modelsize(xGr,yGr);
%xm=xm-Dx(1)/2;  % hier ga je helemaal de mist in. xm klopt niet meer. Pas xGr in en gebruik modelsize
%ym=ym-Dy(1)/2;  % om de juste xm te krijgen, maar ga niet alsnog je xm en ym verprutsen !!

%% Reading unformattted files
%H=readDat([basename,'.hds']);

%% Concentrations from files, each file is for one species
%%(we have only one in this example though

C=readMT3D(sprintf('MT3D001.UCN'));

%% B=readBud([basename,'.bgt'],'FLOWRIGHTFACE');

%% Visualization
ADVmethod={
    'ULTIMATE (TVD)'
    'FDM standard'
    'MOC'
    'MMOC'
    'HMOC'
    };
isothm={
    'no sorption'
    'Linear'
    'Freundlich'
    'Langmuir'
    'First order kinetic'
    'Dual domain mass transfer'
    'Dual dom. mass transf. +sorption'};

%% Get advection method used from MT3D worksheet
[MT3Dparnams,MT3Dparvals]=getExcelData([basename,'.xls'],'MT3D','vertical');
MIXELM=MT3Dparvals(strmatchi('MIXELM',MT3Dparnams));

%%

% De kunst is nu nog om ook de andere concentratie (component 2) te laten
% zien en om een filmpje te maken zodat je kan zien hoe de bellen zich
% ontwikkelen. Je moet daarvoor het contouren in een loop zetten. Zee
% bijvoorbeeld examples/swt_v4/Elder of fsse of fresh_keeper of
% Lima-AbuDhabi, die maken allemaal filmpjes.

figure; hold on;

[c,h]=contourf(xm,ym,C(end).values,[0.1 0.20 0.30 0.4 0.5 0.6 0.7 0.8 0.9 1 1.5 2]);
clabel(c,h);

title(sprintf('%s t=%g d, advection solution method = %s',...
    problem,C(end).time,ADVmethod{MIXELM+2}));
xlabel('xGr [m]'); ylabel('yGr [m]');
grid('on');


plotgrid(xGr,yGr,'c',wel); % You can plot the grid easily, including well locations
