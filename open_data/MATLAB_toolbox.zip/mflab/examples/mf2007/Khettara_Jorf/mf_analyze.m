%% Khettara Erfoud, Morocco (Qanat) under construction
% TO 100827

%% Read out the head and budget file and show the results
% This file is still a bit primitive and geared to the steady-state
% solution. It can however, be easily extended to other more extensive
% situations.

clear variables; close all;

load name
load(basename)

if exist('dem3.mat','file');       load('dem3');       end
if exist('underneath.mat','file'), load('underneath'); end
 
%% Model grid house keeping

[xGr,yGr,Z,xm,ym,zm,DX,DY,DZ,Nx,Ny,Nz]=modelsize3(xGr,yGr,Z);

%% Get heads of first layers 

H=maskHC(readDat([basename '.hds']),10000); % get heads for these dates only and only layer 1

%% If ZBot does not exist create it for next time
%  remove it by using mf_cleandir

if ~exist('ZBot.mat','file')
    ZBot=min(Z(:,:,2),H(end).values(:,:,end)-10);
    save ZBot.mat ZBot
end
%% Compute budgets

B=readBud(['-' basename '.bgt']); % selected cross sections for water balance

%% heads plot

hrange=ContourRange(H,2.5);

figure; hold on;

[c1,h1]=contourf(xm,ym,H(end).values(:,:,1),hrange);
set(get(h1,'children'),'edgecolor','none');

xlabel('x [m]'); ylabel('y [m]'); title('head contours qanat system');

colorbar;

%% SN cross section with latitude on horizontal scale

% figure; hold on;
% ix=find(dem3.em>=-4.3,1,'first');            % let the cross section go through -4.3 degrees longitude
% 
% [eGr,nGr,em,nm]=modelsize(dem3.eGr,dem3.nGr); % get lattitude (and longitude)
% 
% plot(nm,squeeze(Z(:,ix,1)),'g');              % Ground surface
% plot(nm,squeeze(STRTHD(:,ix,:)),'c');         % Initial head
% plot(nm,squeeze(H(end).values(:,ix)),'b');    % Computed head
% plot(nm,squeeze(Z(:,ix,2)),'k');              % Bottom elevation applied
% 
% set(gca,'ylim',[700 1000]);                   % limit scale vertical axis
% legend('Ztop','Strthd','H computed','Zbot ?') % place legend

%% Get overall budget over all items

zonebudget(B);
