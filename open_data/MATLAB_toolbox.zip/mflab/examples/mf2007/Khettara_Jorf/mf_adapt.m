% Simulation of the Khettara (Qanats) in the Tafilalt (Erfoud, Morocco)
% Under construction (modelworks, Khettara yet to be included).
% We use mf2005 for its new parameters making simulation of top layer
% easier than with the continuous and never ending trouble with
% rewetting of cells in all other versions of MODFLOW
%
% The 3sec arc (90 m) srtm dem for Marokko (75MB) which containing the Erfoud area is use for
% ground elevation.
%
% http://www.cgiar-csi.org/data/elevation/item/45-srtm-90m-digital-elevatio
%
% n-database-v41
% The extensions of the srtm file is 5 by 5 degrees: lat: 30 35; lon: -5 0
% Erfoud area of interest for the Khettara is
% lat:  31.30 31.55 lon: -4.5 4.0
%
% The srtm tiff file constains pixelwise elevations in m (16 int values)
% The size of the image is 6001 by 6001 pixels
%

clear variables
close all;

basename='Jorf';

R2 = 6371007.2;  % The Earth's authentic radius (Geodetic Union);

ss=0.001;  % elastic storage coefficient
sy=0.10;   % specific yield
k =10;     % hydraulic conductivity

% Center of model grid will be at
eGr0=-4.0; %  longitude
nGr0=31.0; %  latitude

%% Model bounary (digitized)

mboundary=[
   -4.453614    31.301959
   -4.454693    31.318937
   -4.468716    31.341138
   -4.453614    31.355504
   -4.435275    31.350280
   -4.423409    31.359422
   -4.373786    31.358116
   -4.366235    31.377705
   -4.368393    31.398601
   -4.379180    31.419496
   -4.401834    31.432556
   -4.433118    31.441698
   -4.457929    31.437780
   -4.463323    31.459981
   -4.473031    31.465205
   -4.479504    31.496549
   -4.515102    31.506996
   -4.543150    31.501772
   -4.573355    31.510914
   -4.618662    31.533116
   -4.682309    31.550093
   -4.723301    31.548787
   -4.749191    31.559235
   -4.789105    31.550093
   -4.802050    31.550093
   -4.831176    31.533116
   -4.835491    31.556623
   -4.790183    31.585354
   -4.811758    31.616698
   -4.728695    31.650653
   -4.647789    31.661101
   -4.611111    31.680690
   -4.574434    31.704198
   -4.532362    31.691138
   -4.471953    31.684608
   -4.388889    31.655877
   -4.356526    31.638899
   -4.317691    31.637593
   -4.287487    31.615392
   -4.258360    31.623228
   -4.246494    31.654571
   -4.217368    31.649347
   -4.199029    31.666325
   -4.187163    31.666325
   -4.194714    31.621922
   -4.192557    31.584049
   -4.158037    31.572295
   -4.141855    31.535728
   -4.123517    31.504384
   -4.164509    31.499160
   -4.145092    31.458675
   -4.216289    31.448228
   -4.214132    31.429944
   -4.169903    31.409049
   -4.156958    31.426026
   -4.112729    31.407743
   -4.073894    31.414272
   -4.074973    31.375093
   -4.002697    31.375093
   -4.001618    31.299347
   -4.450378    31.300653];

%% Start

%% Reading the srtm and processing it costs around 20 sec, so if the
%% dem3.mat created from it already exists, we read its mat file instead
if ~exist('dem3.mat','file')  % if not we interpret the srtm file

    %% READ STRM_36_90

    tilefname='srtm_36_06';
    dem=mf_getdemfromtiff(tilefname);

    %% To show it, it's very big, 600` by 6001 pixels
    %  so make it coarser and show it as surf
    
    dem1=mf_demCoarse(dem,10,10);
    figure; hold on; surf(dem1.em,dem1.nm,dem1.z,dem1.z,'edgecolor','none');

    %% Chose area of interest for the model
    lonlim=[-5   -4];
    latlim=[31.3  32];
%     lonlim=[-4.75 -4.25];
%     latlim=[31.25 31.75];
%     lonlim=[-5 -4.5];
%     latlim=[32.25 32.75];

    % show the area of interest (plot it 2000 m high to make sure its
    % visible above the surface
    
    plot3(lonlim([1 2 2 1 1]),latlim([1 1 2 2 1]),2000*ones(5,1),'g');
    plot(-4.5,31.5,'ro');
    
    % I digitized coarsely the near field for the model where most of the
    % Khettara are:
    [E1,N1]=kmlpath('ErfoudPath');
    plot3(E1,N1,2000*ones(size(E1)),'k');

    %% Plot digitize model boundary (again at 2000 m in the sky) above the
    %% surf
    plot3(mboundary(:,1),mboundary(:,2),2000*ones(size(mboundary(:,1))),'k');
    
    %% Zoom in on area of interest
    set(gca,'xlim',lonlim,'ylim',latlim);

    colorbar

    %% Get dem for grid coordinates
    
    %% Here I create a grid in longitude and latitude coordinates
    eGr=lonlim(1):3*dem.PixelScale(1):lonlim(2);
    nGr=latlim(1):3*dem.PixelScale(2):latlim(2);

    %% transform the old dem into this one by interpolating whenhever
    %  required
    dem2=mf_dem2grid(dem,eGr,nGr);
     
    % and plot it

    figure; hold on;
    z=dem2.z;
    E=ones(size(dem2.nm(:)))*dem2.em(:)';
    N=dem2.nm(:)*ones(size(dem2.em(:)'));
    [In,On]=inpolygon(E,N,mboundary(:,1),mboundary(:,2));
    z(~In | On)=NaN;
    dem2.z=z;
    surf(dem2.em,dem2.nm,dem2.z,dem2.z,'edgecolor','none');
    plot3(lonlim([1 2 2 1 1]),latlim([1 1 2 2 1]),2000*ones(5,1),'g');

    [E1,N1]=kmlpath('ErfoudPath');
    plot3(E1,N1,2000*ones(size(E1)),'k');

    axis tight
    colorbar;

    %% Remove heading and trailing rows and columns with NaN
    
    dem3=mf_cleandem(dem2);
    
    figure; hold on;
    z=dem3.z;
    E=ones(size(dem3.nm(:)))*dem3.em(:)';
    N=dem3.nm(:)*ones(size(dem3.em(:)'));
    
    % save this one for later use
    save dem3.mat dem3
else
    load dem3
end

%% Plot dem3

figure; hold on

surf(dem3.em,dem3.nm,dem3.z,dem3.z,'edgecolor','none');

[E1,N1]=kmlpath('ErfoudPath');
plot3(E1,N1,2000*ones(size(E1)),'k');

plot3(mboundary(:,1),mboundary(:,2),2000*ones(size(mboundary(:,1))),'k');

xlabel('longitude [decimal degrees]'); ylabel('latitude [decimal degrees]'); grid on; title('Model area');
axis tight
colorbar;

%% Change to x,y coordinates for the sake of the model

xGr=R2*(dem3.eGr-eGr0)/180*pi*cos(nGr0/180*pi);
yGr=R2*(dem3.nGr-nGr0)/180*pi;

Z=repmat(dem3.z,[1,1,2]); % top  of the aquifer
Z(:,:,2)=Z(:,:,1)  -30;     % base of the aquifer

[xGr,yGr,Z,xm,ym,ZM,Dx,Dy,DZ,Nx,Ny,Nz]=modelsize3(xGr,yGr,Z);

ZGR=mf_Z_extend(Z,xGr,yGr);

%% Plot dem3 in x,y coordinates

figure; hold on
h=surf(ones(size(yGr))*xGr,yGr*ones(size(xGr)),ZGR(:,:,1),Z(:,:,1),'edgecolor','none');
set(gca,'clim',[700 1000]);
axis tight

colorbar;

%% If we created ZBot (zie mf_analyze) we use it

if exist('ZBot.mat','file');
    load('ZBot.mat');
    
    % Use ZBot to change Z(:,:,2) and STRTHD
    Z(:,:,end)= min(Z(:,:,end)-0.01,ZBot);
    STRTHD=0.5*(Z(:,:,1)+ZBot);
else
    STRTHD=mean(Z,3);
end

%% Further parameters, preparing the actual model

IBOUND=ones(Ny,Nx,Nz);
IBOUND(end,:,1)=-1; IBOUND(:,end,1)=-1; % fixed head boundary condition
IBOUND(isnan(STRTHD))=0;     % inactive cells

HK=k*ones(size(IBOUND));
VK=HK;
SY=sy*ones(size(IBOUND));
SS=ss*ones(size(IBOUND));

STRTHD(isnan(STRTHD))=0;     % remove NaN's
Z(     isnan(Z     ))=0;     % remove NaN's
Z(:,:,2)=min(Z(:,:,2),Z(:,:,1)-0.1); % Make sure the aquifer has always some thickness

save underneath E1 N1;  % To becd  used in mf_analyze
