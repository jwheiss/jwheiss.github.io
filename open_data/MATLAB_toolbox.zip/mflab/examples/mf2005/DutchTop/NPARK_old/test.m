%% Lambda

z=logspace(-2,3,51);
semilogx(z,tanh(z)./z,'k','linewidth',2);
grid on
title('factor \Lambda(\gamma)');
ylabel('\Lambda(\gamma)');
xlabel('\gamma=L/(2 \lambda)');

%%


L=[P.L]';
N=0.001;
c=[P.c]';
kD=[P.hk1]'.*[P.c]';
lambda=sqrt(kD.*c);

LAMBDA=tanh(L./(2*lambda))./(L./(2*lambda));

b=L/2;
F=(cosh(b./lambda).^2-1)./(cosh(b./lambda).*sinh(b./lambda));


gamma=L./(2*lambda);

%y=(2*lambda/L).^2.*(1-LAMBDA)./LAMBDA;
%y=(1./gamma.^2).*(1-LAMBDA)./LAMBDA;
y=(1./gamma.^2).*(gamma-tanh(gamma))./tanh(gamma);

yinf=1/3;

fprintf('NL^2/(12kD)=%g\n',yinf)
figure
semilogx(c,y)
hold on
plot(c([1 end]),yinf([1 1]),'k','linewidth', 2);
set(gca,'xlim',[1e-2,1e5]);
title(sprintf('y=c \\Lambda / (1 - \\Lambda); kD=%d m^2/d; L=%d m',kD,L));
xlabel('c [d]'); ylabel('y=c \Lambda / (1-\Lambda)');
legend('y=c \Lambda / (1-\Lambda)','L^2/(12 kD)');
grid on;


%%
close all
figure; hold on


gamma=logspace(-3,3,61);
plot(gamma,(3./gamma.^2).*(gamma-tanh(gamma))./tanh(gamma),'k','linewidth',2);
set(gca,'xscale','log');
grid on
title('y=(1 / \gamma^2) (\gamma-tanh \gamma)/tanh \gamma');
xlabel('\gamma = L/(2 \lambda)'); ylabel('y'); grid on;

%%

lambda=10;
L=logspace(0,4,41);
Llam=L/(2*lambda);
LAMBDA=tanh(Llam)./Llam;

figure;
semilogx(Llam,LAMBDA,'k-','linewidth',2);
set(gca,'xlim',[1e-2,1e3]); grid on
title('y=\Lambda = tanh(\gamma)/\gamma, \gamma=L/(2 \lambda), \lambda=sqrt(kDc)');
xlabel('\gamma = L / (2 \lambda)'); ylabel('y');


%% Test semi-spanningswater met intredeweerstand

b=50;
k=1; D=6; c=10; lambda=sqrt(k*D*c);
w0=1e-6;
w1=10;
N=0.03;
sLR=-0;
phi=-0;
hLR=phi+sLR;

x=0.5:0.5:b;
s0 =sLR+(N*c-sLR)*(1-cosh(x/lambda)./(k*w0/lambda*sinh(b/lambda)+cosh(b/lambda)));
s0_=sLR+(N*c-sLR)*(1-cosh(b/lambda)/(b/lambda)/(k*w0/lambda*sinh(b/lambda)+cosh(b/lambda)));
s1 =sLR+(N*c-sLR)*(1-cosh(x/lambda)./(k*w1/lambda*sinh(b/lambda)+cosh(b/lambda)));
s1_=sLR+(N*c-sLR)*(1-cosh(b/lambda)/(b/lambda)/(k*w1/lambda*sinh(b/lambda)+cosh(b/lambda)));

qu0=-s0_/c;
qu1=-s1_/c;

B0=(1-(k*w0*b/lambda^2+b/lambda*coth(b/lambda))^(-1))^(-1);
B1=(1-(k*w1*b/lambda^2+b/lambda*coth(b/lambda))^(-1))^(-1);

F0x=(1-cosh(x/lambda)/(k*w0/lambda*sinh(b/lambda)+cosh(b/lambda)));
F1x=(1-cosh(x/lambda)/(k*w1/lambda*sinh(b/lambda)+cosh(b/lambda)));

G0=b/lambda*(k*w0/lambda + tanh(b/lambda) - cosh(x/lambda)/sinh(b/lambda));
G1=b/lambda*(k*w1/lambda + tanh(b/lambda) - cosh(x/lambda)/sinh(b/lambda));


s0__=N*c/B0+(B0-1)/B0*sLR;
s1__=N*c/B1+(B1-1)/B1*sLR;

h0__=hLR+(N+qu0)*c/(B0-1);
h1__=hLR+(N+qu1)*c/(B1-1);

h0 =hLR+(N+qu0)*c*B0/(B0-1)*F0x;
h1 =hLR+(N+qu1)*c*B1/(B1-1)*F1x;

h00 =(N+qu0)*c*G0;
h11 =(N+qu1)*c*G1;

figure; hold on;
plot(x,s0+phi,'bp','linewidth',1); plot(x,ones(size(x))*s0_+phi,'bx',x,ones(size(x))*s0__+phi,'b+');
plot(x,s1+phi,'rp','linewidth',1); plot(x,ones(size(x))*s1_+phi,'rx',x,ones(size(x))*s1__+phi,'r+');

plot(x,ones(size(x))*h0__,'go');
plot(x,ones(size(x))*h1__,'mo');

plot(x,h0,'g',x,ones(size(x))*h0__,'gp');
plot(x,h1,'m',x,ones(size(x))*h1__,'mp');

plot(x,h00,'co');
plot(x,h11,'cp');

%% Test multilayer

A=rand(4); sqrtA=sqrtm(A); x=5;

C=funm(x*sqrtA,@cosh)

C*A
A*C

%% Test series limit

s=0;

N=100; s=NaN(N,1); term=NaN(N,1);
term(1)=8/pi^2;
s(1)   =term(1);
for j=2:N
    j2m1=2*j-1;
    term(j)=8/pi^2/j2m1^2;
    s(j)=s(j-1)+term(j);
end

figure;
subplot(2,1,1); plot(1-s);    set(gca,'yscale','lin','ygrid','on','xgrid','on','yminortick','on','xminortick','on');
subplot(2,1,2); plot(term); set(gca,'ytick',[1e-5 1e-4 1e-3 1e-2 1e-1 1e0],'yscale','log','ygrid','on','xgrid','on','yminortick','on','xminortick','on');

