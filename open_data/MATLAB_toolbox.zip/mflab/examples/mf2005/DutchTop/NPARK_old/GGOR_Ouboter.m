function P=GGOR_Ouboter(tne,P)
% function P=GGOR_Ouboter(tne,P)
%
% Dit is de functie "Bereken" in het python script van de officiele GGOR
% tool van Waternet zoals ontworpen door Maarten Outboter
% Ik heb het bestand GxGCalc.py voor dit doel volledig gestript en
% weggelaten wat al in andere matlab scripts gebeurt.
% Deze functie is het hart van de GGOR tool en moet overeenkomen
% met de officiele beschrijving daarvan door Waternet (Jan-Willem Voort)
%
% TO 110105
   
signaal  =  0.0;   % wat is in 's hemelsnaam signaal ?????
cFractieL = 0.33;  % dimensieloos, keuze verdeler
kwel_ber =    0;   % [m/d] berekende kwel
dphi     =  0.5;   % [m] verandering stijghoogte tijdens iteraties 
rest     =  1e-5;  % [m/d] afkappen als kwelverschil < 0.01 mm/d

[YR MONTH]=datevec(tne(:,1));

hLR=P.h_winter*ones(size(tne(:,1)));
hLR(MONTH>=4 & MONTH<=9) = P.h_summer;

P.D1     =    6;  % [[m] dikte van de deklaag
kD       =  P.k * P.D1;
c        =  P.c;
mu       =  P.mu;
Kwel     =  P.q;
phi      =  P.phi;

L        =  P.L;
lambda=sqrt(kD*c); % [m] karakteristieke lengte grondwatersysteem

%% Dit is niet goed want niet dimensieloos TO !!  Dimensie Mu C = dagen, de 1 zou dus de dag tijdstap kunnen zijn      
f = 1/(1+mu*c/Dt*(1-2*lambda/b*(cosh(b/lambda)-1)/(cosh(b/lambda)*sinh(b/lambda))));

Kwel = Kwel * 1000; % getal is arbitrair en garandeert dat je veel iteraties nodig hebt.

for iteratie=1:200
    for i=1:lenght(tne)

        nn = phi/c-hLR/c/(cosh(b/lambda)-1);

        signaal =  min(signaal + f*(tne(i,2)-tne(i,3)-signaal),nn);

        phia = (signaal*c+phi);

        extreem = (hLR-phia)*(sinh(L/lambda*(1-cFractieL))+sinh(L/lambda*cFractieL))/sinh(2*b/lambda)+phia;

        if (extreem > 0)
            wegzijging = -1e5*phi/c;
        else
            wegzijging =lambda/b*(cosh(b/lambda)^2-1)/(cosh(b/lambda)*sinh(b/lambda))*(hLR-phia)/c+signaal;
        end

        kwel_ber = kwel_ber - wegzijging/10;
    end

    kwel_ber = kwel_ber / i;

    if abs(kwel_ber - Kwel) < rest 
        break;
    else                   % pas phi aan
        dphi=dphi/2;
        phi=phi-sign(kwel_ber-kwel)*dphi;
    end
end
            