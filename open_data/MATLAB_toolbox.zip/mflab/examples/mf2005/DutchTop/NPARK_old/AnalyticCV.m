function Out=AnalyticCV(tne,P)
% Out=AnalyticCV(tne,P)
%
% Analytic solution for single aquifer confined flow
% derived from Kraaijnhof van der Leur cosine approximation.
% No leakage. Specified leakage is directly subtracred from recharge.
%
% Out.solution_name = name of this analytic solution.
% Out.tne= recharge time series used
% Out.h1 = transient mean head
% Out.hx = steady head based on input of last time step
% Out.he = mean final  head based on last time step input
% Out.x  = coordinates of x-axis
%
% tne is the recharge and ET during the day. The head at the start of the
% first day (t=0) is set equal to hLR the ditch level on both sides.
%
% TO 101113 101114 101210

solution_name = '1L conv';

%% tne has [time Precip and ET]. Note that these values are during the days

Dt=[NaN; diff(tne(:,1))];  Dt(1)=Dt(2);

N=tne(:,2)-tne(:,3);

%% Initiaize solution specific

kD  = P.hk1*P.D1;
b   = P.b;
mu  = P.sy1;
q   = P.q;

T    =4*b^2*mu/(pi^2*kD);

n=14; tau  =0:Dt(1):n*T; % afgeleid n=7, 2x zo hoog voor veiligheid

hLR = ones(size(tne(:,1))) * P.h_summer; hLR(tne(:,end)==0)= P.h_winter;


h=hLR(1)+filter(BR_recharge(T,mu,tau),1,N+q)'+filter(BR_ditch(T,tau),1,hLR-hLR(1))';

dx=1; x=0:dx:b;

Out.solution_name=solution_name;
Out.clr='ko';  % black

Out.T=T; Out.b=b; Out.mu=mu; Out.kD=kD; Out.q=q; Out.hLR=hLR;

Out.tne=tne;
Out.ht =h;
Out.hx =hLR(end)+(N(end)+q)*b^2/(2*kD)*(1-(x/b).^2);
Out.he =hLR(end)+(N(end)+q)*b^2/(3*kD);
Out.x  =x;

end

function br=BR_recharge(T,mu,tau)
    N=1;
    
    n=max(30,1.5*T/diff(tau(1:2))); % afgeleide criterium bleek te zwak, 30 door experiementeren
        
    sr=(1-exp(-tau/T));

    for j=2:n
        j2=2*j-1;
        sr=sr+(1/j2)^4*(1-exp(-j2^2*tau/T));
    end

    sr=N*T/mu*8/(pi^2)*sr;

    br=diff(sr);

end

function br=BR_ditch(T,tau)
    A=1;
    
    n=max(30,1.5*T/diff(tau(1:2))); % afgeleide criterium bleek te zwak, 30 door experimenteren
     
    sr=exp(-tau/T);

    for j=2:n
        j2=2*j-1;
        sr=sr+(1/j2)^2*exp(-j2^2*tau/T);
    end

    sr=A*(1-8/(pi^2)*sr);

    br=diff(sr);

end



