function [hdl,legt,legx]=Plotout(Out,hdl,legt,legx)
% hdl=Plotout(Out,what)
%
% Universally plot result of analytical solution given in struct Out
% what is dummy argument it is used as the color of the lines of this
% solution and if empty 
%
% TO 101229


if  nargin<2
    hdl=NaN(2,1);
    
    legt={''};
    legx={''};
    
    figure; hold on; grid on;
    xlabel('time [d]');
    ylabel('head [m], elevation [m]');
    title(Out.solution_name);
    hdl(1)=gca;

    figure; hold on; grid on;
    xlabel('x [m]');
    ylabel('head [m], elevation [m]');
    title(Out.solution_name);
    hdl(2)=gca;
else
    ttl=get(hdl(1),'title'); set(ttl,'string',[get(ttl,'string') ' ' Out.solution_name]);
    ttl=get(hdl(2),'title'); set(ttl,'string',[get(ttl,'string') ' ' Out.solution_name]);    
end

if  ~exist('legt','var') || isempty(legt), legt={''}; end
if  ~exist('legx','var') || isempty(legx), legx={''}; end


nm=Out.solution_name;

plot(hdl(1),Out.tne(:,1),Out.ht(1,:), Out.clr);
legt=[legt, [nm ' ht(1)']];

if size(Out.ht,1)>1,
    plot(hdl(1),Out.tne(:,1),Out.ht(2,:),[Out.clr '--']);
    legt=[legt, [nm ' ht(2)']];      
end
 
 
% plot(hdl(1),Out.tne(:,1),Out.he(1)*ones(size(Out.tne(:,1))),[Out.clr '-.']);
% legt=[legt, [nm ' he(1)']];                     
% if size(Out.he,1)>1,
%     plot(hdl(1),Out.tne(:,1),Out.he(2)*ones(size(Out.tne(:,1))),[Out.clr ':']);
%    legt=[legt, [nm ' he(2)']];
% end
% 
if 0
    plot(hdl(2),Out.x,Out.hx(1,:), Out.clr);
    legx=[legx, [nm ' hx(1)']];
    if size(Out.hx,1)>1,
         plot(hdl(2),Out.x,Out.hx(2,:),[Out.clr '--']);
         legx=[legx, [nm ' hx(2)']];
    end
end
%
% plot(hdl(2),Out.x,Out.he(1)*ones(size(Out.x)),[Out.clr '-.']);
% legx=[legx, [nm ' he(1)']];
% if size(Out.he,1)>1,
%     plot(hdl(2),Out.x,Out.he(2)*ones(size(Out.x)),[Out.clr ':' ]);
%     legx=[legx, [nm ' he(2)']];
% end

if nargin<2, legt=legt(2:end); legx=legx(2:end); end

