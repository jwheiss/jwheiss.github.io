function Out=Analytic01(tne,P)
% Out=Analytic01(tne,P)
%
% Analytic solution for single aquifer confined flow
% No leakage. Specified leakage is directly subtracred from recharge.
%
% Out.solution_name = name of this analytic solution.
% Out.tne= recharge time series used
% Out.h1 = transient mean head
% Out.hx = steady head based on input of last time step
% Out.he = mean final  head based on last time step input
% Out.x  = coordinates of x-axis
%
% tne is the recharge and ET during the day. The head at the start of the
% first day (t=0) is set equal to hLR the ditch level on both sides.
%
% TO 101113 101114 101210

solution_name='Conf 1L';

%% tne has [time Precip and ET]. Note that these values are during the days

Dt=[NaN; diff(tne(:,1))];  Dt(1)=Dt(2);

N=tne(:,2)-tne(:,3);

Nt=length(Dt);

%% Initiaize solution specific

kD  = P.hk1*P.D1;
b   = P.b;
mu  = P.sy1;
q   = P.q;

T   = b.^2*mu./(3*kD);  % characteristic tiem of this solution

hLR = ones(size(tne(:,1))) * P.h_summer; hLR(tne(:,end)==0)= P.h_winter;

h   = zeros(1,Nt);  % head change due to recharge variation

h(1)= P.hLR(1)+T./mu.*(N(1)+q)*(1-exp(-Dt(1)/T));

for it=2:length(Dt);
        
    e=exp(-Dt(it)/T);
    
    h(it)=hLR(it) +(h(1,it-1)-hLR(it)).*e + (N(it)+q).*T./mu*(1-e);
end

dx=1; x=0:dx:b;

Out.solution_name=solution_name;
Out.clr='b';

Out.T=T; Out.b=b; Out.mu=mu; Out.kD=kD; Out.q=q; Out.hLR=hLR;

Out.tne=tne;
Out.ht =h;
Out.hx =P.hLR(end)+3/2*(N(end)+q).*T./mu.*(1-(x./b).^2);
Out.he =P.hLR(end)+(N(end)+q).*T./mu;  % T includes Gamma
Out.x  =x;

