% Some multilayer solutions of Bruggeman (1999) solutions in series 710
% TO 101204

clear variables;
close all;


%% given values

b=50;

NLay=10;  % choose n layers

q  = 0.001*[5; -2; 1; -1; 3; 10; -5; 7; 1; -6];

Q  = [1; 2; 0; -3; 1; -2; 1; 2; -10; 3];

h  = [1; -1; 0; -3; 1; -2; 1; 2; -10; 3];

d  = [10; 5; 10; 10; 20; 5; 10; 10; 20; 10];

k  = [2; 2; 5; 10; 15; 1; 5; 10; 0.5; 10];        % conductivity

kD = k.*d;         % transmissivity

c  = [Inf; 10; 200; 40; 100; 5; 10; 3; 10; 20; 100];          % resistance confining beds
w  = [ 1;  5;  1;  2;   2; 3;  1; 1;  2;  1];      % entry resistance

S  = [1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3; 1e-3];

%% Derive matrices

T  = diag(kD(1:NLay));   T_m1=T^(-1);  % trasmissivity matrix
%S_m1= diag(1./S);     % storage ceofficient matrix
H   = diag(1./(k(1:NLay).*w(1:NLay))); H_m1= H^(-1); % entry resistance matrix
I  = eye(NLay);

A=-diag( 1./(kD(2:NLay  ).*c(2:NLay)),-1)+...
  +diag( 1./(kD(1:NLay  ).*c(1:NLay))+1./(kD(1:NLay).*c(2:NLay+1)), 0)+...
  -diag( 1./(kD(1:NLay-1).*c(2:NLay)),1);

A_m1=A^(-1);

sqrtA  = sqrtm(A);         sqrtA_m1= sqrtA^(-1);

sinhm=funm(b*sqrtA,@sinh); sinhm_m1=sinhm^(-1);
coshm=funm(b*sqrtA,@cosh); coshm_m1=coshm^(-1);

cS=diag(c(1:NLay).*S(1:NLay)); cS_m1=cS^(-1);

x=0:b;
t=logspace(-2,1,41);

%% Solution 710.01

% voldoet aan de differentiaalvergelijking, maar de dimensie van A klopt
% niet in de formule. At is niet dimensieloos, maar dat moet wel.

s={ 'Bruggeman (1999) Solution 710.01. Transient.';
    'n-layer system under open water with sudden rise h of its level';
    'phi=phi(t). Only vertical flow in semi-pervious layers.';
    };


AA=-diag( 1./(S(2:NLay  ).*c(2:NLay)),-1)+...
   +diag( 1./(S(1:NLay  ).*c(1:NLay))+1./(S(1:NLay).*c(2:NLay+1)), 0)+...
   -diag( 1./(S(1:NLay-1).*c(2:NLay)),1);

AA_m1=AA^(-1);

htop=h; htop(2:end)=0;

Phi=zeros(NLay,length(t));
for it=1:length(t)
    Phi(:,it)=(I-expm(-AA*t(it)))*AA_m1*cS_m1*htop(1:NLay);
end

figure; hold on; plot(t,Phi); grid on; title(s); xlabel('time [d]'); ylabel('drawdown [m]');

%% Solution 710.02

s={ 'Bruggeman (1999) Solution 710.01. Steady state.';
    'n-layer system under open water with sudden rise h of its level';
    'phi=phi(t). Only vertical flow in semi-pervious layers.';
    };

htop=h; htop(2:end)=0;

for it=1:length(t)
    Phi=AA_m1*cS_m1*htop(1:NLay);
end

plot(t([1 end]),[Phi Phi]); grid on; title(s);

%% Solution 710.12

s={ 'Bruggeman (1999) Solution 710.02. Steady state.';
    'All aquifers with open boundary. Sudden drawdown of the surface water level,';
    'which is kept constant thereafter. phi=phi(x)=drawdown';
    };

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=expm(-x(ix)*sqrtA)*h(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.12

s={ 'Bruggeman (1999) Solution 710.12. Steady state.';
    'All aquifers with open boundary. Sudden drawdown of the surface water level,';
    'which is kept constant thereafter. phi=phi(x)=drawdown';
    };

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=expm(-x(ix)*sqrtA)*h(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.13

s={ 'Bruggeman (1999) Solution 710.13. Steady state.';
    'All aquifers with open boundary. The plane at x=0 ketp at zero head.';
    'Constant vertical infiltration q into the aquifers.';
    }; % phi=phi(x)=drawdown';

x=logspace(0,3,31);

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=(I-expm(-x(ix)*sqrtA))*A_m1*T_m1*q(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.15

s= { 'Bruggeman (1999) Solution 710.14. Steady state.';
     'Fully penetrating well screens in all aquifers at x=0.';
     'Sudden discharges which are kept constant theraafter.';
    }; % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=expm(-x(ix)*sqrtA)*sqrtA_m1*T_m1*Q(1:NLay)/2;
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.16

s={ 'Bruggeman (1999) Solution 710.16. Steady state.';
    'All aquifers with open boundary with entrance resistance.';
    'Sudden drawdown of the surface water level which i kept constant thereafter.';
    }; % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=expm(-x(ix)*sqrtA)*(sqrtA+H)^(-1)*H*h(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.17

s={ 'Bruggeman (1999) Solution 710.17. Steady state.';
    'All aquifers with open boundary with entrance resistance.';
    'Constant infiltration. Zero head at x=0.'
    }; % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=(I-expm(-x(ix)*sqrtA)*(sqrtA+H)^(-1)*H)*A_m1*T_m1*q(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.18

s={ 'Bruggeman (1999) Solution 710.18. Steady state.';
    'Infiltration into aquifers with q(x)=q for |x|<b en 0 for |x|>b.';
    'Flux=0 for x=0.';
    }; % phi=phi(x)=drawdown';

x=unique([0 b logspace(0,log10(3*b),41)]); x=unique([-x x]);

bexpm  = expm(-b*sqrtA);

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    if abs(x(ix))<=b
        Phi(:,ix)=(I-funm(x(ix)*sqrtA,@cosh)*bexpm)*A_m1*T_m1*q(1:NLay);
    else
        Phi(:,ix)=expm(-abs(x(ix))*sqrtA)*sinhm*A_m1*T_m1*q(1:NLay);
    end
end

figure; plot(x,Phi); grid on; title(s);


%% Solution 710.21

s={ 'Bruggeman (1999) Solution 710.25. Steady state.';
    'Given drawdown h for x=b. Flux=0 for x=0.';
     }; % phi=phi(x)=drawdown';

x=0:b;

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=funm(x(ix)*sqrtA,@cosh)*coshm_m1*h(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);


%% Solution 710.22

s={ 'Bruggeman (1999) Solution 710.22. Steady state.';
    'Given drawdown h for x=b. Zero drawdown at x=0.';
     }; % phi=phi(x)=drawdown';

x=0:b;

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=funm(x(ix)*sqrtA,@sinh)*sinhm_m1*h(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.23

s={ 'Bruggeman (1999) Solution 710.23. Steady state.';
    'Zero head at x=b. Zero flux at x=0. Constant infitlration.';
     }; % phi=phi(x)=drawdown';

x=0:b;

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=(I-funm(x(ix)*sqrtA,@cosh)*coshm_m1)*A_m1*T_m1*q(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.24

s={ 'Bruggeman (1999) Solution 710.24. Steady state.';
    'Fully penetrating well screens in all aquifers at x=0, -b, 3b, -3b etc.';
    'Constant but different discharges q. Flux=0 for x=0.';
     }; % phi=phi(x)=drawdown';

x=0:b;

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=funm(x(ix)*sqrtA,@cosh)*sinhm_m1*sqrtA_m1*T_m1*Q(1:NLay)/2;
end

figure; plot(x,Phi); grid on; title(s);


%% Solution 710.25

s={ 'Bruggeman (1999) Solution 710.25. Steady state.';
    'Fully penetrating well screen in all aquifers in the middle of a strip with width 2b.';
    'Constant but different dischargfes q. Drawdown=0 for x=0 and x=2b.'
    }; % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=funm(x(ix)*sqrtA,@sinh)*coshm_m1*sqrtA_m1*T_m1*Q(1:NLay)/2;
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.26

s={ 'Bruggeman (1999) Solution 710.25. Steady state. ';
    'All aquifers with entrance resistances w_i to open water with a constant drawdown.';
    'Zero flux at x=0. phi=phi(x)=drawdown.'
    };

F_m1=(H_m1*sqrtA*sinhm+coshm)^(-1);
Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=funm(x(ix)*sqrtA,@cosh)*F_m1*h(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.27

s={ 'Bruggeman (1999) Solution 710.27. Steady state.';
    'All aquifers with entrance resistance w_i to oen water at x=b.';
    'Constant drawdown of the open water level. Zero drawdown at x=0.'
    }; % phi=phi(x)=drawdown';

F_m1=(H_m1*sqrtA*coshm+sinhm)^(-1);
Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=funm(x(ix)*sqrtA,@sinh)*F_m1*h(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 710.28

s={
    'Bruggeman (1999) solution 710.28. Steady state.';
    'Alle aquifers with entrance resistance w to open water at x=b.';
    'Vertical infiiltration q. Flux=0 for x=0.'
    };  % phi=phi(x)=drawdown';

F_m1=(H_m1*sqrtA*sinhm+coshm)^(-1);
Phi=zeros(NLay,length(x));
for ix=1:length(x)
    Phi(:,ix)=(I-funm(x(ix)*sqrtA,@cosh)*F_m1)*A_m1*T_m1*q(1:NLay);
end

figure; plot(x,Phi); grid on; title(s);

%% Solution 720.01

R=b;

[V,D]=eig(R*sqrtA); V_m1=V^(-1);
K0R=V*diag(besselk(0,diag(D)))*V_m1; K0R_m1=K0R^(-1);
K1R=V*diag(besselk(1,diag(D)))*V_m1; K1R_m1=K1R^(-1);
I0R=V*diag(besseli(0,diag(D)))*V_m1; I0R_m1=I0R^(-1);
I1R=V*diag(besseli(1,diag(D)))*V_m1; I1R_m1=I1R^(-1);

s={
    'Bruggeman (1999) solution 720.01. Steady state.';
    'Vertical infiiltration q(r). q(r)=q for 0<r<=R and 0 for r>R.'
    };  % phi=phi(x)=drawdown';

r=unique([b logspace(0,log10(5*b),31)]);

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    if r(ir)<=R
        Phi(:,ir)=(I-R*sqrtA*K1R*v*diag(besseli(0,d))*v_m1)*A_m1*T_m1*q(1:NLay);
    else
        Phi(:,ir)=R*I1R*v*diag(besselk(0,d))*v_m1*sqrtA_m1*T_m1*q(1:NLay);
    end
end

figure; plot(r,Phi); grid on; title(s);


%% Solution 720.03

s={
    'Bruggeman (1999) solution 720.03. Steady state.';
    'Fully penetrating wells in al aquifers at r=0.';
    'Constant but different discharges Q'
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=v*diag(besselk(0,d))*v_m1*T_m1*q(1:NLay);
end

figure; plot(r,Phi); grid on; title(s);

%% Solution 720.11

s={
    'Bruggeman (1999) solution 720.11. Steady state.';
    'All aquifers with open boundary. Constant drawdown of the open water level.'
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=v*diag(besselk(0,d))*K0R_m1*h(1:NLay);
end

figure; plot(r,Phi); grid on; title(s);


%% Solution 720.12

s={
    'Bruggeman (1999) solution 720.12. Steady state.';
    'Constant lowering of the polder level around a circular basin.';
    'Zero drawdown at r=R.'
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(I-K0R_m1*v*diag(besselk(0,d))*v_m1)*h(1:NLay);
end

figure; plot(r,Phi); grid on; title(s);

%% Solution 720.13

s={
    'Bruggeman (1999) solution 720.12. Steady state.';
    'All aquifers with open boundary and zero head at r=R. Constant infiltration q.'
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(I-K0R_m1*v*diag(besselk(0,d))*v_m1)*A_m1*T_m1*q(1:NLay);
end

figure; plot(r,Phi); grid on; title(s);

%% Solution 720.13

s={
    'Bruggeman (1999) solution 720.13. Steady state.';
    'Fully penetrating circular well screens with unilateral discharges q in all';
    'aquifers at r=R.';
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=v*diag(besselk(0,d))*v_m1*K1R_m1*sqrtA_m1*T_m1*Q(1:NLay);
end

figure; plot(r,Phi); grid on; title(s);


%% Solution 720.15

s={
    'Bruggeman (1999) solution 720.15. Steady state.';
    'All aquifers with entrance resistance w to open water with a constant drawdown h at r=R.';
    'aquifers at r=R.';
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
F_m1=(H_m1*sqrtA*K1R+K0R)^(-1);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=v*diag(besselk(0,d))*F_m1*h(1:NLay);
end

figure; hold on; plot(r(1),h(1:NLay),'o'); plot(r,Phi); grid on; title(s);

%% Solution 720.16

s={
    'Bruggeman (1999) solution 720.16. Steady state.';
    'All aquifers with entrance resistance w to open water with zero drawdown at r=R';
    'Constant lowering of the polder level around a circular basin.'
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
F_m1=(H_m1*sqrtA*K1R+K0R)^(-1);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(I-v*diag(besselk(0,d))*F_m1)*h(1:NLay);
end

figure; hold on; plot(r(1),h(1:NLay),'o'); plot(r,Phi); grid on; title(s);

%% Solution 720.17

s={
    'Bruggeman (1999) solution 720.17. Steady state.';
    'All aquifers with entrance resistance w to open water with zero drawdown at r=R';
    'Constant infiltration q.'
    };  % phi=phi(x)=drawdown';

Phi=zeros(NLay,length(r));
F_m1=(H_m1*sqrtA*K1R+K0R)^(-1);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(I-v*diag(besselk(0,d))*F_m1)*A_m1*T_m1*q(1:NLay);
end

figure; hold on; plot(r(1),h(1:NLay),'o'); plot(r,Phi); grid on; title(s);

%% Solution 720.21

s={
    'Bruggeman (1999) solution 720.21. Steady state.';
    'Given drawdown h for r=R. All aquifers with open boundary to the surface water.';
    'Flux=0 at r=0.'
    };  % phi=phi(x)=drawdown';

r=1:R;

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=v*diag(besseli(0,d))*v_m1*I0R_m1*h(1:NLay);
end

figure; hold on; plot(R,h(1:NLay),'o'); plot(r,Phi); grid on; title(s);

%% Solution 720.22

s={
    'Bruggeman (1999) solution 720.22. Steady state.';
    'All aquifers with open boundary to the surface water with zero head at r=R.';
    'Flux=0 at r=0. Constant infiltration `.'
    };  % phi=phi(x)=drawdown';

r=1:R;

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(I-v*diag(besseli(0,d))*v_m1*I0R_m1)*A_m1*T_m1*q(1:NLay);
end

figure; hold on; plot(r,Phi); grid on; title(s);

%% Solution 720.23

s={
    'Bruggeman (1999) solution 720.23. Steady state.';
    'All aquifers with entrance resistance w to open water with constant drawdown.';
    'Zero flux at r=0.'
    };  % phi=phi(x)=drawdown';

r=1:R;

Phi=zeros(NLay,length(r));
F_m1=(H_m1*sqrtA*I1R+I0R)^(-1);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=v*diag(besseli(0,d))*v_m1*F_m1*h(1:NLay);
end

figure; hold on; plot(R,h(1:NLay),'o'); plot(r,Phi); grid on; title(s);

%% Solution 720.24

s={
    'Bruggeman (1999) solution 720.24. Steady state.';
    'All aquifers with entrance resistance w to open water with constant drawdown.';
    'Zero head at r=R. Zero flux at r=0. Constant infiltration q.'
    };  % phi=phi(x)=drawdown';

r=1:R;

Phi=zeros(NLay,length(r));
F_m1=(H_m1*sqrtA*I1R+I0R)^(-1);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(I-v*diag(besseli(0,d))*v_m1*F_m1)*A_m1*T_m1*q(1:NLay);
end

figure; hold on; plot(r,Phi); grid on; title(s);

%% Solution 720.31

s={
    'Bruggeman (1999) solution 720.31. Steady state.';
    'Fully penetrating wells in all aquifers at r=0.';
    'Constant but different discharges Q. Open water boundary at r=R with zero drawdown.';
    };  % phi=phi(x)=drawdown';

r=1:R;

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(v*diag(besselk(0,d))*v_m1-v*diag(besseli(0,d))*v_m1*I1R_m1*K1R)*T_m1*q(1:NLay);
end

figure; hold on; plot(r,Phi); grid on; title(s);


%% Solution 720.32

s={
    'Bruggeman (1999) solution 720.32. Steady state.';
    'Fully penetrating wells in all aquifers at r=0.';
    'Constant but different discharges Q. Closed boundary (flux=0) at r=R.';
    };  % phi=phi(x)=drawdown';

r=1:R;

Phi=zeros(NLay,length(r));
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(v*diag(besselk(0,d))*v_m1+v*diag(besseli(0,d))*v_m1*I1R_m1*K1R)*T_m1*q(1:NLay);
end

figure; hold on; plot(r,Phi); grid on; title(s);

%% Solution 720.33

s={
    'Bruggeman (1999) solution 720.33. Steady state.';
    'Fully penetrating wells in all aquifers at r=0 with constant but different discharges Q.';
    'Bunndaries with entrance resistance w to open water at r=R.'
    };  % phi=phi(x)=drawdown';

r=1:R;

Phi=zeros(NLay,length(r));
F_m1=(sqrtA*I1R+H*I0R)^(-1);
G   =(sqrtA*K1R-H*K0R);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    Phi(:,ir)=(v*diag(besselk(0,d))*v_m1+v*diag(besseli(0,d))*v_m1*F_m1*G)*T_m1*q(1:NLay);
end

figure; hold on; plot(r,Phi); grid on; title(s);

%% Solution 720.34

s={
    'Bruggeman (1999) solution 720.34. Steady state.';
    'All aquifers with fully penetrating cylindrical well screens wih radius R';
    'and constant but different discharges q. Zero flux at r=0.'
    };  % phi=phi(x)=drawdown';

r=1:2*R;

Phi=zeros(NLay,length(r));
F_m1=(sqrtA*I1R+H*I0R)^(-1);
G   =(sqrtA*K1R-H*K0R);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    if r(ir)<=R
        Phi(:,ir)=R*K0R*(v*diag(besseli(0,d))*v_m1)*T_m1*q(1:NLay);
    else
        Phi(:,ir)=R*I0R*(v*diag(besselk(0,d))*v_m1)*T_m1*q(1:NLay);
    end
end

figure; hold on; plot(r,Phi); grid on; title(s);

%% Solution 720.35

% This one needs careful check ! May be Bruggeman constains error.

s={
    'Bruggeman (1999) solution 720.35. Steady state.';
    'Circular polder with radius R, surrounded by a polder wiht different leel, or isolated';
    'reservoir in open water.'
    };  % phi=phi(x)=drawdown';

r=unique([R logspace(0,log10(300),41)]);

h1=h(1:NLay); h1(2:end)=0;
h2=h(1:NLay); h2(1:end)=0;

Phi=zeros(NLay,length(r));
F_m1=(sqrtA*I1R+H*I0R)^(-1);
G   =(sqrtA*K1R-H*K0R);
for ir=1:length(r)
    [v,d]=eig(r(ir)*sqrtA); v_m1=v^(-1); d=diag(d);
    if r(ir)<=R
        Phi(:,ir)=(I-R*sqrtA*K1R*(v*diag(besseli(0,d))*v_m1))*h1;
    else
        Phi(:,ir)=   R*sqrtA*I1R*(v*diag(besselk(0,d))*v_m1)*h1;
    end
end

figure; hold on; plot(r,Phi); grid on; title(s);
