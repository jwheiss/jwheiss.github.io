function [Out,Phi]=Analytic03(tne,P)
% [Out,Phi]=Analytic03(tne,P,iy);  % XSection iy from database
%
% This is in fact a numerical solution, which we use to verify the analytic
% ones. This finite differnce solution mimics the 2Layer analytic solution.
%
% Out.solution_name = name of this analytic solution.
% Out.tne= recharge time series used
% Out.ht = transient mean head
% Out.hx = steady head based on input of last time step
% Out.he = mean final  head based on last time step input
% Out.x  = coordinates of x-axis
%
% tne is the recharge and ET during the day. The head at the start of the
% first day (t=0) is set equal to hLR the ditch level on both sides.
%
% TO 101113 101114 101210

solution_name = 'fdm2t';

%% tne has [time Precip and ET]. Note that these values are during the days

Dt=[NaN; diff(tne(:,1))];  Dt(1)=Dt(2); Nt=length(tne(:,1));

N=tne(:,2)-tne(:,3);

%% Model grid
t=tne(:,1);

dx  =1;
xGr = [0.01 0:dx:P.b];

z0 = P.h_mean;
z1 = z0-P.D1;
z2 = z1-P.D2;
yGr=[z0; z1; z2];

[xGr,yGr,xm,~,Dx,~,Nx,Ny]=modelsize(xGr,yGr);

Kx=zeros(Ny,Nx); 
Ky=zeros(Ny,Nx);

Ss=zeros(Ny,Nx);

Kx(1,:)=P.hk1; Ky(1,:)=P.vk1;
Kx(2,:)=P.hk2; Ky(2,:)=P.vk2;

%% Entry resistances
Kx(1,1)=Dx(1)/2/P.w1;
Kx(2,1)=Dx(1)/2/P.w2;

%% Specific elastic storage
Ss(1,:)=P.sy1/P.D1;
Ss(2,:)=P.S2/P.D2;

%% Initial and boundary conditions

hLR=ones(size(tne(:,1))) * P.h_summer; hLR(tne(:,end)==0)= P.h_winter;

IH = ones (Ny,Nx)*hLR(1);

IBOUND = ones(size(IH)); IBOUND(:,1)=-1;

FQ = zeros(Ny,Nx); FQ(1,:)=Dx.*N(1); FQ(2,:)=Dx.*P.q; % nicely divided along the cross section
Phi= zeros(Ny,Nx,Nt);

FI=fdm2t(xGr,yGr,t(1:2),Kx,Ky,Ss,IBOUND,IH,FQ); % compute end of first day separately
Phi(:,:,1)=FI(:,:,end);
for it=2:length(Dt);
    FQ(1,:)=Dx.*N(it);    
    FI=fdm2t(xGr,yGr,t([it-1,it]),Kx,Ky,Ss,IBOUND,FI(:,:,end),FQ);
    Phi(:,:,it)=FI(:,:,end);
end

du=ones(Ny,1)*(Dx/sum(Dx)); du=repmat(du,[1,1,Nt]);

Out.solution_name=solution_name;
Out.clr='g';  % green
Out.tne=  tne;

Out.b=P.b;   Out.k=[P.hk1;P.hk2]; Out.D=[P.D1;P.D2]; Out.c=P.c;
Out.mu=[P.sy1;P.S2]; Out.q=P.q;   Out.w=[P.w1;P.w2]; Out.hLR=hLR;

Out.ht =  squeeze(sum(Phi.*du,2));

hx=  fdm2(xGr,yGr,Kx,Ky,IBOUND,IH,FQ);

Out.hx = hx(:,end:-1:2);
Out.he = sum(Out.hx.*(ones(Ny,1)*(Dx(end:-1:2)/sum(Dx(end:-1:2)))),2);
Out.x  = P.b-xm(end:-1:2);





