function [Out1,Out2,Out3]=solveNLay(t,h,flag,S_m1,TAB,tne,q,hLR)
% [Out1,Out2,Out3]=solveNLay(t,h,flag,S_m1,TAB,tne,q,hLR)
% Ode file to integrate joined ordinary differential equations
% deriving from multilayer solutions
%
% TO 101211
%
    if isempty(flag)
        it=find(tne(:,1)>=t,1,'first');
        N=tne(it,2)-tne(it,3);
        Out1=S_m1*([N;q]-TAB*(h-hLR(it)));
        Out2=[];
        Out3=[];
    else
        error(['Unknown flag ''' flag '''.']);
    end
end