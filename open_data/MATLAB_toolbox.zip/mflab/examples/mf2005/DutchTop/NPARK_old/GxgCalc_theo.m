%''********************************************************************************************************************
%  uit GXGCalc.py
%
%*********************************************************************************************************************'''

 
function Bereken(tne,P)
    
    %self,c,L,fi0,K,ZP,WP,FP,MV,Mu,Wvp,beginjaar,eindjaar)
    % Waarom zet die jongen hiern niet wat er berekend wordt !!!!!!
    
    signaal  =  0.0;   % wat is in 's hemelsnaam signaal ?????
    cFractieL = 0.33;  % dimensieloos, keuze verdeler
    kwel_ber =    0;   % [mm/d] berekende kwel
    dphi     =  0.5;   % [m] verandering stijghoogte tijdens iteraties 
    rest     =  1e-5;  % [mm/d] afkappen als kwelverschil < 0.01 mm/d
    
    [YR MONTH]=datevec(tne(:,1);

    hLR=P.h_winter*ones(size(tne(:,1)));
    hLR(MONTH>=4 & MONTH<=9) = P.h_summer;
    
    P.D1     =     6;  % [[m] dikte van de deklaag
    kD       =  P.k * P.D1;
    c        =  P.c;
    mu       =  P.mu;
    Kwel     =  P.q;
    fi0      =  P.phi;

    L        =  P.L;
    lambda=sqrt(kD*c); % [m] karakteristieke lengte grondwatersysteem

    %% Dit is niet goed want niet dimensieloos TO !!  Dimensie Mu C = dagen, de 1 zou dus de dag tijdstap kunnen zijn      
    f = 1/(-2*mu*c*lambda/L*(cosh(L/lambda)-1)/sinh(L/lambda) + mu*c+1);
    
    Kwel = Kwel * 1000; % getal is arbitrair en garandeert dat je veel iteraties nodig hebt.

    for iteratie=1:200
        for i=1:lenght(tne)
            
            nn = (kD*(-fi0)*sinh(L/lambda)-2*kD/lambda^2*(peil-fi0)*sinh(L/(2*lambda)))/...
                (sinh(L/lambda)-2*sinh(L/(2*lambda)));

            signaal =  min(signaal + f*(tne(i,2)-tne(i,3)-signaal),nn);
            
            fi0a = kD*(signaal*c+fi0);
            
            extreem = (...
                ((kD*hLR(i)-fi0a)*sinh(L/lambda*(1-cFractieL))+(kD*hLR(i)-fi0a)*sinh(L/lambda*cFractieL))/...
                       sinh(L/lambda)+fi0a...
                       )/kD;
                   
            if (extreem > 0)
                wegzijging = -1e5*fi0/c;
            else
                wegzijging =(1/lambda*(cosh(L/lambda)-1)/sinh(L/lambda)*(2*kD*hLR(i)-2*fi0a)+signaal*L)*10000/L;
            end
            
            kwel_ber = kwel_ber - wegzijging/10;
        end

        kwel_ber = kwel_ber / i;

        % controleren of klaar anders verkleinen van de stap    
        if abs(kwel_ber - Kwel) < rest 
            break;
        else                   % pas phi aan
            dfi0=dfi0/2
            fi0=fi0-sign(kwel_ber-kwel)*dfi0;
        end
    end

    % als de iteratie gelukt is dan Gxg bepalen
end
            