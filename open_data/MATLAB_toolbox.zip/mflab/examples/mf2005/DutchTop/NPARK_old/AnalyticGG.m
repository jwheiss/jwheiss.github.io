function Out=AnalyticGG(tne,P)
% Out=AnalyticGG(tne,P)
%
% Analytic solution for single aquifer on top of semi-confined aquifer separated
% by leaking semi-confined bed with given supply in second aquifer.
% As applied in the GGOR-tool bij Waternet (till 2011)
%
% Out.solution_name = name of this analytic solution
% Out.tne  = intput time series
% Out.h    = transient mean head
% Out.hx   = steadh head
% Out.he   = mean final head
% Out.x    = grid coordinates of cross section
%
% Analytical solutions both have constant layer thickness and prescribed
% upward flux through the confining bed.
%
% tne is the recharge and ET during the day. The head at the start of the
% first day (t=0) is set equal to hLR the ditch level on both sides.
%
% TO 101113 101114 110106

solution_name='GGOR';

%% tne has [time Precip and ET]. Note that these values are during the days

Dt=[NaN; diff(tne(:,1))];  Dt(1)=Dt(2);

N=tne(:,2)-tne(:,3);

Nt=length(Dt);

%% Initiaize solution specific

GGOR=1; % or - of regular simulaton is desired

EPS=0.9; EPS_m1=1/EPS; % implicitness

kD  = [P.hk1]'.*[P.D1]';
c   = [P.c]';
b   = [P.b]';
mu  = [P.sy1]';
q   = [P.q]';

lambda=sqrt(kD.*c);

gamma=b./lambda;

Lambda=tanh(gamma)./(gamma);

Gamma=(3./gamma.^2).*(1-Lambda)./Lambda;

F = Lambda./(1-Lambda);

T  =b.^2.*mu./(3.*kD).*Gamma;
    
h     =zeros(length(P),Nt);  % head change due to recharge variation

Up=ones(size(P));

if tne(1,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end

Fmuc=c.*mu/Dt(1);

if ~GGOR
    h(:,1) =hLR+T./mu.*(Up*N(1)+q).*(1-exp(-Dt(1)./T));
else
    h(:,1) =EPS_m1*(hLR.*Fmuc+hLR.*F+c.*(Up*N(1)+q))./(F+Fmuc)+(1-EPS_m1)*hLR;
end

for it=2:length(Dt);
    if tne(it,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end
    
    if ~GGOR
        e=exp(-Dt(it)./T);
        h(:,it)=hLR +(h(:,it-1)-hLR).*e + (Up*N(it)+q).*T./mu.*(1-e);
    else
        Fmuc=c.*mu/Dt(it);
        h(:,it)=EPS_m1*(h(:,it-1).*Fmuc+hLR.*F+c.*(Up*N(it)+q) )./(F+Fmuc)+(1-EPS_m1)*h(:,it-1);
    end
end

%% head in second aqufier based on seepage
%h(2,:)=h(1,:)+q.*c;

%% steady state
dx=1; x=0:dx:b(1);

Out.solution_name=solution_name;
Out.clr='bo';  % cyan

Out.T=T; Out.b=b; Out.mu=mu; Out.kD=kD; Out.q=q; Out.hLR=hLR; Out.c=c; Out.lambda=lambda; Out.Gamma=Gamma;

Out.tne  =tne;
Out.ht   =h;
Out.he   =hLR+(tne(end,2)+q).*T./mu;
Out.hx   =[];  % hLR+(tne(end,2)+q).*c./Lambda.*(1-cosh(x./lambda)./cosh(gamma));
Out.x    = x;

