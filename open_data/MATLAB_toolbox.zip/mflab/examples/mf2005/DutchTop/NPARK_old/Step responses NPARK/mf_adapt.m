
% Data file with GxG from GGOR tool of Watenet
% 
% GxG from GGOR tool with normal recharge input
% GxG from GGOR tool with 10 mm/d step response
% GxG from GGOR tool with  0 mm/d input
%
% TO 110105
%
% Copyright 2009 2010 Theo Olsthoorn, TU-Delft and Waternet, without any warranty
% under free software foundation GNU license version 3 or later


clear variables; close all;

basename='NPARK';  % Data for Noodererpark, near Utrecht Nettherlands

%% Read meteo time series

fid=fopen('../PE-92-00.txt','r');
A=fscanf(fid,'%d-%d-%d %f %f',[5,Inf])';
fclose(fid);

tne=[datenum(A(:,3),A(:,2),A(:,1)),A(:,[4 5])/1000,NaN(size(A(:,1)))]; % [t P N isSummer] % to mm/d

fprintf('Length of time series = %d\n',length(tne(:,1)));
%plot(tne(:,1),tne(:,2),'b',tne(:,1),tne(:,3),'r');

[YR,MONTH]=datevec(tne(:,1)');

tne(:,end)= MONTH>=4 & MONTH<=9;

% debug
tne(:,2)=0.01; tne(:,3)=0;

clear A;

%% Get data from GGOR basis data spreadsheet (should be database)

data=dbfread(basename);

%fieldnames={data.fieldname};

%fnms={ 'GLGref', 'GVGref', 'GHGref',  'GLGstep', 'GVGstep', 'GHGstep', 'GLGnul', 'GVGnul', 'GHGnul'};

%I=strmatchi('FID',fieldnames);
%for i=1:length(fnms)
%    I=[I; strmatchi(fnms{i},fieldnames,'exact')];
%end
%
%data=data(:,I);

parnams=deblank({data.fieldname});

FID2=data(strmatchi('FID2'  ,parnams,'exact')).values;
GP = data(strmatchi('GP_ACT',parnams,'exact')).values;  GP=round(100*GP)/100; % average phreatic head
ZP = data(strmatchi('ZP_ACT',parnams  )).values;  ZP=round(100*ZP)/100; % summer ditch level
WP = data(strmatchi('WP_ACT',parnams  )).values;  WP=round(100*WP)/100; % winter dithc level
L  = data(strmatchi('L', parnams,'exact'  )).values;  L(L<20)=20; L =round(L);          % width of parcels
XC = data(strmatchi('XC',parnams,'exact'  )).values;  XC=round(XC);         % parcel center x
YC = data(strmatchi('YC',parnams,'exact'  )).values;  YC=round(YC);         % parcel center y
K  = data(strmatchi('K' ,parnams,'exact'  )).values;  K =round(10*K)/10;    % parcel hor k
MU = data(strmatchi('MU',parnams,'exact'  )).values;  MU=round(100*MU)/100; % parcel Sy
C  = data(strmatchi('C_TRIW5',  parnams     )).values;  C(C>1000)=1000; C =round(C);          % parcel resistance (k_vert/d)
q  = data(strmatchi('QKW1',   parnams     )).values;  q(isnan(q))=0;        % upward seepage
phi= data(strmatchi('PHI2',   parnams     )).values; phi(abs(phi)>10)=0; phi=round(phi*1000)/1000; % head in regional aquifer
AHN= data(strmatchi('AHNMEDCOR',parnams     )).values; AHN(abs(AHN)>10)=0; AHN=round(AHN*1000)/1000; % ground elevations
AREA=data(strmatchi('AREA',   parnams     )).values;
DDEK= data(strmatchi('DIKTE_DEK',parnams  )).values; % thickness of cover layer

GLGNEW=data(strmatchi('GLGNEW',parnams    )).values; GLGDBF=round(100*GLGNEW)/100; % rounded from database
GHGNEW=data(strmatchi('GHGNEW',parnams    )).values; GHGDBF=round(100*GHGNEW)/100; % rounded from database
GVGNEW=data(strmatchi('GVGNEW',parnams    )).values; GVGDBF=round(100*GVGNEW)/100; % rounded from database

%GLGref=data(strmatchi('GLGref',parnams    )).values; GLGDBF=round(100*GLGDBF)/100; % rounded from database
%GHGref=data(strmatchi('GHGref',parnams    )).values; GHGDBF=round(100*GHGDBF)/100; % rounded from database
%GVGref=data(strmatchi('GVGref',parnams    )).values; GVGDBF=round(100*GVGDBF)/100; % rounded from database

% GLGstep=data(strmatchi('GLGstep',parnams    )).values; GLGDBF=round(100*GLGstep)/100; % rounded from database
% GHGstep=data(strmatchi('GHGstep',parnams    )).values; GHGDBF=round(100*GHGstep)/100; % rounded from database
% GVGstep=data(strmatchi('GVGstep',parnams    )).values; GVGDBF=round(100*GVGstep)/100; % rounded from database

% GLGnul=data(strmatchi('GLGnul',parnams    )).values; GLGDBF=round(100*GLGnul)/100; % rounded from database
% GHGnul=data(strmatchi('GHGnul',parnams    )).values; GHGDBF=round(100*GHGnul)/100; % rounded from database
% GVGnul=data(strmatchi('GVGnul',parnams    )).values; GVGDBF=round(100*GVGnul)/100; % rounded from database

% kwel_0 =data(strmatchi('kwel_0' ,parnams    )).values; GLGDBF=round(100*GLGnul)/100; % rounded from database
% kwel_10=data(strmatchi('kwel_10',parnams    )).values; GHGDBF=round(100*GHGnul)/100; % rounded from database

% GLGNEW(GLGNEW<-5 |GLGNEW> 25)=NaN;
% GHGNEW(GHGNEW<-5 |GHGNEW> 25)=NaN;
% GVGNEW(GVGNEW<-5 |GVGNEW> 25)=NaN;

% GLGstep(GLGstep<-5 | GLGstep>10)=NaN;
% GHGstep(GHGstep<-5 | GHGstep>10)=NaN;
% GVGstep(GVGstep<-5 | GVGstep<10)=NaN;

%% Set the physical model parameters

C_DEK_MIN=1;

nRec=length(GP);

P=repmat(struct('FID2',NaN),nRec,1);
for i=1:nRec
    
    % coordinates and depth
    P(i).FID2 = FID2(i);        % [Nr] identify this Xsection in the dbase file
    P(i).b    = L(i)/2;        % [m] half parcel size between water divide and center of ditch
    P(i).area = AREA(i);       % [m2]area repersented by parcel

    P(i).x    = XC(i);          % [m] parcel center x
    P(i).y    = YC(i);          % [m] parcel center y
    P(i).AHN  = AHN(i);
    P(i).D1   = DDEK(i);        % [m] thickness of top layer
    P(i).D1   = 6;              % in huidige GGOR vast
    P(i).D2   = 30;             % [m] default D of regional aquifer

    P(i).h_mean   = GP(i);     % [NAP] average phreatic head
    P(i).h_summer = ZP(i);     % [NAP] summer phreatic head
    P(i).h_winter = WP(i);     % [NAP] winter phreatic heat
    P(i).phi      = phi(i);    % [NAP] head in regional aquifer
    
    P(i).z0   = P(i).h_mean;          % [NAP] parcel ground elevation (in case of phreatic water)
    P(i).z1   = P(i).h_mean-P(i).D1;  % [NAP] default bottom of top aquifer
    P(i).z2   = P(i).z1-P(i).D2;      % [NAP] default bottom of second, regional aquifer'

    
    % Desired highest lowest and spring groundwater level from database,
    % comptued with GGOR tool by Waternet, used here for comparison with
    % outcomes of this model
%     P(i).GHGDBF   = GHGNEW(i)+P(i).AHN; % [NAP] GGG from databse (model Ouboter)
%     P(i).GLGDBF   = GLGNEW(i)+P(i).AHN; % [NAP] GLG from databse (model Ouboter)
%     P(i).GVGDBF   = GVGNEW(i)+P(i).AHN; % [NAP] GVG from databse (model Ouboter)
%     
%     P(i).GHGstep  = GHGstep(i)+P(i).AHN; % [NAP] GGG from databse (model Ouboter)
%     P(i).GLGstep  = GLGstep(i)+P(i).AHN; % [NAP] GLG from databse (model Ouboter)
%     P(i).GVGstep  = GVGstep(i)+P(i).AHN; % [NAP] GVG from databse (model Ouboter)
% 
%     P(i).GHGnul   = GHGnul(i)+P(i).AHN; % [NAP] GGG from databse (model Ouboter)
%     P(i).GLGnul   = GLGnul(i)+P(i).AHN; % [NAP] GLG from databse (model Ouboter)
%     P(i).GVGnul   = GVGnul(i)+P(i).AHN; % [NAP] GVG from databse (model Ouboter)
    
%     P(i).kwel_0   = kwel_0(i);
%     P(i).kwel_10  = kwel_10(i);
    
    % Prescrived seepage (upward positive) between phreatic and and second
    % aquifer. This was computed with an steady-state regional model
    P(i).q = q(i);            % [m/d] vertical (upward) seepage
    
    % Hydraulic parameters, conductivities of the phreatic and second
    P(i).hk1 = K(i);          % [m/d] hor hudraulic conductivity of top layer
    P(i).hk2 = 25;            % [m/d] default k of regional aquifer
    
    P(i).c   = max(C_DEK_MIN,C(i));  % [ d ] vert resistance of top layer
        
    % Vertical conductances or anisotropies of both aquifers (depends on
    P(i).vk1      = 0.5 * P(i).D1/P(i).c; % [ - ] vert anisotropy first layer, requires layvka to be 1 in the LAY worksheet
    P(i).vk2      = P(i).hk2;       % [ - ] default vertical cond regional aquifer, require layvka=1 in the LAY worksheet
       
    ss    = 1e-5;  % default speific storage coefficient
  
    P(i).sy1 = MU(i);      % [ - ] specific yield of first layer
    P(i).S1  = MU(i);      % [ - ] confined storage coefficient (MF2005 STORAGECOEFFICIENT option)
    P(i).ss1 = ss;      % [1/m] specific storage coefficient
    P(i).sy2 = MU(i);      % [ - ] specific yield of first layer
    P(i).S2  = ss*P(i).D2; % [ - ] elastic storage coefficient layer 2 (MF2005 STORAGECOEFFICIENT option)
    P(i).ss2 = ss;      % [1/m] default elastic storativity, all layers
    
    % Drains on ground surface to simulate surface runoff
    P(i).cdr   = 0.1;          % [ d ] default drain resistance
    P(i).zdr   = P(i).AHN;     % [NAP] default drain elevation    
    
    %% Ditch properties
    P(i).cdb   = 0.01;    % [ d ] default sludge resistance
    P(i).dw    =    2;    % [ m ] default ditch width    
    P(i).dd    =  0.6;    % [ m ] default ditch depth
    P(i).zdbot = P(i).h_mean-P(i).dd; % [ m ] ditch bottom elevation
      
    if P(i).zdbot>P(i).z1       % ditch does not cut through cover layer
        P(i).Omega1 = min(P(i).dw/2+P(i).dd,P(i).h_mean-P(i).z1);
        P(i).Omega2 = 0;
        P(i).w1     = P(i).cdb*P(i).D1/P(i).Omega1;  %+2/(pi*sqrt(P.hk1*P.vk1))*log(P.D1/P.Omega1*sqrt(P.hk1/P.vk1));
        P(i).w2     = 1e8;  %+2/(pi*sqrt(P.hk2*P.vk2))*log(P.D2/P.Omega2*sqrt(P.hk2/P.vk2));
  
        P(i).vk_ditch = min(P(i).vk2, 0.5*(P(i).zdbot-P(i).z1)/P(i).D1 / P(i).c); %+ 2/(pi*sqrt(P.hk1*P.hk2))*log(2*P.D2/P.dw *sqrt(P.hk1/P.vk2));
        
    else % ditch cuts into second regional aquifer
        P(i).Omega1= P(i).h_mean - P(i).z1;
        P(i).Omega2= P(i).dw/2+(P(i).z1-P(i).zdbot);
        P(i).w1    = P(i).cdb;                % because Omega1 = total depth of first aquifer
        P(i).w2    = P(i).cdb*P(i).D2/P(i).Omega2 + ...
            2/(pi*sqrt(P(i).hk2*P(i).vk2))*log(P(i).D2/P(i).Omega2*sqrt(P(i).hk2/P(i).vk2));
        
        P(i).vk_ditch = P(i).vk2;
    end
    
if 1
    P(i).h_mean=0;
    P(i).h_winter=0;
    P(i).h_summer=0;
    P(i).q=0;
end
    
end

%% Cleanup
MINAREA=1e3;            % [m2] minimum parcel area taken into account

P=P([P.area]>=MINAREA); % Only use parcels > 1 hectare
P=P([P.b]>10);


%P=P(184);  % 1:250);
%P=P(1:50);


save P; % need this for model testing in testmdl.m

clear parnams parvals GP ZP WP L XC YC K MU C q phi AHN  % clean up unnecessary variables

%% This changes the read data into something else: a test set
%  this allows testing the code
%  comment out to bypass the test run

%mktestset;  % change data into test set
tne(:,2)=0.01; tne(:,3)=0;
verification



return;

