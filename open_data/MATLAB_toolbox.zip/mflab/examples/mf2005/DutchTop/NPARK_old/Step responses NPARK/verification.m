%% Verification of the solutions
% the different analytical solutions have been implemented in separate
% Matlab fucntions that all accept a struct holding the parameters, so that
% each solution can be run with the same parameter set en therefore easily
% mutually compared
%
% we put the results in a results struct together with their properties so
% that plotting the results on the same axis with correct legend in
% arbirary order and combinations is made easy.

%OutCV=AnalyticCV(tne,P);
%Out00=Analytic00(tne,P);
%Out01=Analytic01(tne,P);
Out02=Analytic02(tne,P);
%Out03=Analytic03(tne,P);
%Out04=Analytic04(tne,P);
%Out0n=Analytic_n(tne,P);
%Outnn=Analyticnn(tne,P);
OutGG=AnalyticGG(tne,P);


%[ax,legt,legx]=Plotout(OutCV);
%[ax,legt,legx]=Plotout(Out00,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out01);
%[ax,legt,legx]=Plotout(Out01,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out02);
%[ax,legt,legx]=Plotout(Out02,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out03);
%[ax,legt,legx]=Plotout(Out03,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out04,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out0n,ax,legt,legx);
%[ax,legt,legx]=Plotout(Outnn,ax,legt,legx);
%[ax,legt,legx]=Plotout(OutGG,ax,legt,legx);

%axes(ax(1)); legend(legt);
%axes(ax(2)); legend(legx);

%axes(ax(1));

%he=Out02.he;
ht02=Out02.ht;
htGG=OutGG.ht;
   
% [glg,gvg,ghg]=getGXG(ht,tne(:,1),2);
% 
% for iP=1:length(P);
%     P(iP).GHG=ghg(iP);
%     P(iP).GVG=gvg(iP);
%     P(iP).GLG=glg(iP);
% end


%% plot GxG from model and analytic
leg=[];

I=find([P.q]==0 | [P.q]~=0);
% stepGGOR=[P.GHGstep]-[P.GHGnul];

%%
figure; hold on; grid on;
% plot(-stepGGOR(I),'g');      leg{end+1}='GGOR implementatie Waternet';
%plot(he(I),'r');            leg{end+1}='he';
plot(ht02(I,end),'r.');                           leg{end+1}='Eindwaarde analytisch';
plot(htGG(I,end),'bo');                           leg{end+1}='Eindwaarde GGOR methode';

xlabel('Cross section number');
ylabel('head (above datum)');
title('Compare step responses van GGOR tool with analytic solution');
legend(leg);

%%
figure; hold on; grid on;
xlabel('Analytische'); ylabel('Implementatie Waternet');
% plot(ht02(I,end),-stepGGOR(I),'r.');
% plot(htGG(I,end),-stepGGOR(I),'bo');
plot([0 4],[0 4],'k');
legend('step response neerslag','lijn onder 45^o');
title('verband tussen stap response GGOR en analytische model');

%%
figure; hold on; grid on;
plot(ht02(I,end),htGG(I,end),'r.'); xlabel('Integratie analytisch'); ylabel('GGOR-methode');
plot([0 4],[0 4],'k');
legend('step response neerslag','lijn onder 45^o');
title('verband tussen stap response GGOR en analytische model');


