function Out=Analytic_n(tne,P)
% Out=Analytic02(tne,P)
%
% Analytic solution for single aquifer on top of seminconfined aquifer separated
% by leaking semi-confined bed with given supply in second aquifer.
%
% Out.solution_name = name of this analytic solution.
% Out.tne= recharge time series used
% Out.ht = transient mean head
% Out.hx = steady head based on input of last time step
% Out.he = mean final  head based on last time step input
% Out.x  = coordinates of x-axis
%
% tne is the recharge and ET during the day. The head at the start of the
% first day (t=0) is set equal to hLR the ditch level on both sides.
%
% Analytical solutions both have constant layer thickness and prescribed
% upward flux through the confining bed.
%
% TO 101113 101114 101211

solution_name = 'Semi 2L+w';

%% tne has [time Precip and ET]. Note that these values are during the days

N=tne(:,2)-tne(:,3);

%% Multilayer matrices
NLay=2;

b   = P.b;
k   = [P.hk1; P.hk2];
d   = [P.D1;  P.D2];
kD  = k.*d;

S   = [P.sy1;d(2)*P.ss2];
c   = [1e6; P.c; Inf];
q   = P.q;
w   = [P.w1; P.w2];

hLR = ones(size(tne(:,1))) * P.h_summer; hLR(tne(:,end)==0)= P.h_winter;

%% Set up matrices necessary in the analytical multilayer solution

T   =diag(kD); T_m1=T^(-1);
S   =diag(S ); S_m1=S^(-1);
H_m1=diag([k(1).*w(1); k(2).*w(2)]);

I   = eye(NLay);

A=-diag( 1./(kD(2:NLay  ).*c(2:NLay)),-1)+...
          +diag( 1./(kD(1:NLay  ).*c(1:NLay))+1./(kD(1:NLay).*c(2:NLay+1)), 0)+...
          -diag( 1./(kD(1:NLay-1).*c(2:NLay)),1);

A_m1=A^(-1);

sqrtA = sqrtm(A); sqrtA_m1=sqrtA^(-1); % sqrtA_m1= sqrtA^(-1);

sinhm=funm(b*sqrtA,@sinh); % sinhm_m1=sinhm^(-1);
coshm=funm(b*sqrtA,@cosh); % coshm_m1=coshm^(-1);

F    = (H_m1*sqrtA*sinhm+coshm);
F_m1 =F^(-1);

TAB    = T*A*(I-sqrtA_m1/b * sinhm * F_m1)^(-1);

G=S_m1*TAB; [V,D]=eig(G);

tic
[t,h]=ode45('solveNLay',tne(:,1),[hLR(1); hLR(1)],odeset,S_m1,TAB,tne,q,hLR);
toc

h=h';

%% Steady state
dx=1; x=0*dx:b;

hx=zeros(NLay,length(x));
for ix=1:length(x);
    hx(:,ix) =hLR(end)+(I-funm(x(ix)*sqrtA,@cosh)*F_m1)*A_m1*T_m1*[N(end);q];
end

Out.solution_name=solution_name;
Out.clr='r'; % red

Out.b=b; Out.k=k; Out.d=d; Our.kD=kD; Out.S=S; Our.c=c; Our.q=q; Out.w=w; Out.hLR=hLR;
Out.TConst=diag(D^(-1));

Out.tne=  tne;
Out.ht =  h;
Out.hx =  hx;
Out.he = hLR(end)+(I-sqrtA_m1./b *sinhm     *F_m1)*A_m1*T_m1*[N(end);q];
Out.x  =  x;

