%% Verification of the solutions
% the different analytical solutions have been implemented in separate
% Matlab fucntions that all accept a struct holding the parameters, so that
% each solution can be run with the same parameter set en therefore easily
% mutually compared
%
% we put the results in a results struct together with their properties so
% that plotting the results on the same axis with correct legend in
% arbirary order and combinations is made easy.

tic
%OutCV=AnalyticCV(tne,P);
%Out00=Analytic00(tne,P);
%Out01=Analytic01(tne,P);
%Out02=Analytic02(tne,P);
Out03=Analytic03(tne,P(1));
Out04=Analytic04(tne,P(1));
%Out0n=Analytic_n(tne,P);
%Outnn=Analyticnn(tne,P);
%OutGG=AnalyticGG(tne,P);
%OutWD=wideditch1(tne,P(1));

toc

%[ax,legt,legx]=Plotout(OutCV);
%[ax,legt,legx]=Plotout(Out00,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out01);
%[ax,legt,legx]=Plotout(Out01,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out02);
%[ax,legt,legx]=Plotout(Out02,ax,legt,legx);
[ax,legt,legx]=Plotout(Out03);
%[ax,legt,legx]=Plotout(Out03,ax,legt,legx);
[ax,legt,legx]=Plotout(Out04,ax,legt,legx);
%[ax,legt,legx]=Plotout(Out0n);
%[ax,legt,legx]=Plotout(Out0n,ax,legt,legx);
%[ax,legt,legx]=Plotout(Outnn,ax,legt,legx);
%[ax,legt,legx]=Plotout(OutGG,ax,legt,legx);
%[ax,legt,legx]=Plotout(OutWD,ax,legt,legx);

axes(ax(1)); legend(legt);
%axes(ax(2)); legend(legx);

axes(ax(1));

ht=Out03.ht;

if 0
[glg,gvg,ghg]=getGXG(ht,tne(:,1),2);

for iP=1:length(P);
    P(iP).GHG=ghg(iP);
    P(iP).GVG=gvg(iP);
    P(iP).GLG=glg(iP);
end

if 0 %size(ht,1)>1   
    %% plot GxG from model and analytic
    leg=[];
    figure; hold on; grid on;
    plot([P.GLGDBF],'r--'); leg{end+1}='GLGDBF';
    plot([P.GVGDBF],'g--'); leg{end+1}='GVGDBF';
    plot([P.GHGDBF],'b--'); leg{end+1}='GHGDBF';
    plot([P.GLG],'r');      leg{end+1}='GLG';
    plot([P.GVG],'g');      leg{end+1}='GVG';
    plot([P.GHG],'b');      leg{end+1}='GHG';
    xlabel('Cross section number');
    ylabel('head (above datum)');
    grid on
    title('GxG of the computed cross sections (GGOR tool, MODFLOW)');
    legend(leg);
end

end