function Out=Analyticnn(tne,P)
% Out=Analyticnn(tne,P)
%
% THIS ONE IS NOT (YET) CORRECT
%
%
% Analytic solution for single aquifer on top of seminconfined aquifer separated
% by leaking semi-confined bed with given supply in second aquifer.
%
% directly integrated using eigen values and eigen vectors
%
% Out.solution_name = name of this analytic solution.
% Out.tne= recharge time series used
% Out.ht = transient mean head
% Out.hx = steady head based on input of last time step
% Out.he = mean final  head based on last time step input
% Out.x  = coordinates of x-axis
%
% tne is the recharge and ET during the day. The head at the start of the
% first day (t=0) is set equal to hLR the ditch level on both sides.
%
% Analytical solutions both have constant layer thickness and prescribed
% upward flux through the confining bed.
%
% TO 101113 101114 101211

%error('This function is still incorrect, should not be used!');

solution_name = 'Semi 2L+w direct';

%% tne has [time Precip and ET]. Note that these values are during the days

N=tne(:,2)-tne(:,3); Nt=length(tne(:,1)); Dt=[0; diff(tne(:,1))]; Dt(1)=Dt(2);

%% Multilayer matrices

P=P(1);  % accepts only one groundwater system

NLay=2;

b   = [P.b];
k   = [P.hk1; P.hk2];
d   = [P.D1;  P.D2 ];
kD  = k.*d;

S   = [P.sy1; P.S2];
c   = [1e6; P.c; Inf];
q   = [P.q];
w   = [P.w1; P.w2];

%% Set up matrices necessary in the analytical multilayer solution

T   =diag(kD); T_m1=T^(-1);
S   =diag(S ); S_m1=S^(-1);
H_m1=diag([k(1).*w(1); k(2).*w(2)]);

I   = eye(NLay);

A=-diag( 1./(kD(2:NLay  ).*c(2:NLay)),-1)+...
          +diag( 1./(kD(1:NLay  ).*c(1:NLay))+1./(kD(1:NLay).*c(2:NLay+1)), 0)+...
          -diag( 1./(kD(1:NLay-1).*c(2:NLay)),1);

A_m1=A^(-1);

sqrtA = sqrtm(A); sqrtA_m1=sqrtA^(-1); % sqrtA_m1= sqrtA^(-1);

sinhm=funm(b*sqrtA,@sinh); % sinhm_m1=sinhm^(-1);
coshm=funm(b*sqrtA,@cosh); % coshm_m1=coshm^(-1);

F    = (H_m1*sqrtA*sinhm+coshm);
F_m1 =F^(-1);

TAB    = T*A*(I-sqrtA_m1/b * sinhm * F_m1)^(-1);


if tne(1,end), hLR = P.h_summer'; else hLR = P.h_winter; end

method=3;
switch method
    case 1  %% Diect intragtion by third order Runge Kutta method with step control  
        if tne(1,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end
        H0 =[hLR;hLR];
        
        h  =zeros(2,Nt);
        for it=1:length(Dt)

            if tne(it,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end

            dt=Dt(it); tau=0;
            while tau<Dt(it)
                f1=S_m1*([N(it);q]-TAB*(H0-hLR)); H1=H0+f1*dt/2;
                f2=S_m1*([N(it);q]-TAB*(H1-hLR)); H2=H0+dt*(2*f2-f1);
                f3=S_m1*([N(it);q]-TAB*(H2-hLR));
                H3=H0+dt*(f1+4*f2+f3)/6;
                d=dt*(f1-2*f2+f3)/6; 
                if  max(abs(d))<1e-4
                    tau=tau+dt;
                    H0=H3;
                else
                    dt=dt/2;
                end
                % fprintf('it=%4d tau=%12g dt=%12g d=%12.4g H3=%12.4g %12.4g\n',it,tau,dt,max(abs(d)),H3);        
            end

            h(:,it)=H3;
            H0=H3;
        end
    case 2 % Making the equations independent by means of eigen vectors and eigen values
        G=S_m1*TAB; [V,D]=eig(G); V_m1=V^(-1); D_m1=D^(-1);

        xi     =zeros(2,Nt);
        I=eye(2);
        e=expm(-D*Dt(1));
        theta=V_m1*S_m1*[N(1);q];
        xi(:,1)=(I-e)*D_m1*theta;

        for it=2:length(Dt);

           e=expm(-D*Dt(it));

           theta=V_m1*S_m1*[N(it);q];

           xi(:,it)=e*xi(:,it-1)+(I-e)*D_m1*theta;

           if tne(it,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end

           h(:,it)=hLR+V*xi(:,it);
        end
    case 3 % omit the step via xi
        G=S_m1*TAB; [V,D]=eig(G); V_m1=V^(-1); D_m1=D^(-1);
        R=D_m1*V_m1*S_m1;
       
        I=eye(2);
        if tne(1,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end
        h(:,1)=hLR+V*(I-expm(-D*Dt(1)))*R*[N(1);q];

        for it=2:length(Dt);

           e=expm(-D*Dt(it));

           if tne(it,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end
           h(:,it)=hLR+V*e*V_m1*(h(:,it-1)-hLR)+V*(I-e)*R*[N(it);q];
        end
  end

%% Steady state
dx=1; x=0*dx:b;

hx=zeros(NLay,length(x));
for ix=1:length(x);
    hx(:,ix) =hLR(end)+(I-funm(x(ix)*sqrtA,@cosh)*F_m1)*A_m1*T_m1*[N(end);q];
end

Out.solution_name=solution_name;
Out.clr='k'; % black

Out.b=b; Out.k=k; Out.d=d; Our.kD=kD; Out.S=S; Our.c=c; Our.q=q; Out.w=w; Out.hLR=hLR;
Out.TConst=D.^(-1);
%Out.xi=xi;

Out.tne=  tne;
Out.ht =  h;
Out.hx =  hx;
Out.he = hLR(end)+(I-sqrtA_m1./b *sinhm     *F_m1)*A_m1*T_m1*[N(end);q];
Out.x  =  x;

