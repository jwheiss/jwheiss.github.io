function Out=Analytic02(tne,P)
% Out=Analytic02(tne,P)
%
% Analytic solution for single aquifer on top of semi-confined aquifer separated
% by leaking semi-confined bed with given supply in second aquifer.
%
% Out.solution_name = name of this analytic solution
% Out.tne  = intput time series
% Out.h    = transient mean head
% Out.hx   = steadh head
% Out.he   = mean final head
% Out.x    = grid coordinates of cross section
%
% Analytical solutions both have constant layer thickness and prescribed
% upward flux through the confining bed.
%
% tne is the recharge and ET during the day. The head at the start of the
% first day (t=0) is set equal to hLR the ditch level on both sides.
%
% TO 101113 101114

solution_name='Semi 1L';

%% tne has [time Precip and ET]. Note that these values are during the days

Dt=[NaN; diff(tne(:,1))];  Dt(1)=Dt(2);

N=tne(:,2)-tne(:,3);

Nt=length(Dt);

%% Initiaize solution specific

kD  = [P.hk1]'.*[P.D1]';
c   = [P.c]';
b   = [P.b]';
mu  = [P.sy1]';
q   = [P.q]';
AHN = [P.AHN]';

lambda=sqrt(kD.*c);

gamma=b./lambda;

Lambda=tanh(gamma)./(gamma);

Gamma=(3./gamma.^2).*(1-Lambda)./Lambda;

T  =b.^2.*mu./(3*kD).*Gamma;

if tne(1,end)
    hLR = [P.h_summer]';
else
    hLR = [P.h_winter]';
end
    
    h     =zeros(length(P),Nt);  % head change due to recharge variation
Out.Qsw   =zeros(length(P),Nt);  % surface water runoff

Up=ones(size(P));

h(:,1) =hLR+T./mu.*(Up*N(1)+q).*(1-exp(-Dt(1)./T));

for it=2:length(Dt);
    
    e=exp(-Dt(it)./T);    
    if tne(it,end), hLR=[P.h_summer]'; else hLR=[P.h_winter]'; end
    h(:,it)=hLR +(h(:,it-1)-hLR).*e + (Up*N(it)+q).*T./mu.*(1-e);
    
    % tackle surface water runoff
    I=find(h(:,it)>AHN);
    if ~isempty(I), Out.Qsw(I,it)=mu(I).*(h(I,it)-AHN(I)); h(I,it)=AHN(I); end
end

%% head in second aqufier based on seepage
%h(2,:)=h(1,:)+q.*c;

%% steady state
dx=1; x=0:dx:b(1);

Out.solution_name=solution_name;
Out.clr='k';  % black

Out.T=T; Out.b=b; Out.mu=mu; Out.kD=kD; Out.q=q; Out.hLR=hLR; Out.c=c; Out.lambda=lambda; Out.Gamma=Gamma;

Out.tne  =tne;
Out.ht   =h;
Out.he   =hLR+(Up*N(end)+q).*T./mu;
Out.hx   = [];
%Out.hx   =hLR+(Up*N(end)+q).*c./Lambda.*(1-cosh((Up*x)./(lambda)./cosh(gamma));
Out.x    = x;

