function [h,Phi]=GGOR_analytic(tne,P,solution)
% [h,Phi]=GGOR_analytic(tne,P,solution)
%
% analytic solution with solution switch
%  solution=1 --> single layer top aquifer with seepage directly added to
%  recharge and effect of varying ditch level taken into account. Then the
%  second argument is the effect of varying ditch level on the average head
%  in the aquifer alone. It is included in the first total effect already
%  solution=2 --> single aquifer on top of seminconfined aquifer separated
%  by leaking semi-confined bed. The solution is symmetric, ditch level
%  same on both sides. The varying ditch levels are not included in the
%  outcome but simply imposed as boundaries on every step. The head in the
%  second aquifer has been adjusted to exactly match the prescribed upward
%  seepage. Phi is the corresponding constant head in the underlying layer
%  that makes sure the computed seepage matches the prescribedv value
%  during every time step.
%
% Analytical solutions both have constant layer thickness and prescirbed
% upward flux through the confining bed. But in the first solution this
% flux is added to the recharge immediately without any second layer
% present.
% Be aware though, that this simulation totally ignores surface runoff
% The second solution also ignores water balance effects occurring
% after the ditch level changed. Therefore the numerical and analytical
% simultaions will and must differ unless the numerical settings is set
% such that the analytical circumstances are guaranteed.
% Lastly, the analytical solution works with constant aquifer thickness (to
% avoid zero thickness in case of large downward flow.
% TO 101113 101114

%% tne has [time Precip and ET]. Note that these values are during the days
%  comprised in the times in tne. The heads well be at the end of these
%  days.
if nargin<3, solution=1; end; solution=min(2,max(1,solution));

Dt=[0; diff(tne(:,1))]; Dt(1)=Dt(2);

DV=datevec(tne(:,1)); MONTH=DV(:,2);

RECH=tne(:,2)-tne(:,3);

P=P(1);

%% Initiaize solution specific

kD=([P.hk1].*[P.D1])'; c=[P.c]'; w=[P.w]'; mu=[P.sy1]'; q=[P.q]';

switch solution
    case 1
        T  =w.^2.*mu./kD;
%        T  =(([P.w]-[P.wd]/2).^2.*[P.sy1]./([P.hk2].*[P.D2]))';
        TMU=T/3./[P.sy1]';
    case 2
        lambda=sqrt(kD*c);
        gamma=w./lambda;
        LAMBDA=tanh(gamma)./gamma;
        GAMMA=3./gamma.^2.*(gamma-tanh(gamma))./tanh(gamma);
        T=w.^2.*mu./(3*kD).*GAMMA;
        A=w.^2/(3*kD).*GAMMA;
        qc=q.*c';
end
    
%% allocate memory for s and h, initialize the first values
h     =zeros(length(P),size(tne,1));  % head change due to recharge variation
dh    =zeros(size(h));
Phi   =zeros(size(h));
    
%runoff=zeros(length(P),length(tne(:,1)));

%% Simulate analytically

for it=1:length(Dt);

    % Head due to varying ditch level alone
    if MONTH(it)>=4 && MONTH(it)<=9,
        hditch=[P.h_summer]';
    else
        hditch=[P.h_winter]';
    end
    
    if it==1, hditch0=hditch; dh0=zeros(size(hditch0)); end

    % Head change due to varying recharge and seepage alone
    switch solution
        case 1
            if it==1,
            % head above ditch level
                h(:,it)=hditch+(hditch   -hditch).*exp(-Dt(it)./(T/3)) + TMU.*(RECH(it)+[P.q]').*(1-exp(-Dt(it)./(T/3)));
               dh(:,it)=dh0       .*exp(-(pi^2/4)*Dt(it)./T)+(hditch-hditch0).*(1-exp(-(pi^2/4)*Dt(it)./T)); % due to ditch level
            else
                h(:,it)=hditch   +(h(:,it-1)-hditch).*exp(-Dt(it)./(T/3)) + TMU.*(RECH(it)+[P.q]').*(1-exp(-Dt(it)./(T/3)));
               dh(:,it)=dh(:,it-1).*exp(-(pi^2/4)*Dt(it)./T)+(hditch-hditch0).*(1-exp(-(pi^2/4)*Dt(it)./T)); % due to ditch level
            end
        case 2
            e=exp(-Dt(it)./T);
            if it==1,
                h(:,it)=hditch;
            else
                h(:,it)=hditch+(h(:,it-1)-hditch).*e+(RECH(it)+q).*A.*(1-e);
            end
            Phi(:,it)=h(:,it)+qc;            
    end
end

switch solution
    case 1
        h=h+dh;
        Phi=dh;
    case 2
        % steady state voor
        N=0.001;
        fprintf('hoverline=hditch+(N*[P.c]''+qc).*GAMMA\n');
        hoverline=hditch+(N*[P.c]'+qc).*GAMMA;
        
        ([P.c]'*RECH(it)+qc).*(1-LAMBDA)./LAMBDA.*(1-e);
        ([P.c]'*RECH(it)+qc).*(gamma-tanh(gamma))./tanh(gamma).*(1-e);
          kD=([P.hk1].*[P.D1])';
          w=[P.w]';
        (RECH(it)+[P.q])./   kD.*      (   lambda.^2).*(gamma-tanh(gamma))./tanh(gamma).*(1-e);
        (RECH(it)+[P.q])./   kD.*w.^2.*(1./gamma .^2).*(gamma-tanh(gamma))./tanh(gamma).*(1-e);
        (RECH(it)+[P.q])./3./kD.*w.^2.*(3./gamma .^2).*(gamma-tanh(gamma))./tanh(gamma).*(1-e);

end

%     if ~isempty(I),
%         runoff(I,i)=(s(I,it+1)-[P(I).z0]').*[P(I).sy1]';
%         s(I,it+1)=[P(I).z0]'-h(I,it+1);
%     end
