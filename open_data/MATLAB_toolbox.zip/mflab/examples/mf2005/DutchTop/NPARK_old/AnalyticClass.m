classdef AnalyticClass
    % TO 110713 trial to make oo from analytic
    properties
        name = 'Semi 1Layer';
        kD   % Transmissivity of aquifer 1
        c    % Resistance, taken at bottom of aquifer 1
        b    % Don't know
        mu   % phreatic storage coefficient
        q    % average upard seepage
        AHN  % ground surface elevation
    end
    properties (Dependent)
        lambda % spreading length
        Lambda %
        gamma  %
        Gamma  %
        T      % transmissivity
        hLR    % ditch level
        h      % average head in cross section
        ht     %
        hx     %
        he     %
        Qsw    %
    end
    methods
        function obj=analytic(P)
            % Constructor
            obj.kD  = [P.hk1]'.*[P.D1]';
            obj.c   = [P.c]';
            obj.b   = [P.b]';
            obj.mu  = [P.sy1]';
            obj.q   = [P.q]';
            obj.AHN = [P.AHN]';
            obj.lambda=sqrt(obj.kD.*obj.c);
            obj.gamma=obj.b./obj.lambda;
            obj.Lambda=tanh(obj.gamma)./(obj.gamma);
            obj.Gamma=(3./obj.gamma.^2).*(1-obj.Lambda)./obj.Lambda;
            obj.T  =obj.b.^2.*obj.mu./(3*obj.kD).*obj.Gamma;
        end
        function obj=simulate(obj,x,tne)
            % Simulator
            Dt=[NaN; diff(tne(:,1))];  Dt(1)=Dt(2);

            N=tne(:,2)-tne(:,3);
            Nt=length(Dt);

            if tne(1,end)
                obj.hLR = [P.h_summer]';
            else
                obj.hLR = [P.h_winter]';
            end

                obj.h     =zeros(length(P),Nt);  % head change due to recharge variation
                obj.Qsw   =zeros(length(P),Nt);  % surface water runoff

            Up=ones(size(P));

            h(:,1) =obj.hLR+obj.T./obj.mu.*(Up*N(1)+obj.q).*(1-exp(-Dt(1)./obj.T));

            for it=2:length(Dt);

                e=exp(-Dt(it)./T);    
                if tne(it,end), obj.hLR=[P.h_summer]'; else obj.hLR=[P.h_winter]'; end
                obj.h(:,it)=obj.hLR +(obj.h(:,it-1)-obj.hLR).*e + (Up*N(it)+obj.q).*obj.T./obj.mu.*(1-e);

                % tackle surface water runoff
                I=find(obj.h(:,it)>obj.AHN);
                if ~isempty(I), obj.Qsw(I,it)=obj.mu(I).*(obj.h(I,it)-obj.AHN(I)); obj.h(I,it)=obj.AHN(I); end
            end
        end
        function plot(obj)
            % Plotter
            plot(obj.t,obj.h);
        end
    end
end

dx=1; x=0:dx:b(1);


Out.he   =hLR+(Up*N(end)+q).*T./mu;

solution=analytic(P);
solution=solution.sim(x,tne)

