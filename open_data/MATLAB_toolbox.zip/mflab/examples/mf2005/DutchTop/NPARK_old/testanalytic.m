%% Testing the model using analytical solutions

test.N  = 0.002;           % [m/d] recharge
test.L  =   100;            % [ m ] width of section
test.w  = test.L/2;         % [ m ] half width of section
test.fi =  -0.6;            % [NAP] averagte ditch stage
test.phi=  -0.8;            % [NAP] head in regional aquifer
test.sy =   0.2;            % [ - ] specific yield
test.k1 =     5;            % [m/d] cond. of first aquifer
test.k2 =  3000;            % [m/d] cond. of second aquifer
test.c  =   200;            % [ d ] resistance between 1st and 2nd aquifer
test.q  =  1e-3*[-3 -2 -1 0 1 2 3];  % [m/d] upward seepage
test.q  =  1e-3*[-1];  % [m/d] upward seepage
test.z0 =     1;            % [NAP] ground surface
test.z1 =    -2;            % [NAP] bottom of covering layer (= 1st aquifer)
test.D1 = test.fi-test.z1;  % [ m ] thickness of covering layer below ditch level
test.DCBD=    1;            % [ m ] thickness of confining bed
test.D2 =    30;            % [ m ] thickness of second aquifer
test.h0 = test.fi-test.z1;  % [NAP] head at ditch above bottom of top aquifer
test.z2 = test.z1-test.DCBD;% [NAP] thickness of confining bed
test.z3 = test.z2-test.D2;  % [NAP] thickness of regional aquifer
test.A  =   0.1;            % [ m ] initial water table for transient model
test.N2=test.A/test.c;      % [m/d] recharge that will cause 1 m head
test.P =test.A*test.sy;     % [ m ] recharge pulse to create a rise of A
test.wd =     0;            % [ m ]width of ditch
test.cd =  1e-8;            % [ d ] entry resistance of ditch
test.dd =   1.0;            % [ m ] depth of ditch
test.omega= 2.0;            % [ m ]circumference of ditch

%% Read meteo time series

fid=fopen('PE-92-00.txt','r');
A=fscanf(fid,'%d-%d-%d %f %f',[5,Inf])';
fclose(fid);

tne=[datenum(A(:,3),A(:,2),A(:,1)) A(:,[4 5])/1000]; % [t P N] % to mm/d


fprintf('Length of time series = %d\n',length(tne(:,1)));
%plot(tne(:,1),tne(:,2),'b',tne(:,1),tne(:,3),'r');

clear A;


if 0 %if testmdl
    tne(:,2)=0;
    tne(1,2)=test.A*test.sy;
    tne(1000:end,2)=test.N;
    tne(:,3)=0;
end

%% mf2k has 1000 stress period limit, use mf2005 instead, see nam sheet

RECH=ones(1,1,length(tne(:,1))); RECH(1,1,:)=tne(:,2)-tne(:,3);
%EVTR=ones(1,1,length(tne(:,1))); EVTR(1,1,:)=tne(:,3);

load P;  % struct with parcel data saved by mf_adapt last run

P=P(1:length(test.q));
for i=1:length(P)
    P(i).FID2     = 0;
    P(i).w        = test.L/2;
    P(i).z0       = test.z0;
    P(i).z1       = test.z1;
    P(i).z2       = test.z1-test.DCBD;
    P(i).z3       = test.z2-test.D2;
    P(i).h_mean   = test.fi;
    P(i).h_summer = test.fi;
    P(i).h_winter = test.fi;
    P(i).phi      = test.phi;
    P(i).q        = test.q(i);
    P(i).D1       = test.fi-test.z1;
    P(i).D2       = test.D2;
    P(i).hk1      = test.k1;
    P(i).hk2      = test.k2;
    P(i).c        = test.c;
    P(i).vka1     = 10;
    P(i).vak2     = 1/3;
    P(i).vkcb     = test.DCBD/test.c;
    P(i).sy       = test.sy;
    P(i).wd       = test.wd;
    P(i).cd       = test.cd;
    P(i).dd       = test.dd;
    P(i).omega    = test.omega;
end

%% Analytische berekening GGOR met constante pakketdike en gegeven flux

 %% Compare Modflow with the GGOR aproximation
Dt=1;

lambda=sqrt([P.hk1]'.*([P.z0]'-[P.z1]').*[P.c]');
Lambda=tanh([P.w]'./lambda)./([P.w]'./lambda);   % capital Lambda !!
T=[P.c]'.*[P.sy]'.*(1-Lambda); fprintf('T=%f\n'  ,mean(T));    % time constant
nu0 =[P.h_mean]'.*Lambda./T;     fprintf('nu0=%f\n',mean(nu0));  % nu without actual recharge

s  =zeros(size(P,1),size(tne,1));  % head in the shallow aquifer
sto=zeros(size(s));   % storage
rof=zeros(size(s));   % runoff
qdi=zeros(size(s)); % q ditch out

DV=datevec(tne(:,1));  month=DV(:,2); isum=month>=4 & month<=9;
h=[P.h_winter]'*ones(1,size(tne,1));
h(:,month>=4 & month<=9)=[P.h_summer]'*ones(size(find(isum'>0)));

s(:,1)=0;                                         % start with head at ditch level

for it=2:length(tne(:,1));
%        nu=nu0+RECH(it)./[P.sy];                     % ad N/mu to nu0       
%        s(  :,it)=s(:,it-1)'.*exp(-Dt./T)+nu.*T.*(1-exp(-Dt./T)); % compute avg head in XSec at and of time step

    s(:,it)=s(:,it-1).*exp(-Dt./T) + T.*(RECH(it)+[P.q]')./[P.sy]'.*(1-exp(-Dt./T));

    rof(:,it-1)=min((s(:,it)-[P.z0]').*[P.sy]',0).*2.*[P.w]';

    s(:,it)=min(s(:,it),[P.z0]'-h(:,it));

    sto(:,it-1)=(s(:,it)-s(:,it-1)).*[P.sy]';

    qdi(:,it-1)=0.5*(s(:,it)+s(:,it-1))./([P.w]'.^2)*3.*[P.hk1]'.*[P.D1]';

    fprintf('.');
    if rem(it,100)==0, fprintf('\n'); end
end

h=h+s;

yrs=unique(DV(:,1)); yrs=yrs(2:end); % skip first year
GHG=zeros(size(P));
GLG=zeros(size(P));
GVG=zeros(size(P));
II=[];
for i=1:length(yrs)
    I=find(DV(:,1)==yrs(i) & (DV(:,3)==14 | DV(:,3)==28));
    hyr=h(:,I);
    GVG=GVG+mean(hyr(:,5:7),2);  % 14 and 28 March + 14 April
    hyr=sort(hyr,2);
    GLG=GLG+mean(hyr(:,1    :3  ),2);
    GHG=GHG+mean(hyr(:,end-2:end),2);
    II=[II;I];
end
GHG=GHG/length(yrs);
GLG=GLG/length(yrs);
GVG=GVG/length(yrs);

%% plot it
figure; hold on; grid on;
ylabel('[m NAP]'); xlabel('t [d]');
title('Dynamisch verloop van de MODFLOW- en GGOR-rekenwijze');
leg=[];


plot(tne(II,1),h(:,II));
%    plot(tne(II,1),s(:,II));
plot(tne([1 end],1),[GHG GHG],'b');
plot(tne([1 end],1),[GLG GLG],'r');
plot(tne([1 end],1),[GVG GVG],'g');

datetick('x',12);

for i=1:length(P)
    P(i).GHGanalytic=GHG(i);
    P(i).GLGanalytic=GLG(i);
    P(i).GVGanalytic=GVG(i);
end


figure; hold on;
plot(1:NROW,[P.GHGanalytic],'k'); plot(1:NROW,[P.GLGanalytic],'k'); plot(1:NROW,[P.GVGanalytic],'k');
legend(''GHGanalytic','GLGanalytic','GVGanalytic');
grid on;
xlabel('Section Nr'); ylabel('GXG [mNAP]'); title(sprintf('GXG for %s over period %d - %d',...
    basename,y(1),y(end)));






    %% Verification --- analytical formulas TO 100902

    H=readDat([basename '.hds'],'','',1); % get heads for these dates only and only layer 1

    lambda=sqrt(test.k1*test.D1*test.c);  % [ m ] spreading length, characterictic length

    clr=repmat('brgkmc',1,6);
    %% steady state phreatic
    dx=1;
    x=0:dx:test.w;  % half cross section

    %% with varying aquifer thickness
    h1=sqrt(test.h0^2+test.N/test.k1*((test.w).^2-(test.w-x).^2));
    a=sqrt(test.k1/test.N*(test.h0/test.w)^2+1);
    h1av=test.w/2*sqrt(test.N/test.k1)*(sqrt(a^2-1)+a^2*asin(1/a));

    figure; hold on; xlabel('x m'); ylabel('head NAP'); grid on
    title('water table different steady-state solutions');
    plot(x(end:-1:1),test.z1+ h1        ,'g');
    plot(x([end 1]) ,test.z1+[h1av h1av],'g');
    leg={'unconf','unconf'};

    % with fixed aquifer thickness
    h2  =  test.h0+test.N/(2*test.k1*test.D1)*(test.w^2-(test.w-x).^2);
    h2av = test.h0+2/3*test.N*test.w^2/(2*test.k1*test.D1);
    plot(x(end:-1:1),test.z1+ h2        ,'b');
    plot(x([end 1]) ,test.z1+[h2av h2av],'b');
    leg=[leg {'conf','conf'}];

    % solution with leakage

    % correct solution
    s0 =test.fi-test.phi;
    s1 =test.N*test.c-(test.N*test.c-s0)*cosh(x/lambda)/cosh(test.L/2/lambda);
    s1a=test.N*test.c-2*lambda/test.L*(test.N*test.c-s0)*tanh(test.L/2/lambda);

    plot(x         ,test.phi+ s1      ,'k');
    plot(x([1 end]),test.phi+[s1a s1a],'k');
    leg=[leg {'leak','leak'}];

    hmean=sum(H(end).values(1,:).*Dx)/sum(Dx);

    plot(xm(end)-xm ,H(end).values,'r','linewidth',2);
    plot(xm([1 end]),[hmean hmean],'r','linewidth',2);
    leg=[leg {'modflow', 'modflow'}];

    set(gca,'xlim',[0, test.w]);
    legend(leg);
    %% Transient (without leakage)

    y=reshape([H.values],H(1).NROW,H(1).NCOL,length(H)); y=squeeze(y(:,end,:)); % MODFLOW

    T=test.L^2*test.sy/(test.k1*test.D1); t05=0.07*T;
    t=0:t05:10*t05;
    Nt=length(t);
    IT=NaN(size(t)); for it=1:length(t), IT(it)=find(tne(:,1)<=t(it)+tne(1,1),1,'last'); end

    s=NaN(Nt,length(x));
    s(1,:)=test.A;
    sa=zeros(Nt,1); sa(1)=test.A;

    figure; hold on; xlabel('x [m]'); ylabel('s [m]'); title('decay of initial head');
    leg={};
    for it=2:Nt
        som=zeros(size(x));
        Dt=tne(it,1)-tne(it-1,1);
        for j=1:10
            som=som+(-1)^(j-1)/(2*j-1)*cos((2*j-1)*pi*x/test.L)*exp(-(2*j-1)^2*pi^2*t(it)/T);
        end
        s(it,:)=test.A*4/pi*som;
        sa(it)=8*test.A/pi^2*exp(-pi^2*t(it)/T);
        plot(x           ,test.fi+s(it,:)      ,clr(it));
        plot(xm(end:-1:1),H(IT(it)).values(1,:),clr(it),'linewidth',2);
        plot(x([1 end])  ,test.fi+[sa(it) sa(it)],[clr(it) '--']);
        leg{end+1}=sprintf('%.0f',t(it));
        leg{end+1}=sprintf('%.0f',t(it));
        leg{end+1}=sprintf('%.0f',t(it));  
    end
    legend(leg);

    figure; hold on; plot(t,s(:,1)+test.fi,'ro'); grid on
    xlabel('time [d]'); ylabel('h [m NAP]'); title('Decay of initial head in parcel center');

    if length(size(y))>2
        plot(t(1):t(end),y(:,1:length((t(1):t(end)))),'linewidth',1);
    else
        plot(t(1):t(end),y(1:length((t(1):t(end)))),'linewidth',1);
    end
    %% Compare Modflow with the GGOR aproximation

    figure; hold on; grid on;
    ylabel('[m NAP]'); xlabel('t [d]');
    title('Dynamisch verloop van de MODFLOW- en GGOR-rekenwijze');
    leg=[];

    sLR = test.fi - test.phi;  % s in the ditches hditch-phi
    Lambda=tanh(test.L/2/lambda)/(test.L/2/lambda);   % capital Lambda !!
    T=test.c*test.sy*(1-Lambda); fprintf('T=%f\n',T); % time constant
    nu0 =sLR*Lambda/T; fprintf('nu0=%f\n',nu0);       % nu without actual recharge

    s=NaN(size(tne(:,1)));
    s(1)=sLR;                                         % start with head at ditch level
    for it=2:length(tne(:,1));
        nu=nu0+RECH(it)/test.sy;                     % ad N/mu to nu0
        s(it)=s(it-1)*exp(-Dt/T)+nu*T*(1-exp(-Dt/T)); % compute avg head in XSec at and of time step
    end

    %t=tne(:,1)-tne(1,1)+1;
    t=tne(:,1);
    plot(t,s+test.phi,'k');   % GGOR computed heads
    leg=[leg, {'GGOR'}];

    % if 0
    %     % Add steady state values (hor line) of analytic average head in XS
    %     leg=[leg, {'Leakage steady state'}];
    %     sav=test.N*test.c+(s0-test.N*test.c)*Lambda;
    %     plot(t([1 end]),test.phi+[sav sav],'g');
    % end

    % The average upward seepage in the previous computation is

    Leakage=s/test.c;  % leakage time series computed from the previous GGOR compuation
    meanL  =mean(Leakage(:)); % average leakage
    T12=test.L^2*test.sy/(12*test.k1*(test.fi-test.z1)); % time constant

    sL1=NaN(size(s));
    sL2=NaN(size(s));
    sL1(1)=0;
    sL2(1)=0;
    for it=2:length(tne(:,1))
        Dt=tne(it,1)-tne(it-1,1);
        sL1(it)=sL1(it-1)*exp(-Dt/T12)+T12*(RECH(it)-Leakage(it))/test.sy*(1-exp(-Dt/T12));
        sL2(it)=sL2(it-1)*exp(-Dt/T12)+T12*(RECH(it)-meanL)      /test.sy*(1-exp(-Dt/T12));
    end

    plot(t,sL1+test.fi,'b');   % GGOR prescribde leakage
    plot(t,sL2+test.fi,'g');   % GGOR prescribed average leakage

    leg=[leg {'presibed leakage'}];
    leg=[leg,{'prescribed avg leakage'}];

    % plot results from MODFLOW
    h=reshape([H.values],H(1).NROW,H(1).NCOL,length(H));
    h=squeeze(mean(h(:,2:end,:),2));
    plot(t,       h,  'r');   % modflow computed heads

    leg=[leg, {'MODFLOW'}];


    % if 0  % show head in second aquifer
    %     H2=readDat([basename '.hds'],'','',2); % get heads for these dates only and only layer 1
    %     h2=reshape([H2.values],H2(1).NROW,H2(1).NCOL,length(H2));
    %     h2=squeeze(mean(h2(:,2:end,:),2));
    % 
    %     plot(t,       h2,  'c');   % modflow computed heads
    % 
    %     leg=[leg, {'MODFLOW Layer 2'}];
    % end

    % plot GXG
    for i=1:length(P)
        plot(tne([1 end],1),P(i).GLG*[1 1],'m--'); leg=[leg, {'GLG'}];
        plot(tne([1 end],1),P(i).GHG*[1 1],'c--'); leg=[leg, {'GHG'}];
        plot(tne([1 end],1),P(i).GVG*[1 1],'y--'); leg=[leg, {'GVG'}];
    end

    legend(leg); datetick;

end

