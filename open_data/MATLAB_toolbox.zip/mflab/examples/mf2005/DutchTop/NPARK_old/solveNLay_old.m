function [Out1,Out2,Out3]=solveNLay(t,h,flag,S_m1,B,tne,q,hLR)
% [Out1,Out2,Out3]=solveNLay(t,h,flag,S_m1,B,tne,q,hLR)
% Ode file to integrate joined ordinary differential equations
% deriving from multilayer solutions
%
% TO 101211
%
    if isempty(flag)
        I=find(tne(:,1)>=t,1,'first');
        N=tne(I,2)-tne(I,3);
        Out1=S_m1*([N;q]-B*(h-hLR([I I])));
    else
        switch lower(flag)
            case 'init'
                Out1=tne(:,1);
                Out2=[hLR(1); hLR(1)];
                Out3=[];
 %           case 'mass'
 %               Out1=S;
            otherwise
                error(['Unknown flag ''' flag '''.']);
        end
    end
end
