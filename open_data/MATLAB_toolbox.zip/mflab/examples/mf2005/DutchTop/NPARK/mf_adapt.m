% Dutch top system consisting of a shallow Holocene aquifer underlain by a
% semi-pervious layer on top of a larger regional aquifer. The shallow
% aquiifer is intersected by may dithces in which the surface water level
% is maintained to manage the groundwater system.
% We simulate two parallel ditches in this shallow top system underlain by
% the confining bed and the regional system. THe ditches may cut through
% the confining layer.
% Input is recharge and seepage from below through the confining bed from
% the regional aquifer. Extraction is evapotranspiration and leakage to the
% ditches. These dithches may at times also infiltrate.
% The specific yield will be made dependent on the the water table
% elevation in the shallow aquifer.
% When this water table intersects ground surface, surface runoff occurs.
% There is no limit to the infiltration capacity of the soil.
% Evapotranspiration maybe made depdendent on the extincktion depth.
% We may apply various tricks to influence the behavior of the boundary
% conditions such as more than one drainage level wiithin a single cell.
% The smallest conceivable model consists of only a single cell.
% It is sufficient to simuulate only half the strip of land between the
% ditch and its axis of symmetry at the center.
%
%
% TO 100905 101020 110715
%
% Copyright 2009 2010 Theo Olsthoorn, TU-Delft and Waternet, without any warranty
% under free software foundation GNU license version 3 or later

% JB 24032011 
% Diverse aanpassingen, zie commentaar. 

clear variables; close all;

tstart=tic;  % overall time
basename='NPARK';  % Data for Noodererpark, near Utrecht Nettherlands

%% Constants

runtest=1;

APRIL     = 4;
SEPTEMBER = 9;
C_DEK_MIN=1;       % default minimum resistance cover layer 
D_DEK_MIN=0.01;    % default minimum thickness of top layer (below ditch)

cDRAIN_DEFAULT=0.1; % default resistance drains on ground surface
iDRN    =7;    % zone nr of drains (simulate surface runoff)
iINACT  =0;    % inactive cell zone number
iDITCH1 =1;    % zone nr of ditch in layer 1
iDITCH2 =3;    % zone nr of ditch in layer 2
iWVP2   =4;    % zone nr of of regional aquifer

%% Read meteo time series

fid=fopen('PE-92-00.txt','r');
A=fscanf(fid,'%d-%d-%d %f %f',[5,Inf])';
fclose(fid);

tne=[datenum(A(:,3),A(:,2),A(:,1)) A(:,[4 5])/1000]; % [t P N] % to mm/d

fprintf('Length of time series = %d\n',length(tne(:,1)));
%plot(tne(:,1),tne(:,2),'b',tne(:,1),tne(:,3),'r');

[YR,MONTH]=datevec(tne(:,1)');

clear A;

tic

%% Get data from GGOR basis-data spreadsheet (should be database)
if ~runtest
    tic
    fprintf('\nReading in the spatial database <<%s>>, may require some patience. Please wait ...',[basename '.dbf']);

    data=dbfread(basename);
    for i=1:length(data), data(i).fieldname=deblank(data(i).fieldname); end
    fprintf('\nPfff .. Done, took me %.2f seconds.\n',toc);

    %% aliases .. replace column names

    fprintf('Turning database inside out to get a record per section, please wait ...\n');
    tic;
    aliases= {
        'AHNMED2COR' 'AHN';
        'ZP_ACT'     'ZP';
        'WP_ACT'     'WP';
        'KWEL_M_DAG' 'q';
        'DIKTE_DEK'  'DDEK';
        'K'          'hk1';
        };

    for i=1:size(aliases,1),
        j=strmatchi(aliases{i,1},{data.fieldname},'exact');
        if j>0
            data(j).fieldname=aliases{i,2};
        else
            fprintf('Can''t %s in fieldnames\n',aliases{i,1}); 
        end
    end

    NRec=length(data(1).values);

    P(NRec).FID2=NaN;  % memory allocation

    for ifld=1:length(data)
        fldnm=data(ifld).fieldname;
        if data(ifld).fieldtype=='N'
            for iRec=1:NRec
                P(iRec).(fldnm)=data(ifld).values(iRec);
            end
        end
    end

    %% Adaptations of and additions to the databasse + constants (defaults)

    for i=1:length(P)
        P(i).GP= (P(i).ZP+P(i).WP)/2;     % [ m ] Average managed ditch water level
        P(i).C  = max(C_DEK_MIN,P(i).C_DEK); % [ d ] Resistance of cover layer (>0)

        P(i).wd    = 2;           % [ m ] default width of ditch
        P(i).cex   = 0.5;         % [ d ] default exfiltration resistance
        P(i).cin   = 0.5;         % [ d ] default infiltration resistance of ditch
        P(i).dd    = 2.6;         % [ m ] default ditch depth

        P(i).width   = P(i).L/2;      % [m] half parcel width between water divide and center of ditch

        P(i).D1 = max(0.1,P(i).DDEK); % [m] thickness of top layer, min 0.1
        P(i).D2 = 30;                 % [m] default thickness of regional aquifer

        P(i).z1 = P(i).AHN-P(i).D1; % [m] bottom of top-aquifer elevation
        P(i).z2 = P(i).z1 -P(i).D2; % [m] bottom of bot-aquifer elevation

        P(i).D1effective = max(0.1,P(i).GP-P(i).z1);


        % set GXGDBF in database from ground surface to NAP datum
        P(i).GHGDBF   = P(i).GHGDBF+P(i).AHN; % [NAP] GGG from databse (model Ouboter)
        P(i).GLGDBF   = P(i).GLGDBF+P(i).AHN; % [NAP] GLG from databse (model Ouboter)
        P(i).GVGDBF   = P(i).GVGDBF+P(i).AHN; % [NAP] GVG from databse (model Ouboter)

        % Hydraulic parameters, conductivities of the phreatic and second aquifer

        %    hk1 from database, see aliases
        P(i).hk2      = 30;       % [m/d] default horizontal hydraulic conductivity of regional aquifer

        P(i).vk1      = 0.5 * P(i).D1effective/P(i).C; % [ m/d ] vertical hydraulic contuctivity of first layer, requires layvka to be 1 in the LAY worksheet
        P(i).vk2      = 0.2 * P(i).hk2;       % [ m/d ] vertical hydraulic conductivity of regional aquifer, require layvka=1 in the LAY worksheet

        P(i).S1       = 1e-4 ;         % [ - ] Storage coefficient layer 1
        P(i).S2       = 1e-5* P(i).D2; % [ - ] Storage coefficient layer 2

        P(i).zdr   = P(i).AHN;     % [NAP] default drain elevation (Ground surface elevation = AHN)

    end

    fprintf('Took %.3f seconds.\n',toc);

    tic
    fprintf('Ready to go ...\n');

    P=P(1:150);
end

%% Use only these cross sections/parcels. This is the place to reduce the size of the model
%  for instance for testing

if runtest
    [testnams,testvals,txtnams,txtvals]=getExcelData(basename,'testset','H');
    P=[]; P(size(testvals,1)).FID2=[];  % preallocate
    for i=1:size(testvals,1)
        for j=1:length(testnams)
            P(i).(testnams{j})=testvals(i,strmatchi(testnams{j},testnams,'exact'));
        end
        P(i).C  = max(C_DEK_MIN,P(i).C_DEK); % [ d ] Resistance of cover layer (>0)
    end
    if any(testvals(:,strmatchi('IsStep',testnams)))
        tne(:,3)=0;
        tne(  1: 365,2)=0;
        tne(366:3288,2)=0;
    end
end

%% Cleanup free memory

%save P; % need this for model testing in testmdl.m

clear data;

%% Model grid

dx=2;  % cell width. This is a user's choice

xGr=[P(1).wd/2 0:dx:max([P.width])]; % [m] width of model (max length of any parcel)
yGr=0:1:length(P);                   % each X-section gets its own row in the model (CHANI=0)
zGr=[0;-1;-2];                       % default zGr values, will be adjusted to actual parcel vlaues below

%% Adjust the z-values on a per parcel basis
Z=NaN(numel(yGr)-1,numel(xGr)-1,length(zGr));
for iy=1:length(P)
    Z(iy,:,1)=P(iy).AHN;   % Ground elevation
    Z(iy,:,2)=P(iy).z1;    % Bottom of first layer elevation
    Z(iy,:,3)=P(iy).z2;    % Bottom of second layer elevation
end

gr = gridObj(xGr,yGr,Z);

%% Build IBOUND using zone numbers to identify zones that are needed layer
%  address specific areas of the model like the ditch

IBOUND= gr.const(1);

for iy=1:length(P),
    % aquifer 1
    IBOUND(iy,:,1)                =iDRN;    % iDrn indicates location of drain
    IBOUND(iy,gr.xm>P(iy).width,1)=iINACT;  % inactive cells
    IBOUND(iy,gr.xm<P(iy).wd/2,1) =iDITCH1; % iDITCH1 indicates location of ditch in layer 1
    
    % aquifer 2
    IBOUND(iy,:,2)                 =iWVP2;   % iWVP2 indicates second aquifer
    IBOUND(iy,gr.xm>P(iy).width ,2)=iINACT;  % inactive cells
    IBOUND(iy,gr.xm<P(iy).wd/2,2)  =iDITCH2; % iDITCH2 indicates location of ditch in layer 2
end

IBOUND_lay1=IBOUND(:,:,1); % IBOUND for only layer 1, useful later on
IBOUND_lay2=IBOUND(:,:,2); % IBOUND for only layer 2, useful later on

%% Build model arrays

HK    =ones(size(IBOUND)); % horizontal conductivity
VK    =ones(size(IBOUND)); % use vertical conductivity not anisotropy
VKCB  =ones(size(IBOUND)); % confining bed leakance
SY    =ones(size(IBOUND)); % storage coefficient
SS    =ones(size(IBOUND)); % specific storage coefficient
STRTHD=ones(size(IBOUND)); % start head

HK(:,:,1)   =[P.hk1]' * ones(size(gr.xm));  % kh of top aquifer
HK(:,:,2)   =[P.hk2]' * ones(size(gr.xm));  % kh of bottom aquifer
VK(:,:,1)   =[P.vk1]' * ones(size(gr.xm));  % kz of top aquifer
VK(:,:,2)   =[P.vk2]' * ones(size(gr.xm));  % kz of bottom aquifer

%% Elastic storage coefficients are used instead of specific storage coefficients.
%  Therefore, STORAGECOEFFICIENT must be on and MF2005 must be
%  used (see worksheet MFLOW)
SY(:,:,1)   =[P.MU]' * ones(size(gr.xm));  % SY first aquifer
SS(:,:,1)   =[P.MU]' * ones(size(gr.xm));  % SS first aquifer
SY(:,:,2)   =[P.MU]' * ones(size(gr.xm));  % SY bottom aquifer
SS(:,:,2)   =[P.S2]' * ones(size(gr.xm));  % SS bottom aquifer

%% Start head
STRTHD(:,:,1)=[P.GP  ]'*ones(size(gr.xm));  % start head of top aquifer
STRTHD(:,:,2)=[P.PHI2]'*ones(size(gr.xm));  % start head of bottom aquifer

%% mf2k has 1000 stress period limit, use mf2005 instead, see nam sheet

RECH=ones(1,1,length(tne(:,1))); RECH(1,1,:)=tne(:,2)-tne(:,3);
%EVTR=ones(1,1,length(tne(:,1))); EVTR(1,1,:)=tne(:,3);

%% Handlling the ditch in the MODFLOW model

% Replace the top of the cover layer at the ditch by the bottm of the ditch

IDitch=find(IBOUND_lay1==iDITCH1);  % Global cell indices of ditch in layer 1
ZDitchBot=([P.GP]'-[P.dd]')*ones(1,gr.Nx); % ditch bottom elevation

Z = gr.Z;
Z1 =Z(:,:,1);                  % copy op of first layer for manipulation
Z1(IDitch)=ZDitchBot(IDitch); % replace Z(:,:,1) at ditch by ditch bottom elevation
Z(:,:,1)=Z1;                  % new op Z(:,:,1) now equals ditch bottom elevation at ditch

% lower top of second layer if needed to make sure it's below bottom of first
Z1=Z(:,:,1);
Z2=Z(:,:,2);

I = find(Z2>=Z1);

Z2(I)=Z1(I)-C_DEK_MIN;       % default minimum thickness of top layer below ditch

Z(:,:,2)=Z2;

ZDitch=Z1(IDitch);            % ZDitch for global indices IDitch

%% Drains at ground surface to compute surface runoff

IDRN=find(IBOUND_lay1==iDRN);  % Global index of drain locations
CDRN=gr.AREA./cDRAIN_DEFAULT;  % compute drain conductance
CDRN=CDRN(IDRN);               % drain conductance at IDRN

hDRN=[P.AHN]'*ones(1,gr.Nx);  % [Ny*Nx] drain head is equal to AHN, ground surface
hDRN=hDRN(IDRN);               % reset hDRN to AHN (ground surface elevation)

%% Handling infiltration and exfiltration for the ditch.
%  Use RIV and DRN in parallel to obtain a higher entry resistance than
%  exit resistance.

%% Conductances for the ditch bottoms using cex and cin separately
CEXbot=(gr.dy./[P.cex]'-gr.dy./[P.cin]')*gr.dx; % exfiltration to be handled by drn + riv
CINbot=(                gr.dy./[P.cin]')*gr.dx; % infiltration to be handled by riv alone
CEXbot =CEXbot( IDitch); % to be handled by RIV
CINbot =CINbot( IDitch); % to be handles by RIV+DRN

%% Conductance for the ditch face (inflow throug vertical face of ditch) form or to
%  the cell to the right of the right-most ditch cell.
%
% A ditch may be wide, such that several of the lest most cells of the cross
% section are covered by the ditch.
%
% We now find the cell in the cross to the right of the ditch.
Irightofditch=[IBOUND_lay1(:,1) IBOUND_lay1]; % top of IBOUND, expanded because we will differentiate next
Irightofditch(Irightofditch==iINACT)=iDRN;      % make sure we only have iDITCH1 and iDRN in IB
Irightofditch=(diff(Irightofditch,1,2)~=0);          % find ditch-face locations be differentiating with respect to x
Iright=find(Irightofditch~=0);

%% Wet circumference of the ditch
% Every cell of the model now has its Omega with generally is zero except
% of ditch cells, while ditch shore  cells have a larger omega due to
% contact across ditch face
Omega = (gr.dy.*[P.dd]')*ones(1,gr.Nx).*(Irightofditch~=0);   % vertical face area of ditch
CEXright=Omega(Iright)./[P.cex]'-Omega(Iright)./[P.cin]';
CINright=                        Omega(Iright)./[P.cin]';

%% Resistance due to partial penetration of ditch into 2nd layer
%  We assume the ditch bottom is flat at the top of the second layer. In
%  that case we can use the analytical solution for partial penetration
%  given by Huisman (1970) for this case.

cpp = vertcat(P.wd)./(pi*sqrt(vertcat(P.hk2).*vertcat(P.vk2))) ...
       .*log( (vertcat(P.D2) ./vertcat(P.wd)).* ...
              (vertcat(P.hk2)./vertcat(P.vk2)).^2 ...
         );                 % one value oper section
cpp = cpp*ones(1,gr.Nx);   % resistance of partial penetration full area 

%% Vertical conductivity, now incorporates the vertical resistance due to
%  partial penetration in the second aquifer. The resistance of the overlying
%  layer including when it cuts through its bottom is incorporated in the
%  vertical conductivity of the top layer.
H   =gr.DZ(:,:,end);           % thickness of second layer
IDitch2=IDitch+gr.Ny*gr.Nx;

VK(IDitch2)=0.5*H(IDitch)./cpp(IDitch);  % note IDitch2 and IDitch2 !!

%% Upward seepage (positive) will be divided across the cells of layer (aquifer) 2

QSeep = gr.AREA.*([P.q]'*ones(1,gr.Nx));
ISeep = find(IBOUND_lay2==iWVP2 | IBOUND_lay2==iDITCH2);
QSeep=QSeep(ISeep); % only keep the cells that are in the second aquifer

ISeep=ISeep+gr.Nxy;  % shift index ISeep of cells to that of second aquifer

%% Use the global indices to compute the Layer Row Column indices nescesary
%  to specify the boundary conditions in MODFLOW through the DRN, GHB, RIV
%  and WEL packages

LRC_drn  =cellIndices(IDRN,  size(IBOUND),'LRC'); % for surface runoff
LRC_ditch=cellIndices(IDitch,size(IBOUND),'LRC'); % for ditch bottoms
LRC_right=cellIndices(Iright,size(IBOUND),'LRC'); % sideinflow/outflow of ditches
LRC_seep =cellIndices(ISeep, size(IBOUND),'LRC'); % for seepage

uDRN   =ones(size(IDRN));   % a column of ones for easyier multiplying below
uDitch =ones(size(IDitch)); % drainage
uRight =ones(size(Iright)); % ditch side
uSeep  =ones(size(ISeep));  % seepage from second aquifer

%% We need NPER so get pervals from xls file

NPER=getPeriods(basename);

%% specify the arrays for the boundary conditions

for iPer=1:NPER

    if MONTH(iPer)>=APRIL && MONTH(iPer)<=SEPTEMBER,
        h_ditch=[P.ZP]';
    else
        h_ditch=[P.WP]';
    end
    
    h_ditch=h_ditch*ones(1,gr.Nx);
    h_ditch=h_ditch(IDitch);
    
    if iPer==1;
        DRN = [iPer*uDRN   LRC_drn   hDRN    CDRN]; % surface runoff, always
        if any(CEXbot>0)
            DRN=[DRN; ...
                 iPer*uDitch LRC_ditch h_ditch CEXbot];   % ditch discharge
        end
        if any(CEXright>0)
            DRN=[DRN; ...
                iPer*uRight LRC_right h_ditch CEXright];
        end
        RIV=[iPer*uDitch LRC_ditch h_ditch CINbot    ZDitch  ; ... % ditch infiltration
             iPer*uRight LRC_right h_ditch CINright  ZDitch ];
        WEL=[iPer*uSeep  LRC_seep  QSeep];
        continue
    end
    
    if MONTH(iPer)==MONTH(iPer-1), % use previous
        DRN=[DRN; -iPer, ones(1,5)];
        RIV=[RIV; -iPer, ones(1,6)];
    else
        if any(CEXbot>0)
            DRN=[DRN; ...
                iPer*uDitch LRC_ditch h_ditch CEXbot]; % same in as first period
        end
        if any(CEXright>0)
            DRN=[DRN;
                iPer*uRight LRC_right h_ditch CEXright];
        end
            RIV=[RIV; ...
                iPer*uDitch LRC_ditch h_ditch CINbot    ZDitch; ... % same in as first period
                iPer*uRight LRC_right h_ditch CINright  ZDitch];
    end
    WEL=[WEL; -iPer ones(1,4)]; % same as in first period (one value QSeep for entire simulation)
end

fprintf('Done in%.3f seconds.\n',toc);

%% Simulation using analytical solution with constante layer thickness and prescirbed flux
    
clr='brgkmc';

fprintf('And now let''s do it analytically ...\n');

%% To see posssible solution see legal below
ISol=[ 4 6];
ISec=1:size(testvals,1);

sol=repmat(solution(P(ISec)),size(ISol));  % create solution object for every cross section

obj=solution(); legal=obj.solutions; % legal is implemented solutions overview

tic

%% Show the requested analytical solutions for the requested cross sections ISec
fprintf('Cross sections Nr: '); fprintf(' %d',ISec); fprintf('\n');
leg=[];
GXG=0;  % boolean switch to show GXG or analyical solutions
for i=1:length(ISec)  % requested cross section numbers
    fprintf('iSec = %d -- Sol =',ISec(i));
    for j=1:length(ISol) % requeste (analyical) solutions
        fprintf(' %s(color %c)',legal{ISol(j),1},clr(j));
        sol(i,j)=sol(i,j).solve(legal{ISol(j),1},tne);
        sol(i,j)=sol(i,j).getGXG();
        if ~GXG  % Show the result of the simulated analytical solution
            if i==1 && j==1
                figure; hold on; title('analytial solutions');
                xlabel('time'); ylabel('elevation (head)');
            end
            leg{end+1}=sol(i,j).name;
            if size(sol(i,j).ht,1)==2,
                leg{end+1}=[sol(i,j).name '-2'];
            end
            sol(i,j).plott(clr(j),'-x');
        else % show the GXG
            sol(i,j).showGXG();
        end
    end
    fprintf('\n');
    if ~GXG, legend(leg); end
end

fprintf('\nDone in %.3f seconds\n',toc);

fprintf('Saving .... ');
save underneath P tne IDitch IDRN ISeep iDRN iDITCH1 iDITCH2 iWVP2 sol IBOUND_lay1 IBOUND_lay2
fprintf('\nDone !\n');
fprintf('Now generate MODFLOW input files.\n');
fprintf('Total model preparation time = %.3f seconds\n',toc(tstart));
