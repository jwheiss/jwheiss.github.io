% Dutch top system consisting of a shallow Holocene aquifer underlain by a
% semi-pervious layer on top of a larger regional aquifer. The shallow
% aquiifer is intersected by may dithces in which the surface water level
% is maintained to manage the groundwater system.
% We simulate two parallel ditches in this shallow top system underlain by
% the confining bed and the regional system. THe ditches may cut through
% the confining layer.
% Input is recharge and seepage from below through the confining bed from
% the regional aquifer. Extraction is evapotranspiration and leakage to the
% ditches. These dithches may at times also infiltrate.
% The specific yield will be made dependent on the the water table
% elevation in the shallow aquifer.
% When this water table intersects ground surface, surface runoff occurs.
% There is no limit to the infiltration capacity of the soil.
% Evapotranspiration may be made depdendent on the extincktion depth.
% We may apply various tricks to influence the behavior of the boundary
% conditions such as more than one drainage level wiithin a single cell.
% The smallest conceivable model consists of only a single cell.
% It is sufficient to simuulate only half the strip of land between the
% ditch and its axis of symmetry at the center.
%
%
% TO 100905 101021
%
% Copyright 2009 2010 Theo Olsthoorn, TU-Delft and Waternet, without any warranty
% under free software foundation GNU license version 3 or later


clear variables; close all;

basename='HSV';

%% Read meteo time series

fid=fopen('PE-92-00.txt','r');
A=fscanf(fid,'%d-%d-%d %f %f',[5,Inf])';
fclose(fid);

tne=[datenum(A(:,3),A(:,2),A(:,1)) A(:,[4 5])/1000]; % [t P N] % to mm/d

fprintf('Length of time series = %d\n',length(tne(:,1)));
%plot(tne(:,1),tne(:,2),'b',tne(:,1),tne(:,3),'r');

clear A;

%% mf2k has 1000 stress period limit, use mf2005 instead, see nam sheet

RECH=ones(1,1,length(tne(:,1))); RECH(1,1,:)=tne(:,2)-tne(:,3);
%EVTR=ones(1,1,length(tne(:,1))); EVTR(1,1,:)=tne(:,3);

%% Get data from GGOR basis data spreadsheet (should be database)

%[parnams,parvals]=getExcelData('GGOR_basisdata_Noorderpark','','Horizontal');
%[parnams,parvals]=getExcelData('GGOR_basisdata_test','','Horizontal');

data=dbfread(basename);

parnams=deblank({data.fieldname});

FID2=data(strmatchi('FID2',parnams,'exact')).values;
GP = data(strmatchi('GEMPEIL',parnams,'exact')).values;  GP=round(100*GP)/100; % average phreatic head
ZP = data(strmatchi('ZOMERPEIL' ,parnams  )).values;  ZP=round(100*ZP)/100; % summer ditch level
WP = data(strmatchi('WINTERPEIL',parnams  )).values;  WP=round(100*WP)/100; % winter dithc level
L  = data(strmatchi('L', parnams,'exact'  )).values;  L(L<20)=20; L =round(L);          % width of parcels
XC = data(strmatchi('XC',parnams,'exact'  )).values;  XC=round(XC);         % parcel center x
YC = data(strmatchi('YC',parnams,'exact'  )).values;  YC=round(YC);         % parcel center y
K  = data(strmatchi('K_NEW' ,parnams,'exact'  )).values;  K =round(10*K)/10;    % parcel hor k
MU = data(strmatchi('MU_NEW',parnams,'exact'  )).values;  MU=round(100*MU)/100; % parcel Sy
C  = data(strmatchi('C1_WL' ,parnams,'exact'  )).values;  C(C>1000)=1000; C =round(C);          % parcel resistance (k_vert/d)
q  = data(strmatchi('QKW1',parnams    )).values;  q(isnan(q))=0;        % upward seepage
phi= data(strmatchi('H1_WL_NEW',parnams,'exact' )).values; phi(abs(phi)>10)=0; phi=round(phi*1000)/1000; % head in regional aquifer
AHN= data(strmatchi('AHN_MEDCOR',parnams     )).values; AHN(abs(AHN)>10)=0; AHN=round(AHN*1000)/1000; % ground elevations
AREA=data(strmatchi('AREA',parnams        )).values;


GLGDBF=data(strmatchi('GLG_FF',parnams    )).values; GLGDBF=round(100*GLGDBF)/100; % rounded from database
GHGDBF=data(strmatchi('GHG_FF',parnams    )).values; GHGDBF=round(100*GHGDBF)/100; % rounded from database
GVGDBF=data(strmatchi('GVG_FF',parnams    )).values; GVGDBF=round(100*GVGDBF)/100; % rounded from database

GLGDBF(GLGDBF<-5)=NaN;
GHGDBF(GHGDBF<-5)=NaN;
GVGDBF(GVGDBF<-5)=NaN;

%% Set the physical model parameters

nRec=length(GP);

P=repmat(struct('FID2',NaN),nRec,1);
for i=1:nRec
    
    % coordinates and depth
    P(i).FID2=FID2(i);        % [Nr] identify this Xsection in the dbase file
    P(i).w   = L(i)/2;        % [m] half parcel size between water divide and center of ditch
    P(i).area= AREA(i);       % [m2]area repersented by parcel
 
    P(i).x  = XC(i);          % [m] parcel center x
    P(i).y  = YC(i);          % [m] parcel center y
    P(i).D1 = 6;              % [m] default thickness of top layer
    P(i).DCBD=1;              % [m] default thickness of confining bed
    P(i).D2 = 30;             % [m] default D of regional aquifer
    P(i).z0 = AHN(i);         % [NAP] parcel ground elevation
    P(i).z1 = P(i).z0-P(i).D1;% [NAP] default bottom of top aquifer
    P(i).z2 = P(i).z1-P(i).DCBD;  % [NAP] default bottom of confining bed;
    P(i).z3 = P(i).z2-P(i).D2;% [NAP] default bottom of second, regional aquifer'
    
    % heads
    P(i).h_mean   = GP(i);     % [NAP] average ditch water level
    P(i).h_summer = ZP(i);     % [NAP] average ditch summer water level
    P(i).h_winter = WP(i);     % [NAP] average ditch winter water level
    P(i).phi      = phi(i);    % [NAP] head in regional aquifer

    P(i).GHGDBF   = GHGDBF(i)+P(i).z0; % [NAP] GGG from databse (model Ouboter)
    P(i).GLGDBF   = GLGDBF(i)+P(i).z0; % [NAP] GLG from databse (model Ouboter)
    P(i).GVGDBF   = GVGDBF(i)+P(i).z0; % [NAP] GVG from databse (model Ouboter)
    
    % seepage
    P(i).q = q(i);            % [m/d] vertical (upward) seepage
    
    % yHraulic parameters
    P(i).hk1 = K(i);          % [m/d] hor hudraulic conductivity of top layer
    P(i).hk2 = 30;            % [m/d] default k of regional aquifer
    P(i).c   = C(i);          % [ d ] vert resistance of top layer
    P(i).vkcb=P(i).DCBD/P(i).c;      % [1/d] vert. conductance
    P(i).vka1= 0.001;           % [ - ] vert anisotropy first layer
    P(i).vka2= 3;           % [ - ] default vertical cond regional aquifer
    P(i).sy  = MU(i);         % [ - ]specific yield of first layer
    P(i).ss  = 1e-5;          % [1/m] default elastic storativity, all layers
    
    % Ditch
    P(i).wd    = 2;           % [ m ] default width of ditch
    P(i).cd    = 0.5;         % [ d ] default entry resistance of ditch
    P(i).dd    = 0.6;         % [ m ]default ditch depth
    P(i).omega = P(i).wd+2*P(i).dd;  % [ m ] default circumference of ditch

    % Drains simulating surface runoff
    P(i).cdr   = 0.1;         % [ d ] default drain resistance
    P(i).zdr   = P(i).z0;     % [NAP] default drain elevation    
end

MINAREA=1e3;            % [m2] minimum parcel area taken into account

P=P([P.area]>=MINAREA); % Only use parcels > 1 hectare

P=P(1:100);

clear parnams parvals GP ZP WP L XC YC K MU C q phi AHN GHGDBF GLGDBF GVGDBF   % clean up unnecessary variables


%% Model grid
dx=2;  % cell width choice

xGr=[-0.001 0:dx:round(max([P.w]))]; % [m] width of model (max length of any parcel)
yGr=0:1:length(P);                % each x-section gets its own row (CHANI=0)

Z=NaN(numel(yGr)-1,numel(xGr)-1,4);
for iy=1:length(P)
    Z(iy,:,1)=P(iy).z0;
    Z(iy,:,2)=P(iy).z1;
    Z(iy,:,3)=P(iy).z2;
    Z(iy,:,4)=P(iy).z3;
end

gr = gridObj(xGr,yGr,Z);

%% None number come useful for section from arrays layer on
iDRN  =1;    % zone of drains
iGHB  =2;    % zone of ditch
iWVP2 =3;    % zone of regional aquifer
iWEL  =4;    % zone where to dose seepage

%% Build IBOUND use zone number to identify zones

IBOUND= gr.const(1);

IBOUND(:,:,1)=iDRN;    % zone with drains (ground surface)
IBOUND(:,1,1)=iGHB;    % location of ditch
IBOUND(:,:,2)=iWVP2;   % second aquifer
IBOUND(:,1,2)=iWEL;    % location where seepage is added

%IBOUND(:,:,end)=-IBOUND(:,:,end);    % bottom aquifer fixed head

% Because the width of the cross section varies and we only model one half
% of each cross section, some cells near the water divide will be inactive
% for smaller sections. This is effected by setting IBOUND to zero for
% those cells

% cells with gr.xm>w of the section are made inactive
for iy=1:gr.Ny, IBOUND(iy,gr.xm>P(iy).w+eps,:)=0; end  % cells beyond water divide inactive

%% Build model arrays

HK    =ones(size(IBOUND));
VKA   =ones(size(IBOUND));
VKCB  =ones(size(IBOUND));
SY    =ones(size(IBOUND));
SS    =ones(size(IBOUND));
STRTHD=ones(size(IBOUND));

HK(:,:,1)    =[P.hk1]' * ones(1,gr.Nx);  % kh of top aquifer
HK(:,:,2)    =[P.hk2]' * ones(1,gr.Nx);  % kh of bottom aquifer
VKA(:,:,1)   =[P.vka1]'* ones(1,gr.Nx);  % kz of top aquifer
VKA(:,:,2)   =[P.vka2]'* ones(1,gr.Nx);  % kz of bottom aquifer
VKCB(:,:,1)  =[P.vkcb]'* ones(1,gr.Nx);  % resistance of aquitard
SS(:,:,1)    =[P.ss]'  * ones(1,gr.Nx);  % SS of top aquifer
SS(:,:,2)    =[P.ss]'  * ones(1,gr.Nx);  % SS of bottom aquifer
SY(:,:,1)    =[P.sy]'  * ones(1,gr.Nx);  % SY of top aquifer
SY(:,:,2)    =[P.sy]'  * ones(1,gr.Nx);  % SY of bottom aquifer
STRTHD(:,:,1)=[P.h_mean]' *ones(1,gr.Nx);  % start head of top aquifer
STRTHD(:,:,2)=[P.phi]' * ones(1,gr.Nx);  % start head of bottom aquifer

%% Drains at ground surface to compute surface runoff

CDRN=NaN(size(IBOUND));              % allocate memory for drain conductance
CDRN(:,:,1) = gr.AREA./([P.cdr]'*ones(1,gr.Nx));  % comptue drain conductance
CDRN(IBOUND==0)=NaN;                 % remove inactive cells
IDRN=find(~isnan(CDRN));             % get global incices of drain locations

hDRN=NaN(size(IBOUND));              % allocate memory
hDRN(:,:,1)=[P.z0]'*ones(1,gr.Nx);  % [Ny*Nx] drain head is equal to z0, ground surface

%% Head boundaries in the left-most cell to simulate the ditch

CGHB=0.5*[P.omega]'./[P.cd]'; % conductance of ditch (half circumfernce/resistance)
hGHB=[P.h_mean]';             % GHB heads in the left ditch only, whill change during stress periods
IGHB=find(IBOUND==iGHB);      % global indices of ditch

%% Wells to simulate seepage from bottom aquifer or vice versa

% The specific upward positive flux is given. We compute the total flux by 
% by multiplying this areal flux withe the area of the model
% This fulx is given and constant for all stress periods

qWEL=sum(([P.q]'*ones(1,gr.Nx)).*gr.AREA.*(IBOUND(:,:,1)>0),2);
IWEL=find(abs(IBOUND)==iWEL);     % Global indices of well

%% using the global incices compute the Layer Row Column indices necesary
%  to specify the boundary conditions in MODFLOE throuth the DRN, GHB and
%  WEL packages

LRCdrn=cellIndices(IDRN,size(IBOUND),'LRC');
LRCghb=cellIndices(IGHB,size(IBOUND),'LRC');
LRCwel=cellIndices(IWEL,size(IBOUND),'LRC');

uDRN=ones(size(IDRN)); % a column of ones for easyier multiplying below
uGHB=ones(size(IGHB)); % same
uWEL=ones(size(IWEL)); % same

%% specify the arrays for the mentioned boundary conditions so that
% mfLab can generate the input files for MODFLOW

NPER = getPeriods(basename);

[Y,M]=datevec(tne(:,1)); summer=(M>4 & M<10);

iPer=1;

if summer(iPer), h=[P.h_summer]; else h=[P.h_winter]; end  % NP heads

DRN=[iPer*uDRN LRCdrn hDRN(IDRN) CDRN(IDRN) ];
GHB=[iPer*uGHB LRCghb h' CGHB ];
WEL=[iPer*uWEL LRCwel qWEL];
for iPer=2:NPER
    if summer(iPer)==summer(iPer-1), % use previous
        GHB=[GHB; -iPer, ones(1,5)];
    else
        if summer(iPer), h=[P.h_summer]; else h=[P.h_winter]; end
        GHB=[GHB;  iPer*uGHB LRCghb h' CGHB]; % same in as first period
    end
    WEL=[WEL; -iPer ones(1,4)]; % same as in first period
    DRN=[DRN; -iPer ones(1,5)]; % same as in first period
end

%% Simulation using analytical solution with constante layer thickness and prescirbed flux

% Be aware though, that this simulation totally ignores surface runoff
% It also ignores water balance effects occurring when the ditch level is
% changed in autumn and spring. Therefore the numerical and analytical
% simultaions will and must differ unless the numerical settings is set
% such that the analytical circumstances are guaranteed.
% Lastly, the analytical solution works with constant aquifer thickness (to
% avoid zero thickness in case of large downward flow.


Dt=diff(tne(:,1));
T=([P.w].^2.*[P.sy]./(3*[P.hk1].*[P.D1]))';
TMU=T./[P.sy]';

s  =zeros(size(P,1),size(tne,1));  % head in the shallow aquifer
for it=1:length(Dt);
    s(:,it+1)=s(:,it).*exp(-Dt(it)./T) + TMU.*(RECH(it)+[P.q]').*(1-exp(-Dt(it)./T));
    fprintf('.');
    if rem(it,100)==0, fprintf('\n'); end
end
fprintf('\n');

%% Add varying ditch level

DV=datevec(tne(:,1));  month=DV(:,2);
h=[P.h_winter]'*ones(1,size(tne,1));
h(:,month>=4 & month<=9)=[P.h_summer]'*ones(size(find(month>=4 & month<=9)'));

h=h+s;

%% Compute GXG for the analytical simulation

[GLGanalytic,GVGanalytic,GHGanalytic]=getGXG(h,tne(:,1),0);

for i=1:length(P)
    P(i).GHGanalytic=GHGanalytic(i);
    P(i).GVGanalytic=GVGanalytic(i);
    P(i).GLGanalytic=GLGanalytic(i);
end

save underneath P tne

