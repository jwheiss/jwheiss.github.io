names=fieldnames(P);

for i=1:length(names), 
    fprintf('%-20s %f\n',names{i},eval(['mean([P.' names{i} '])']));
%    fprintf('%-20s %f\n',names{i},sum([P.(names{i})]));
end