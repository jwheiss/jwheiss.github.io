%% Analyzing the simulation reusult of the shallow Dtuch top system.
% TO 100823
%
% Copyright 2009 2010 Theo Olsthoorn, TU-Delft and Waternet, without any warranty
% under free software foundation GNU license version 3 or later

clear variables; close all;

load name
load(basename)
load underneath

%% Get heads of first layer to compute GxG

H=readDat([basename '.HDS'],[],[],1);  % heads of first layer only

dDYDX=(IBOUND(:,:,1)~=0).*gr.AREA; % Area of active cells
dDYDX=dDYDX./(sum(dDYDX,2)*ones(1,gr.Nx));                 % total area of cross section

h=zeros(length(P),numel(H));
for i=1:length(H)
    h(:,i)=sum(H(i).values.*dDYDX,2);
end    

[glg,gvg,ghg]=getGXG(h,tne(:,1),0);

for iP=1:length(P);
    P(iP).GHG=ghg(iP);
    P(iP).GVG=gvg(iP);
    P(iP).GLG=glg(iP);
end

%% plot GxG from model and analytic
figure; hold on
plot([P.GLGDBF],'r--');
plot([P.GVGDBF],'g--');
plot([P.GHGDBF],'b--');
plot([P.GLG],'r');
plot([P.GVG],'g');
plot([P.GHG],'b');
plot([P.GLGanalytic],'r:');
plot([P.GVGanalytic],'g:');
plot([P.GHGanalytic],'b:');
xlabel('Cross section number');
ylabel('head (above datum)');
grid on
title('GxG of the computed cross sections (GGOR tool, MODFLOW and analytical)');
legend('GLGDBF','GVGDBF','GHGDBF','GLG','GVG','GHG','GLGanalytic','GVGanalytic','GHGanalytic');

%% === water budgets ===== water budgets ===== water budgets =====


fprintf('press RETURN to continue\n');
%pause;

%% Compute budegets

userLabels={'STORAGE' 'WELLS' 'DRAINS' 'HEADDEPBOUNDS' 'RECHARGE'}; % needed for water balance

compact=0;

if compact>0
    B=readBud(['-' basename '.bgt'],userLabels); % selected cross sections for water balance
else
    B=readBud([basename '.bgt'],userLabels); % selected cross sections for water balance
end

                           %% Narrative water budgets
% The budget file has the flow terms for each flow proejct (see labels) in
% 4D, that is for each time we have a 3D array of values for each flow
% process. This is an amazing amount of data.
% First we will sum the data flow terms for every cross sections, so that
% we end up with the total of DRN, GHB ect for every cross section and time
% period. We can produce a water balance for every individual cross section
% over time from this.
% We will then be able to combine cross sections arbitrarily if we so
% desire. We may for instance compute the overall running water balance for
% the entire area by summing over all cross sections weighted by their
% area. We could do so for every process separately, to find the total
% runoff (= total DRN), total recharge total ditch discharge (= GHB) and
% total seepage (= given WEL). The combination of arabitrary subsaries into
% different subareal totals can be done, if these subareas have indices in
% the database that can be used to recognize the subareas. The data base is
% contained in the structmatrix P.

%% Terms for the water budget
% The terms of interest in this model are
% RCH  -- recharge
% GHB  -- flow from the ditches
% DRN  -- overflow (surface runoff)
% WEL  -- fixed seepage flow injected in second aquifer
% STO  == storage during time step
% to compare these and check the water balans, we may compute the values
% per unit of ground surface m/s or mm/d

%% To get the discharges of the individual cross sections per unit area
%  in m/d we first sum all flows over the entire cross section and then
%  have to divide the values by the surface area of the cross section


NSec=length(B(1).rows);    % number of cross sections in budget file
                           % same as length ISec (selected cross sections)

%% Get active area of the cross sections from IBOUND<>0 in layer 1

a = sum( (gr.dy * gr.dx) .* (IBOUND(:,:,1)~=0) ,2);

%% Allocate memory to store budget terms.
% NSec = cross section, Nt is time

Nt=size(tne,1);
QRCH=zeros(NSec,Nt);   % flow form recharge
QGHB=zeros(NSec,Nt);   % flow through the general head boundaries (to and form the ditches)
QDRN=zeros(NSec,Nt);   % flow through the drains at ground surface
QWEL=zeros(NSec,Nt);   % prescribe flow for the seeapage from or to the regional aquifer
QSTO=zeros(NSec,Nt);   % storage change during the time step

% Fill the arrays using the flow terms from the budget file.

idrn = strmatchi('DRAINS'       ,B(1).label);
irch = strmatchi('RECHARGE'     ,B(1).label);
ighb = strmatchi('HEADDEPBOUNDS',B(1).label);
isto = strmatchi('STORAGE'      ,B(1).label);
iwel = strmatchi('WELLS'        ,B(1).label);

% Sum over columns and layers to get totals for all cross sections as a
% funcion of time

if compact>0   % compact form of budget arrays X=[I V], [globindex value] 
    dims=[length(B(1).rows) length(B(1).cols) length(B(1).lays)];

    for i=1:length(B)
        QDRN(:,i)=sum(sum(mf_expand(B(i).term{idrn},dims),2),3); % catch end
        QRCH(:,i)=sum(sum(mf_expand(B(i).term{irch},dims),2),3); % catch end
        QGHB(:,i)=sum(sum(mf_expand(B(i).term{ighb},dims),2),3); % catch end
        QSTO(:,i)=sum(sum(mf_expand(B(i).term{isto},dims),2),3); % catch end
        QWEL(:,i)=sum(sum(mf_expand(B(i).term{iwel},dims),2),3); % catch end
    end    
else
    for i=1:length(B)
        QDRN(:,i)=sum(sum(B(i).term{idrn},2),3); % catch end
        QRCH(:,i)=sum(sum(B(i).term{irch},2),3); % catch end
        QGHB(:,i)=sum(sum(B(i).term{ighb},2),3); % catch end
        QSTO(:,i)=sum(sum(B(i).term{isto},2),3); % catch end
        QWEL(:,i)=sum(sum(B(i).term{iwel},2),3); % catch end
    end
end

% compute these discharge in m/d by dividiing with the cross section area
QDRN=QDRN./(a*ones(1,Nt));
QRCH=QRCH./(a*ones(1,Nt));
QGHB=QGHB./(a*ones(1,Nt));
QSTO=QSTO./(a*ones(1,Nt));
QWEL=QWEL./(a*ones(1,Nt));

%% Total these flows to see of the water balance is zero (or almost)
QTOT=         QDRN +    QRCH +    QGHB +    QSTO +    QWEL;
QABS=0.5*(abs(QDRN)+abs(QRCH)+abs(QGHB)+abs(QSTO)+abs(QWEL));

%% Display these flows summed over all times for the cross sections
% to show that the water budget matches
% for all cross section of all times
fprintf('      QTOT      QWEL      QSTO      QDRN      QGHB      QRCH  [mm/d]');
display(1000*[...
    mean(QTOT,2),...
    mean(QWEL,2),...
    mean(QSTO,2),...
    mean(QDRN,2),...
    mean(QGHB,2),...
    mean(QRCH,2)]);

%% saving the waterbalance for all sections
labels=B(1).label;
timestamp=now;
legtxt={'UPWSPG','STO   ','DITCH ','RUNOFF','RCH   ','DWNSPG','STO   ','DITCH ','RUNOFF','EVTR  '};
labtxt={'QWEL>0','QSTO>0','QGHB>0','QDRN>0','QRCH>0','QWEL<0','QSTO<0','QGHB<0','QDRN<0','QRCH<0'};
save Balance labels legtxt labtxt QTOT QWEL QSTO QDRN QGHB QRCH P tne timestamp

%% The (relative) area of the selecred cross sections

A=[P.area]'; a = (A/sum(A))*ones(1,size(QTOT,2));

%% Show running water budget summed over all area-weigted cross sections 
%  selected from the database

POS=[max(0,sum(a.*QWEL,1));max(0,sum(a.*QSTO,1));...
     max(0,sum(a.*QGHB,1));max(0,sum(a.*QDRN,1));...
     max(0,sum(a.*QRCH,1))];
NEG=[min(0,sum(a.*QWEL,1));min(0,sum(a.*QSTO,1));...
     min(0,sum(a.*QGHB,1));min(0,sum(a.*QDRN,1));...
     min(0,sum(a.*QRCH,1))];
figure; hold on

% convert to mm/d while plotting
area(tne(:,1),POS'*1000);
area(tne(:,1),NEG'*1000);
plot(tne(:,1)',sum(a.*QTOT*1000,1),'w');

legend('UPWSPG','STO','DITCH','RUNOFF','RCH','DWNSPG','STO','DITCH','RUNOFF','EVTR');
xlabel(sprintf('%s - %s',datestr(tne(1,1),'yyyy'),datestr(tne(end,1),'yyyy')));
ylabel('mm/d');
title(sprintf('Running water budget for %s over %d cross sections representing %.0f ha in mm/d',...
    basename,NSec,sum([P.area])/1e4));
datetick('x',4); grid on;

%% Show the running balance of the top system

%dtopBalance
