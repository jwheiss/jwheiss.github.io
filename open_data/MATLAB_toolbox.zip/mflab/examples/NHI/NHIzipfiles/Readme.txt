This directory should contain the zipfiles of the NHI model. However, the size is too big
to copy them to the mfLab site. You can download them yourself from

http://www.nhi.nu/bibliotheek.html

Their exact URL s are in the workbook NHI.xls, see worksheet "zipfiles".
the column description is obvious but in Dutch.
the column zipfileURL shows their URL on the NHI site
the column zipfileName is the name without the path.

the unpacked files are all ASCII and reside in the directory NHIascii.
