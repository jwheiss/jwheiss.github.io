This directory should contain the unzipped NHI files (from the zipfiles)

Each file is an ASCII file, either representing a layer variable (with 1300 by 1200 
data points or a stress (boundary condition file) specifying the values per cell as a
list starting with Layer Row Col and ending with Q or Head Conductance depending on the
type of stress.

In total there are over 110 files for just the steady-state NHI model.

Once you downloaded the zipfiles, you can unpack them to this directory so that they
can be read by NHI.m who converts them to mat files in the directory NHI.data for further
use (especially more efficient use) by others.

the directory mfLab/mfiles/NHI has some m-files to assist in reading the files automatically

getNHIzipfileList.m
SaveZips.m
NHIunzips.m

there is no warranty, but you may use them to start developing your own code to manage
NHI files and for instance to automatically update if things have changed at that site.

The names of the unpacked ASCII files that should be in this directory are in the worksheet
files of workbook NHI.m