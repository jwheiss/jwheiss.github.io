function var2chc(fname,varname,var)

%fname = 'NHI.bodem.nc';

nccreate(fname,varname,...
         'Dimensions',{'r' size(var,1) 'c' size(var,2)},...
         'Format','classic');
 ncwrite(fname,'A', var);
 ncdisp(fname);