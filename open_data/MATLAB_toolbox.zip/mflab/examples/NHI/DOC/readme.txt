The documents (mostly in Dutch) can be downloaded directly from the site

http://www.nhi.nu/documenten.html