%function OUT=readcbcflowfile(filename)
%http://water.usgs.gov/nrp/gwsoftware/modflow2000/MFDOC/index.html
%{
The data can be either in single-precision or double-precision format.
There is no data field that indicates which format is used.  Instead, you
will need to try both and see which one works. First read the following
variables in order KSTP: the time step number, an integer, 4 bytes. KPER:
the stress period number, an integer, 4 bytes. DESC, a description of the
array, 16 ANSI characters, 16 bytes. NCOL, the number of columns in the
array, an integer, 4 bytes. NROW, the number of rows in the array, an
integer, 4 bytes. NLAY, the number of layers in the array, an integer, 4
bytes.  NLAY can be a negative number in which case the absolute value of
NLAY is the number of layers in the array. If NLAY is greater than zero, a
3D array of real numbers follows NLAY.  The number of values is NCOL x NROW
x NLAY. To read it, you can use a loop over the layers that contains a loop
over rows that contains a loop over columns. If NLAY is less than zero, the
compact format is being used.  (However, in some older versions of MODFLOW,
data from the HUF package was saved using the compact format but with a
positive value of NLAY.) With the compact format, read the following:
ITYPE, a value indicating how the data is stored, an integer, 4 bytes.
DELT, the length of the current time step, a real number, either 4 or 8
bytes. PERTIM: the time in the current stress period, a real number, either
4 or 8 bytes. TOTIM, the total elapsed time, a real number, either 4 or 8
bytes. If ITYPE = 5 read NVAL which is the number of values associated with
each cell.  Otherwise, assume that NVAL = 1. If NVAL > 1, read (NVAL - 1)
copies of CTMP.  CTMP is a description of the additional value associated
with each cell. CTMP is 16 ANSI characters, 16 bytes. If ITYPE = 2 or 5
read NLIST which is the number of cells for which values will be stored.
NLIST is an integer, 4 bytes. Next we read the values associated with the
cells. The format used to read the values is determined by ITYPE. �	If
ITYPE = 0 or 1, read a 3D array of values. �	If ITYPE = 2 or 5, read a
list of cells and their associated values. �	If ITYPE = 3, read a 2D
layer indicator array followed by a 2D array of values to be assigned to
the layer indicated by the layer indicator array. �	If ITYPE = 4 read a 2D
array of values associated with layer 1. If ITYPE = 0 or 1, read a 3D array
of real numbers.  The number of values is NCOL x NROW x Abs(NLAY). To read
it, you can use a loop over the layers that contains a loop over rows that
contains a loop over columns. Each value is either 4 or 8 bytes depending
on whether the file is saved with single- or double-precision data.
Remember that NLAY may be a negative number. If ITYPE = 2 or 5 check
whether NLIST is greater than zero. If it is greater than zero, compute NRC
as NROW x NCOL. then in a loop from 1 to NLIST read first ICELL (an
integer, 4 bytes) and then NVAL values (real numbers either 4 or 8 bytes
each).  ICELL is a cell index, the layer, row and column can be determined
from ICELL as follows: Layer = (ICELL-1)/NRC + 1 Row = ( (ICELL -
(Layer-1)*NRC)-1 )/NCOL +1 Column = ICELL - (Layer-1)*NRC - (Row-1)*NCOL
Duplicate ICELL values may occur in the list.  For example if two wells
occur in the same cell, the cell will be listed twice: once for each well.
If ITYPE = 3, first read NROW*NCOL integer values (4 bytes each).  These
are layer indicators in row major order.  Then read NROW*NCOL real-number
values (either 4 or 8 bytes each) in row major order.  The position of each
value in the list indicates its row and column.  The corresponding layer
indicator indicates which layer to which the value applies. If ITYPE = 4,
read NROW*NCOL real-number values (either 4 or 8 bytes each) in row major
order.  All the values apply to the top layer (layer 1).  A value of zero
applies to all the remaining cells. After reading one set of values, start
over with KSTP. Continue until reaching the end of the file. To determine
whether the files are saved with single- or double-precision real numbers,
you need to read the flow values for at least two flow terms.  The
description of the first flow term should be one of the first four items in
the list below.  The second flow term should be one of the last four items
in the list below. The flow terms should be read using the information
described above but using either single (4 byte) or double (8 byte) real
numbers when reading the data. '         STORAGE' '   CONSTANT HEAD' 'FLOW
RIGHT FACE ' 'FLOW FRONT FACE ' 'FLOW LOWER FACE '
%}

fid=fopen(filename,'r');
ind1=0;
ind2=1;
kper=0;
while ~feof(fid) % comment out to output first layer
    fprintf(['fid' num2str(fid)]);
    temp=[];
    KSTP=fread(fid,1,'uint');
    KPER=fread(fid,1,'uint');
    if KPER~=kper
        ind2=1;
        ind1=ind1+1;
        kper=KPER;
        if mod(KPER-1,10)==0 && KPER~=1
            fprintf('Saving...\n')
            save(['cbcf_' num2str(KPER-10) '_' num2str(KPER-1)],'OUT')
            clear OUT
        end
    end
    DESC=char(fread(fid,16,'char')');
    fprintf(['Reading ' strtrim(DESC) ' for Period ' num2str(KPER) '\n'])
    NCOL=fread(fid,1,'uint');
    NROW=fread(fid,1,'uint');
    nlay=fread(fid,1,'int');
    NLAY=abs(nlay);
    if nlay<0
        ITYPE=fread(fid,1,'uint');
        DELT=fread(fid,1,'float');
        PERTIM=fread(fid,1,'float');
        TOTIM=fread(fid,1,'float');
        if ITYPE==0 || ITYPE==1
            fprintf(['here0']);
            temp=nan(NROW,NCOL,NLAY);
            for k=1:NLAY
                for i=1:NROW
                    for j=1:NCOL
                        temp(i,j,k)=fread(fid,1,'float');
                    end
                end
            end
        elseif ITYPE==2 || ITYPE==5
            fprintf(['here2']);
            if ITYPE==5
                NVAL=fread(fid,1,'uint');
                fprintf(['here5_NVAL=' NVAL]);
                if NVAL>1 %If NVAL > 1, read (NVAL - 1) copies of CTMP.  CTMP is a description of the additional value associated with each cell. CTMP is 16 ANSI characters, 16 bytes.
                    fprintf(['inLoop']);

                    for i=1:NVAL-1 % loop added by cjr 
                    CTMP(i,:)=char(fread(fid,16,'char')');
                    end %end of loop added by CJR

                end
            end
            
            NLIST=fread(fid,1,'uint');%'uint32');
        
            if NLIST>0
                fprintf(['hereNlist0 NLIST=' NLIST]);
                NRC=NROW*NCOL;
                temp=nan(NLIST,4); %problem line
                for i=1:NLIST
                    ICELL=fread(fid,1,'uint');
                    VAL=fread(fid,1,'float');
                    lay=floor((ICELL-1)/NRC+1);
                    row=floor(((ICELL-(lay-1)*NRC)-1)/NCOL+1);
                    col=ICELL-(lay-1)*NRC-(row-1)*NCOL;
                    temp(i,:)=[lay row col VAL];
                end
            end
        elseif ITYPE==3
            fprintf(['here3']);
            for i=1:NROW*NCOL
                temp(i,1)=fread(fid,1,'uint');
            end
            for i=1:NROW*NCOL
                temp(i,2)=fread(fid,1,'float');
            end
        end
    elseif nlay>0
        temp=nan(NROW,NCOL,NLAY);
        for k=1:NLAY
            for i=1:NROW
                for j=1:NCOL
                    temp(i,j,k)=fread(fid,1,'float');
                end
            end
        end
    end
    %OUT=temp; %added by CJR outputs first layer only
    OUT{ind1,1}{ind2,1}=strtrim(DESC); % comment out to output first layer
    OUT{ind1,1}{ind2,2}=temp; %comment out for first layer
    ind2=ind2+1;
    
    
end
fclose(fid)
fprintf('Saving...\n')
save(['cbcf_' num2str(KPER-9) '_' num2str(KPER)],'OUT')
%clear OUT % comment out to output first layer
%OUT='file read done'; % comment out to output first layer
