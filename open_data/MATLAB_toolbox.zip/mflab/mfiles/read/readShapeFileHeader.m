function SHAPE = readShapeFileHeader(FName)
%%
    fprintf('\n\nreadshp --- %s\n',datestr(now));

    if strcmpi(FName(end-3:end),'.shp'), FName=FName(1:end-4); end  % cut off .shp if necessary

    headerlen=100;  % for shp and shx files

    %% Open file pointers using big and little endian as needed

    % big endian file pointer into index file
    shxB =fopen([FName,'.shx'],'r','b');  % big endian bite ordering (Sun or Motorola)

    % big endian file pointer into main file
    shpB =fopen([FName,'.shp'],'r','b');  % big endian bite ordering (Sun or Motorola)

    % little endian time pointer into main file
    shpL =fopen([FName,'.shp'],'r','l');  % little endian (Intel or PC)

    if shxB<1, error('Can''t open file ''%s.shx''\n',FName); end
    if shpB<1, error('Can''t open file ''%s.shp''\n',FName); end
    if shpL<1, error('Can''t open file ''%s.shp''\n',FName); end

    %% Skip the header because it is idential to that of the .shp file

    shxHdr=fread(shxB,100,'int8');
    shpHdr=fread(shpB,100,'int8');

    % assert that the two headers are equal
    if ~all(shxHdr([1:25 29:100])==shpHdr([1:25 29:100])),
        error('Header in .shx and .shp file differ, must be the same\n');
    end

    %% Header shx file
    fseek(shxB, 0,'bof'); fprintf('FileCode  = %d\n',fread(shxB,1,'uint'));
    fseek(shxB,24,'bof'); fprintf('FileLenShx= %d\n',fread(shxB,1, 'int'));  % number of bytes
    fseek(shxB,28,'bof'); fprintf('Version   = %d\n',fread(shxB,1, 'int'));

    %% Header shp file
    fseek(shpB, 0,'bof'); fprintf('FileCode  = %d\n',fread(shpB,1,'uint'));
    fseek(shpB,24,'bof'); fprintf('FileLenShp= %d\n',fread(shpB,1, 'int')); % in 16 bit words
    fseek(shpB,28,'bof'); fprintf('Version   = %d\n',fread(shpB,1, 'int'));

    fclose(shpB); % big endian pointer into o file no longer needed

    %% Get number of o records from index file

    SHAPE.name=FName;

    SHAPE.NShapes=(ftell(shxB)-headerlen)/8;

    %% read bounding box from shapefile header
    fseek(shpL,32,'bof');
        SHAPE.type=fread(sphL,1,'int');
        fprintf('Shape type = %s\n',SHAPPE.type);

    fseek(shpL,36,'bof');
        SHAPE.Xmin=fread(shpL,1,'double');
        SHAPE.Ymin=fread(shpL,1,'double');
        SHAPE.Xmax=fread(shpL,1,'double');
        SHAPE.Ymax=fread(shpL,1,'double');
        SHAPE.Zmin=fread(shpL,1,'double');
        SHAPE.Zmax=fread(shpL,1,'double');
        SHAPE.Mmin=fread(shpL,1,'double');
        SHAPE.Mmax=fread(shpL,1,'double');

    %% saving file pointers

    fseek(shxB,0,'eof');

    SHAPE.shpL = shpL;
    SHAPE.shxB = shxB;
    
    
    %% DBF data
    SHAPE.data = dbfread(FName)';

