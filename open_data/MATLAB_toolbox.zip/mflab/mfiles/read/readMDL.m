%READMDL same as readMFlab

readMFLAB
