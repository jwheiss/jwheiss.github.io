% MFILES
%
% Files
%   mfsetpath - --- set mflab paths and provide strings to be copied into a shortcut
