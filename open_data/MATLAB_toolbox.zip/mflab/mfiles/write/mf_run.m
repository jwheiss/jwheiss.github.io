%MF_RUN sctipt that runs mf_setup, mf_run is considered a more logical name than mf_setup
%
% Also, I think or replacing mf_adapt by mf_build, which is also a more
% logical name.
%
% This descision was taken after discussion with Frank Smits on May 21,
% 2012. The original names have a historical background which is no longer
% useful.
%
% TO 120522

mf_setup