function writeSWI(basename,swi)
%WRITESWI writes input for SWI package (seawater intrusion package)
%
% Example:
%    writeSWI(basename,swi)
%
%    0.- Opens a new empty file to write all the data in
%    1.- Types in the new file the name and the date, does not work with this file
%    2.- Types in the command window the file which is being written
%    3.- Types the first line with the four requires values (NPLN ISTRAT ISWIZT
%        NPRN)
%    4.- Types the second line with the four required values (TOESLOPE TIPSLOPE
%        ZETAMIN DELZETA)
%    5.- Types the density values depending of the value given to ISTRAT
%    6.- The interfaces are written by number of plane and, afterwards, by layer
%    7.- Types the value of the effective porosity by layer
%    8.- Types the kind of source at each point by layer
%
%    The .swi file is ready to be used
%
% TO 090624

fid=fopen([basename,'.',swi.ext],'wt');                                     
%% 0

%fprintf(fid,'# MATLAB writeSWI %s\n',datestr(now));  % SWI doesn't allow comment lines
fprintf(    '# MATLAB writeSWI %s\n',datestr(now));                         

%% 1

fprintf(fid,'%10d%10d%10d%10d     NPLN ISTRAT ISWIZT NPRN\n',...            
        swi.NPLN,swi.ISTRAT,swi.ISWIZT,swi.NPRN);
    % number of inerfaces, swithc for stratified or interpolated and number
    % of steps between zeta recordings
    
%% 2 

fprintf(fid,'%10f%10f%10f%10f     TOESLOPE TIPSLOPE ZETAMIN DELZETA\n',...  
        swi.TOESLOPE,swi.TIPSLOPE,swi.ZETAMIN,swi.DELZETA);
        % max slop of toecell, of tipcell, minimum zeta before zeta is
        % removed from a cell, delzeta is elevation when it is moved into
        % an adjacent cell
%% 3
% Values for dimensionless density (NPLN+1 if ISTRAT=1, NPLN if ISTRT=0
warray(fid,swi.NU(:)',swi.unit,sprintf('(%dF15.5)',length(swi.NU)),'NU',true,swi.FREE);  

if isfield(swi.ZETA,'values')
    fieldnm='values';
else
    fieldnm='term';
end
    
if isstruct(swi.ZETA)
    % ZETA -- SWI wants for each surface(PLNE) and then for each layer the ZETA
    % this is compatible with the way data is stored in the budget file
    % in mflab. So if you have the struct with zeta planes in this way,
    % e.g obtained from reading a ZTA file:
    % ZETA=readbud([basename '.ZTA']);
    % then you could provide ZETA(it) as input to SWI in mfLab. it=end is default to
    % easily allow continuation from a previous run;

    for ipln=1:swi.NPLN
        for iLay=1:swi.GRID.Nlay % for each layer
            if iscell(swi.ZETA(ipln).(fieldnm))
                warray(fid,swi.ZETA(ipln).(fieldnm){1}(:,:,iLay),...
                    swi.unit,'(10E15.6)',sprintf('Layer(%d), ZETA(%d)',iLay,ipln),true,swi.FREE);
            else
                warray(fid,swi.ZETA(ipln).(fieldnm)(:,:,iLay),...
                    swi.unit,'(10E15.6)',sprintf('Layer(%d), ZETA(%d)',iLay,ipln),true,swi.FREE);
            end
        end
    end

elseif isnumeric(swi.ZETA)    
    % ZETA might be specified alternatively as a single array of size
    % NROW,NCOL,NPLN. Each layer in this array is the elevation of the ZETAPLANE
    % in 3D space.
    for ipln=1:swi.NPLN  % for each surface
        for iLay=1:swi.GRID.Nlay % for each layer
            warray(fid,max(min(swi.GRID.ZTlay(:,:,iLay),swi.ZETA(:,:,ipln)),swi.GRID.ZBlay(:,:,iLay)),...
                swi.unit,'(10E15.6)',sprintf('Layer(%d), ZETA(%d)',iLay,ipln),true,swi.FREE);
        end
    end
else
    error('mfLab:writeSWI:ZETA_wrong_structure',...
        ['ZETA should have same sturcture as if produced by readBud()\n',...
         'or be a Ny*Nx*NPLN array of doubles, each layer representing the\n',...
         'elevation of the ZETA plane in 3D space\n']);
end
%% 5
% Types the value of the effective porosity by layer
for iLay=1:swi.GRID.Nlay
    warray(fid,swi.SSZ(:,:,iLay)    ,swi.unit,'(12F12.3)',...
        sprintf('SSZ(%d)=effective porosity'    ,iLay),true,swi.FREE); 
end

%% 6
% Types the kind of source at each point by layer
for iLay=1:swi.GRID.Nlay
    warray(fid,swi.ISOURCE(:,:,iLay),swi.unit,'(25I4)',sprintf('ISOURCE(%d)',iLay),true,swi.FREE); 
end

%% The .swi file is ready to be used
fclose(fid);
