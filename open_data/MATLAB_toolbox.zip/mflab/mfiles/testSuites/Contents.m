% TESTSUITES
%
% Files
%   check_mf_adapts                    - runs mf_adapt.m and mf_build.m in current and all subdirectories
%   look_for_use_of_function           - checks in current and lower dirctories where string is used in m-files
%   run_mf_setup_and_check_mf_analyzes - recursively check all examples
%   testPlotXSec                       - tests plotXSec and plotYSec for many input variants
