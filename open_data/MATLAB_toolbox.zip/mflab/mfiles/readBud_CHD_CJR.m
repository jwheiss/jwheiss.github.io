function OUT=readBud_CHD_CJR(filename)

fid=fopen(filename,'r');
ind1=0;
ind2=1;
kper=0;

%% CHD
temp=[];
KSTP=fread(fid,1,'uint');
KPER=fread(fid,1,'uint');

    ind2=1;
    ind1=ind1+1;
    kper=KPER;
    if mod(KPER-1,10)==0 && KPER~=1
        fprintf('Saving...\n')
        save(['cbcf_' num2str(KPER-10) '_' num2str(KPER-1)],'OUT')
        clear OUT
    end

DESC=char(fread(fid,16,'char')');
fprintf(['Reading ' strtrim(DESC) ' for Period ' num2str(KPER) '\n'])
NCOL=fread(fid,1,'uint');
NROW=fread(fid,1,'uint');
nlay=fread(fid,1,'int');
NLAY=abs(nlay);

ITYPE=fread(fid,1,'uint');
DELT=fread(fid,1,'float');
PERTIM=fread(fid,1,'float');
TOTIM=fread(fid,1,'float');

NLIST=fread(fid,1,'uint');%'uint32');

if NLIST>0
    fprintf(['hereNlist0 NLIST=' NLIST]);
    NRC=NROW*NCOL;
    temp=nan(NLIST,4); %problem line
    for i=1:NLIST
        ICELL=fread(fid,1,'uint');
        VAL=fread(fid,1,'float');
        lay=floor((ICELL-1)/NRC+1);
        row=floor(((ICELL-(lay-1)*NRC)-1)/NCOL+1);
        col=ICELL-(lay-1)*NRC-(row-1)*NCOL;
        temp(i,:)=[lay row col VAL];
    end
end

fclose(fid);


CHD = zeros(201,233);

for i=1:length(temp)
CHD(temp(i,2),temp(i,3))=temp(i,4);
end

OUT = CHD;