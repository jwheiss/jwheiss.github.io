function OUT =agesTracking(rootFolder)

fileName='029';

ROWs = 201;
COLs = 233;
LAYs = 4; %number of particles per cell

%set breaks in the histogram
histoBreaks = 0:(1/10):10;
histoBreaks = 10.^histoBreaks;
histoBreaks = [0 histoBreaks(1:length(histoBreaks))];
len=length(histoBreaks);


%get list of subfolders
subFolders = listSubSubFolders(rootFolder);

OUT = zeros(length(subFolders),len);

for fold = 1:length(subFolders)
    try
        folder = subFolders(fold);
        
        temp = strcat(folder, '\', fileName, '.end');
        ageArray=importMPath5(temp{1,1}); %(I x J x numParticles/cell)
        
        temp = strcat(folder, '\', fileName, '.bud');
        chdArray=readBud_CHD_CJR(temp{1,1}); %(I x J)
        
        %initialize array where histo vals will be stored
        histoVals = zeros(1,len);
        
        %loop through age array
        for row=1:ROWs
            for col=1:COLs
                for lay=1:LAYs
                    
                    histLoc=1;
                    age = ageArray(row,col,lay);
                    
                    while age > histoBreaks(histLoc)
                        histLoc=histLoc+1;
                    end
                    
                    histoVals(1,histLoc) = histoVals(1,histLoc)+chdArray(row,col)/LAYs; %1/numParticles of the flux is assigned to this age
                    
                end
            end
        end
        
        
        histoCDF = zeros(1,len);
        for i=1:len
            histoCDF(i)=sum(histoVals(1:i));
        end
        
        histoCDFpct=histoCDF./histoCDF(len);
        
    catch
        histoVals = zeros(1,len);
        histoCDF = zeros(1,len);
        histoCDFpct=zeros(1,len);
    end
    
       
    OUT(fold,:)=histoCDFpct;
end

% columns=zeros(len,1);
%     for i=1:212
%         column=0;
%         for j=1:len
%             if histoCDFpct(i,j) < .5
%                 column=column+1;
%             end
%         end
%         
%         columns(i,1)=column;
%     end
%     
%     for i =1:212
%         agesList(i,1)=histoBreaks(columns(i));
%     end



%% plot
        % bar(abs(histoVals))
        % %plot(abs(histoCDF))
        % ax1 = gca;
        % set(ax1,'XColor','b','YColor','b')
        % ax2 = axes('Position',get(ax1,'Position'),...
        %     'YAxisLocation','right',...
        %     'Color','none',...
        %     'XColor','k','YColor','red');
        % hold on
        % plot(abs(histoCDFpct),'color','red','Parent',ax2)
        %
        % a=[cellstr(num2str(get(ax2,'ytick')'*100))];
        % pct = char(ones(size(a,1),1)*'%');
        % new_yticks = [char(a) '%'];
        %
        % set(ax2,'YTickLabel',new_yticks')
        %
        % set(ax1,'XTickLabel', [0,1,100,1000,10000,100000,1000000,10000000])