%extract data from readBud6 function (matrix 'B') into 3D matrix of:
%storage, constant head, flow right, flow lower

% negative fluxes are out of the system


%need to use readbud6 to get matrix 'B' for fluxes
%need to use readDIS to get matrix 'dis' for x and y coords

% clear all

%% create a 3d matrix of u for flux across right face (matrix 'right')
%and a matrix of v for flux across lower face (matrix 'left)

%matrix B is raw output from readbud6; convert to cell array
%define modflow grid
num_layers = B.NLAY;
num_columns = B.NCOL;
num_rows = B.NROW;

F = struct2cell(B).';  %matrix B is raw output from readbud6; convert to cell array

%time domain and flow timesteps
time = cell2mat(F(:,12));
flow_TS = cell2mat(F(:,2));


% %storage, constant head, flow right, flow lower for each flow TS; put
% into cell array that is m by 1 where m is number of flow TS
params = F(:,7); 


%extract params from matrix params and put each into separate cell for each
%TS
for  i = 1:length(B)
    bud(i,:) = params{i,:};
end


%matrix of fluxes across right and lower faces for each flow TS
right_face = bud(:,3);
lower_face = bud(:,4);


%right face (u); convert columns to layers and layers to columns for each flow timestep
parfor m = 1:length(B);
    right = right_face{m};
    for j = 1:num_columns;
        for i = 1:num_layers;
           right_face_3d(m,i,j)=right(1,j,i); 
        end
    end
end


%lower face (u); convert columns to layers and layers to columns for each flow timestep
parfor m = 1:length(B);
    lower = lower_face{m};
    for j = 1:num_columns;
        for i = 1:num_layers;
           lower_face__3d(m,i,j)=lower(1,j,i); 
        end
    end
end


%% matrix of x coordinates and matrix of y coordinates of grid cells

%define model grid domain
D = struct2cell(dis).';  %matrix dis is raw output from readDIS; convert from structure to cell array

%%%%%%
% X coords
%X coords; distance from landward boundary
x_dis = D(1,8);
x_dis = cell2mat(x_dis);

%make matrix of x_dis of grid; k limit is num_layers+1 because
%there are is a value for the elevation of the top of each grid PLUS the
%elevation of the bottom of the model domain
for k = 1:num_layers+1; 
    x_dis_grid(k,:) = x_dis;
end

% make matrix of cumulative sum of x_dis_grid
for m = 1:num_layers+1 
X(m,:) = cumsum(x_dis_grid(m,:)); 
end

X = [zeros(num_layers+1,1) X]; 

X_top_layer = X(1:num_layers,2:num_columns+1);  % use this if you want to plot location of each
%grid cell, excluding bottom of model domain
%X_top_layer is the X coord of the right face of each grid cell


%%%%%%
% Y coords
%Y coords; depth from top of model domain
Y_flip = D(1,10);
Y_flip = cell2mat(Y_flip);

%convert columns to layers and layers to columns
for j = 1:num_columns; 
      for i = 1:num_layers+1;                
               Y_3d(1,i,j)=Y_flip(1,j,i);                
    end
end

%isolate layers and columns from 3d matrix Y_3d
   for j = 1:num_columns;
      for i = 1:num_layers+1;
            Y(i,j)=Y_3d(1,i,j);             
    end
   end

Y = [Y(:,1) Y]; %elevation of left face of first column in model has same 
%elevation as right face. Add this to matrix Y


Y_top_layer = Y(1:num_layers,2:num_columns+1);  % use this if you want to plot location of each
%grid cell, excluding bottom of model domain
%Y_top_layer is the Y coord of the top of each grid cell




%% plot velocity vectors at specified flow time step
timestep = 10;


u = squeeze(right_face_3d(timestep,:,:));
v = squeeze(lower_face__3d(timestep,:,:));


quiver(X_top_layer, Y_top_layer, u, v);
ylabel('Elevation [m]');
xlabel('Distance [m]');
% axis([0 xmax   min(flux_bdry(:)) max(flux_bdry(:))])