clear all
%concentrations from readMT3D2


num_flowTS = 160; %INPUT number of flow timesteps in model
ucn_name = '0001A.ucn'; %INPUT name of ucn file


%% matrix of x coordinates and matrix of y coordinates of grid cells
dis = readDIS('001.dis');

%define model grid domain
D = struct2cell(dis).';  %matrix dis is raw output from readDIS; convert from structure to cell array

%layers; Y coords; depth from top of model domain and number of layers
num_layers = D(1,1);
num_layers = cell2mat(num_layers);
%columns; X coords; distance from landward boundary, and number of columns
num_columns = D(1,3);
num_columns = cell2mat(num_columns);
%rows
num_rows = D(1,2);
num_rows = cell2mat(num_rows);



%%%%%%%%%%%%%%%%%%%%%%
%x coords
%make matrix of x_dis of grid; k limit is num_layers+1 because
%there are is a value for the elevation of the top of each grid PLUS the
%elevation of the bottom of the model domain

%X coords; distance from landward boundary
x_dis = D(1,8);
x_dis = cell2mat(x_dis);

for k = 1:num_layers+1; 
    x_dis_grid(k,:) = x_dis;
end

% make matrix of cumulative sum of x_dis_grid
for m = 1:num_layers+1 
X(m,:) = cumsum(x_dis_grid(m,:)); 
end

X = [zeros(num_layers+1,1) X]; 

X_top_layer = X(1:num_layers,2:num_columns+1);  % use this if you want to plot location of each
%grid cell, excluding bottom of model domain
%X_top_layer is the X coord of the right face of each grid cell



%%%%%%%%%%%%%%%%%%%%%%
%Y coords
Y_flip = D(1,10);
Y_flip = cell2mat(Y_flip);

%convert columns to layers and layers to columns
for j = 1:num_columns; 
      for i = 1:num_layers+1;                
               Y_3d(1,i,j)=Y_flip(1,j,i);                
    end
end

%isolate layers and columns from 3d matrix Y_3d
   for j = 1:num_columns;
      for i = 1:num_layers+1;
            Y(i,j)=Y_3d(1,i,j);             
    end
   end

Y = [Y(:,1) Y]; %elevation of left face of first column in model has same 
%elevation as right face. Add this to matrix Y


Y_top_layer = Y(1:num_layers,2:num_columns+1);  % use this if you want to plot location of each
%grid cell, excluding bottom of model domain
%Y_top_layer is the Y coord of the top of each grid cell


figure(1)
plot(X_top_layer, Y_top_layer,'k.');




%% extract concentrations from matrix C and put into matrix 'B' of i,j,k where i is 
%transport timestep, j, is number of model layers, and k is number of model
%columns
C=readMT3D2(ucn_name, 1:num_flowTS,  1:num_layers,  1:num_rows,  1:num_columns);

D = struct2cell(C).';  %matrix C is raw output from readMT3D2

ival = cellfun(@ischar,D); %identify cells with string and replace with '1'. All other cells get '0'
D(ival) = {NaN};   %replace all '1's with NaN in cell array D


conc = cell2mat(D(:,1)); % pull out concentrations for each transport TS and convert to matrix
% [TS    column in model domain      layer in model domain]

time = cell2mat(D(:,5)); % pull out elepsed time and convert to matrix

flowTS = cell2mat(D(:,3)); % pull out flow timesteps and convert to matrix


B = zeros(length(conc), num_layers, num_columns);
%convert columns to layers and layers to columns
for k = 1:length(conc);
    for j = 1:num_columns;
        for i = 1:num_layers;
            B(k,i,j)=conc(k,j,i);
        end
    end
end





%% plot concentration at one point in time in cross section

transTS = 200; %INPUT transport timestep to plot

elapsed_time = time(transTS,1); %not needed but nice to know elapsed time

conc_transTS = B(transTS,:, :); %pull out concentrations during transport TS of interest


%isolate layers and columns from 3D matrix conc_transTS
for j = 1:num_columns(1,1);
	for i = 1:num_layers(1,1);
           conc_transTS_model(i,j)=conc_transTS(1,i,j); 
    end
end

figure(2);
contourf(X_top_layer,  Y_top_layer,  conc_transTS_model,5, 'LineColor','none');
ylabel('Elevation [m]');
xlabel('Distance [m]');
caxis([0 35])

% surf(X_top_layer,  Y_top_layer,  conc_transTS_model);
% ylabel('Elevation [m]');
% xlabel('Distance [m]');
% caxis([0 35])
% az = 0;
% el = 90;
% view(az, el);  % view surf plot from top





%% animate concentration in cross section
for k = 1:length(B)
    clf
       
%     annotation('textbox', [0.64,0.75,0.1,0.1], 'BackgroundColor', 'none',...
%         'EdgeColor',   'none'  ,  'String', 'Time step:');
%     annotation('textbox', [0.75,0.75,0.1,0.1], 'BackgroundColor', 'none',...
%         'EdgeColor',  'none' , 'String', k);  
    
elapsed_time = time(k,1); %just for reference (associates transport timestep with elapsed time

conc_transTS = B(k,:, :); %pull out concentrations during transport TS 'k'


%isolate layers and columns
for j = 1:num_columns(1,1);
    for i = 1:num_layers(1,1);
         conc_transTS_model(i,j)=conc_transTS(1,i,j); 
    end
end


contourf(X_top_layer,  Y_top_layer,  conc_transTS_model,5, 'LineColor','none');
ylabel('Elevation [m]');
xlabel('Distance [m]');
caxis([0 35])



Mo = getframe;   
end
% hold on
% numtimes = 1;
% fps = 24;
% movie(Mo,numtimes,fps)
% movie2avi(Mo, 'CS.avi', 'Compression', 'None');




