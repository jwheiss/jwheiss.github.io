### Dr. James Heiss <br> ENVI3010 <br> GIS in Earth and Environmental Sciences <br> james_heiss@uml.edu <br> Date
### Lab 1

#### Purpose
Lab 1 images, tables, text, etc. go in these subheadings.

![hover-over text](SandTable.png)
<br>
**Figure 1.** Example sand table landscape.
<br><br>
More text.


#### Objective
Text.
#### Methods
Text.
#### Data, answers, graphics
Text.
#### Summary and Conclusion
Text.

